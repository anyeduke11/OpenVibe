/* ============================================================
   OpenVibe 灵典 · 交互原型（单页应用）
   覆盖：M1 提示词库 / M2 Skill 中心 / M3 术语库 / M5 项目与流程 /
        M6 标准包与注入 / 开箱体验 / 成长阶段与渐进披露 / 三层保证
   ============================================================ */
(function () {
  "use strict";
  var S = window.OV_SEED;
  var DOC = document;

  /* ══════════════ 工具 ══════════════ */
  function $(s, r) { return (r || DOC).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || DOC).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function escA(s) { return esc(s).replace(/"/g, "&quot;"); }
  function find(arr, id) { for (var i = 0; i < arr.length; i++) if (arr[i].id === id) return arr[i]; return null; }
  function pad(n) { return n < 10 ? "0" + n : "" + n; }
  function now() {
    var d = new Date();
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes());
  }
  function estTokens(txt) {
    var s = String(txt || "");
    var cjk = (s.match(/[\u3400-\u9fff\u3000-\u303f\uff00-\uffef]/g) || []).length;
    return Math.round(cjk + (s.length - cjk) / 4);
  }
  function sha(s) { // 演示用短指纹（非密码学）
    var h = 0x811c9dc5, i;
    for (i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = (h * 0x01000193) >>> 0; }
    return ("00000000" + h.toString(16)).slice(-8);
  }

  /* ---------- Markdown ---------- */
  var KW = "const|let|var|function|return|if|else|for|while|import|from|export|default|class|new|await|async|try|catch|throw|typeof|interface|type|extends|implements|public|private|readonly|as|in|of|this|null|undefined|true|false|def|self|print|echo|cd|npm|pnpm|git|npx";
  function hi(code, lang) {
    var s = esc(code);
    if (!lang) return s;
    var re = new RegExp("(\\/\\/[^\\n]*|#[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/)|(\"(?:[^\"\\\\]|\\\\.)*\"|'(?:[^'\\\\]|\\\\.)*')|\\b(" + KW + ")\\b|\\b(\\d+(?:\\.\\d+)?)\\b", "g");
    return s.replace(re, function (m, com, str, kw, num) {
      if (com) return '<span class="tok-com">' + com + "</span>";
      if (str) return '<span class="tok-str">' + str + "</span>";
      if (kw) return '<span class="tok-kw">' + kw + "</span>";
      return '<span class="tok-num">' + num + "</span>";
    });
  }
  function mdInline(s) {
    s = esc(s);
    s = s.replace(/\{\{\s*([A-Za-z0-9_\u4e00-\u9fa5]+)\s*\}\}/g, '<span class="var">{{$1}}</span>');
    s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
    s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    s = s.replace(/(^|[^*\w])\*([^*\n]+)\*/g, "$1<em>$2</em>");
    s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    return s;
  }
  function md(src) {
    var lines = String(src || "").replace(/\r\n/g, "\n").split("\n");
    var out = [], i, para = [], tbl = [];
    function flushPara() {
      if (!para.length) return;
      out.push("<p>" + para.map(mdInline).join("") + "</p>");
      para = [];
    }
    function flushTbl() {
      if (tbl.length < 2) { tbl.forEach(function (l) { para.push(l); }); tbl = []; flushPara(); return; }
      var head = tbl[0].replace(/^\||\|$/g, "").split("|").map(function (c) { return c.trim(); });
      var rows = tbl.slice(2).map(function (l) {
        return l.replace(/^\||\|$/g, "").split("|").map(function (c) { return c.trim(); });
      });
      var h = "<table><thead><tr>" + head.map(function (c) { return "<th>" + mdInline(c) + "</th>"; }).join("") + "</tr></thead><tbody>";
      rows.forEach(function (r) {
        h += "<tr>" + r.map(function (c) { return "<td>" + mdInline(c) + "</td>"; }).join("") + "</tr>";
      });
      out.push(h + "</tbody></table>");
      tbl = [];
    }
    for (i = 0; i < lines.length; i++) {
      var L = lines[i];
      if (/^```/.test(L)) {
        flushPara(); flushTbl();
        var lang = L.replace(/^```/, "").trim();
        var buf = [];
        i++;
        while (i < lines.length && !/^```/.test(lines[i])) { buf.push(lines[i]); i++; }
        out.push("<pre><code>" + hi(buf.join("\n"), lang) + "</code></pre>");
        continue;
      }
      if (/^\s*$/.test(L)) { flushPara(); flushTbl(); continue; }
      if (/^\s*\|/.test(L)) { flushPara(); tbl.push(L); continue; }
      flushTbl();
      var m;
      if ((m = L.match(/^(#{1,4})\s+(.*)$/))) {
        flushPara();
        out.push("<h" + m[1].length + ">" + mdInline(m[2]) + "</h" + m[1].length + ">");
      } else if (/^\s*([-*_])\s*\1\s*\1[\s\-*_]*$/.test(L)) {
        flushPara(); out.push("<hr>");
      } else if (/^>\s?/.test(L)) {
        flushPara();
        var q = [];
        while (i < lines.length && /^>\s?/.test(lines[i])) { q.push(lines[i].replace(/^>\s?/, "")); i++; }
        i--;
        out.push("<blockquote>" + q.map(mdInline).join("<br>") + "</blockquote>");
      } else if ((m = L.match(/^\s*([-*+]|\d+\.)\s+(.*)$/))) {
        flushPara();
        var items = [], ordered = /\d+\./.test(m[1]);
        while (i < lines.length && (m = lines[i].match(/^\s*([-*+]|\d+\.)\s+(.*)$/))) {
          var t = m[2];
          if (/^\[( |x|X)\]\s+/.test(t)) {
            var ck = /^\[x|X\]/.test(t) ? "checked" : "";
            t = '<span class="row" style="gap:7px"><input type="checkbox" disabled ' + ck + "> " + mdInline(t.replace(/^\[( |x|X)\]\s+/, "")) + "</span>";
          } else t = mdInline(t);
          items.push("<li>" + t + "</li>");
          i++;
        }
        i--;
        out.push("<" + (ordered ? "ol" : "ul") + ">" + items.join("") + "</" + (ordered ? "ol" : "ul") + ">");
      } else {
        para.push(L);
      }
    }
    flushPara(); flushTbl();
    return out.join("\n");
  }

  /* ---------- Diff ---------- */
  function diffLines(a, b) {
    var A = String(a).split("\n"), B = String(b).split("\n");
    var n = A.length, m = B.length, i, j;
    var dp = [];
    for (i = 0; i <= n; i++) dp.push(new Array(m + 1).fill(0));
    for (i = n - 1; i >= 0; i--) for (j = m - 1; j >= 0; j--) {
      dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
    var ops = [], x = 0, y = 0;
    while (x < n && y < m) {
      if (A[x] === B[y]) { ops.push(["ctx", A[x]]); x++; y++; }
      else if (dp[x + 1][y] >= dp[x][y + 1]) { ops.push(["del", A[x]]); x++; }
      else { ops.push(["add", B[y]]); y++; }
    }
    while (x < n) ops.push(["del", A[x++]]);
    while (y < m) ops.push(["add", B[y++]]);
    return ops;
  }

  /* ══════════════ 图标 ══════════════ */
  var P = function (d) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + d + "</svg>"; };
  var ICONS = {
    gauge: P('<path d="M12 20a8 8 0 1 1 8-8"/><path d="M12 12l4-3"/>'),
    prompt: P('<path d="M5 5h14v10H9l-4 3z"/><path d="M9 9h6M9 12h3"/>'),
    skill: P('<path d="M12 3l2.4 5.2 5.6.7-4.1 3.9 1 5.6L12 15.8 6.1 18.4l1-5.6L3 8.9l5.6-.7z"/>'),
    term: P('<path d="M4 5h10M4 5v14M9 5v14"/><path d="M15 8h6M18 5v12"/>'),
    playbook: P('<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H19v18H6.5A2.5 2.5 0 0 1 4 18.5z"/><path d="M8 8h7M8 12h7"/>'),
    project: P('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M9 9v11"/>'),
    pack: P('<path d="M21 8.5 12 3 3 8.5v7L12 21l9-5.5z"/><path d="M3 8.5 12 14l9-5.5M12 14v7"/>'),
    growth: P('<path d="M4 19V5M4 19h16"/><path d="M7 15l4-5 3 3 5-6"/>'),
    settings: P('<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>'),
    copy: P('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5h10"/>'),
    plus: P('<path d="M12 5v14M5 12h14"/>'),
    check: P('<path d="M4 12.5 9 17.5 20 6.5"/>'),
    x: P('<path d="M6 6l12 12M18 6 6 18"/>'),
    refresh: P('<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 5v6h-6"/>'),
    down: P('<path d="M12 4v12M7 12l5 5 5-5"/><path d="M4 20h16"/>'),
    info: P('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'),
    warn: P('<path d="M12 4 2.5 20h19z"/><path d="M12 10v4M12 17h.01"/>'),
    clock: P('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    search: P('<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/>'),
    file: P('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>'),
    shield: P('<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>'),
    branch: P('<circle cx="6" cy="5" r="2.2"/><circle cx="6" cy="19" r="2.2"/><circle cx="18" cy="9" r="2.2"/><path d="M6 7.2v9.6M18 11.2c0 4-4 4.6-8 4.6"/>'),
    trash: P('<path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/>'),
    bolt: P('<path d="M13 2 4 14h6l-1 8 9-12h-6z"/>'),
    eye: P('<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6z"/><circle cx="12" cy="12" r="2.6"/>'),
    terminal: P('<rect x="2.5" y="4" width="19" height="16" rx="2"/><path d="M7 9.5l3 2.5-3 2.5M12.5 15h4"/>')
  };
  function ico(n, cls) { return '<span class="' + (cls || "") + '" style="display:inline-flex;width:15px;height:15px">' + (ICONS[n] || "") + "</span>"; }

  /* ══════════════ 状态 ══════════════ */
  var KEY = "openvibe-proto-v1";
  var defaults = {
    route: "/dashboard", theme: "light", expert: {}, stageOverride: {},
    onboarded: false, telemetry: false, localStats: true,
    events: S.events.slice(), ledgerFilter: "all",
    promptQ: "", promptTag: "all", promptPlat: "all", selectedPrompt: "p-001", promptTab: "edit",
    termQ: "", termView: "roadmap", termSel: [],
    scanned: false, currentProject: "prj-1", projTab: "board",
    checks: {}, kanban: {}, packDetail: null, verify: "CONSISTENT", patch: {}, extraLogs: {}, reflow: {}
  };
  var state = JSON.parse(JSON.stringify(defaults));
  try {
    var raw = localStorage.getItem(KEY);
    if (raw) {
      var saved = JSON.parse(raw);
      Object.keys(defaults).forEach(function (k) {
        if (saved[k] !== undefined && saved[k] !== null) state[k] = saved[k];
      });
    }
  } catch (e) {}
  function save() {
    try {
      var c = JSON.parse(JSON.stringify(state));
      delete c.wizard;
      localStorage.setItem(KEY, JSON.stringify(c));
    } catch (e) {}
  }

  function getPrompt(id) {
    var base = find(S.prompts, id);
    if (!base) return null;
    var p = state.patch[id];
    if (!p) return base;
    var merged = Object.assign({}, base, p);
    return merged;
  }
  function promptContent(p) {
    var pt = state.patch[p.id];
    return pt && pt.content != null ? pt.content : p.content;
  }
  function promptVersion(p) {
    var pt = state.patch[p.id];
    return pt && pt.version != null ? pt.version : p.version;
  }
  function promptLog(p) {
    var pt = state.patch[p.id];
    return pt && pt.changelog ? pt.changelog : p.changelog;
  }
  function routeStage(route) {
    if (state.stageOverride[route] != null) return state.stageOverride[route];
    var m = find(S.moduleStages.filter(function (x) { return x.route === route; }), 0) || S.moduleStages.filter(function (x) { return x.route === route; })[0];
    return m ? m.stage : 0;
  }

  /* ══════════════ Toast ══════════════ */
  function toast(title, msg, kind) {
    var root = $("#toast-root");
    var el = DOC.createElement("div");
    el.className = "toast" + (kind ? " is-" + kind : "");
    el.innerHTML = "<div>" + ico(kind === "err" ? "warn" : kind === "warn" ? "warn" : kind === "info" ? "info" : "check") + "</div><div><b>" + esc(title) + "</b>" + (msg ? "<p>" + msg + "</p>" : "") + "</div>";
    root.appendChild(el);
    setTimeout(function () {
      el.classList.add("is-out");
      setTimeout(function () { el.remove(); }, 220);
    }, 3200);
  }
  function copyText(t, okMsg) {
    var done = function () { toast(okMsg || "已复制到剪贴板"); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(done, function () { fallbackCopy(t); done(); });
    } else { fallbackCopy(t); done(); }
  }
  function fallbackCopy(t) {
    try {
      var ta = DOC.createElement("textarea");
      ta.value = t; ta.style.position = "fixed"; ta.style.opacity = "0";
      DOC.body.appendChild(ta); ta.select();
      try { DOC.execCommand("copy"); } catch (e) {}
      ta.remove();
    } catch (e) {}
  }

  /* ══════════════ 覆盖层 ══════════════ */
  var overlayStack = [];
  function overlay(html, cls) {
    var wrap = DOC.createElement("div");
    wrap.className = cls || "modal-mask";
    wrap.innerHTML = html;
    $("#overlay-root").appendChild(wrap);
    overlayStack.push(wrap);
    return wrap;
  }
  function closeOverlay(n) {
    n = n || 1;
    for (var i = 0; i < n; i++) {
      var w = overlayStack.pop();
      if (!w) break;
      if (w.classList.contains("drawer")) {
        var masks = $$(".drawer-mask", $("#overlay-root"));
        if (masks.length) {
          var m = masks[masks.length - 1];
          var k = overlayStack.indexOf(m);
          if (k >= 0) overlayStack.splice(k, 1);
          m.remove();
        }
      }
      w.remove();
    }
    if (!overlayStack.length) DOC.body.style.overflow = "";
  }
  function closeAllOverlays() { while (overlayStack.length) closeOverlay(); }
  function openModal(html, mod) {
    DOC.body.style.overflow = "hidden";
    return overlay('<div class="modal ' + (mod || "") + '" role="dialog" aria-modal="true">' + html + "</div>");
  }
  function openDrawer(html) {
    DOC.body.style.overflow = "hidden";
    var m = overlay("", "drawer-mask");
    var d = DOC.createElement("div");
    d.className = "drawer";
    d.innerHTML = html;
    $("#overlay-root").appendChild(d);
    overlayStack.push(d);
    return { mask: m, drawer: d };
  }
  DOC.addEventListener("mousedown", function (e) {
    if (e.target.classList && (e.target.classList.contains("modal-mask") || e.target.classList.contains("drawer-mask") || e.target.classList.contains("palette-mask") || e.target.classList.contains("onboard-mask"))) closeOverlay();
  });
  DOC.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && overlayStack.length) { closeOverlay(); return; }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); openPalette(); }
  });

  /* ══════════════ 顶栏 / 导航 ══════════════ */
  var TITLES = {
    "/dashboard": ["工作台", "标准化飞轮 · 本地统计不上报"],
    "/prompts": ["提示词库", "M1 · Markdown 编辑 · 模板变量 · 版本快照 · 平台适配标记"],
    "/skills": ["Skill 中心", "M2 瘦身版 · 本地扫描发现 + 手动登记与版本记录"],
    "/terms": ["术语库", "M3 · 词条 CRUD · 全文搜索 · 生成 TERMS.md"],
    "/projects": ["项目与流程", "M5 · 流程模板 · 阶段检查清单 · 看板 · 开发日志"],
    "/packs": ["标准包与注入", "M6 · 组装 · 文件生成 · dry-run · 冲突保护 · 版本追踪"],
    "/growth": ["成长与统计", "成长阶段向量 · 飞轮面板 · 本机事件台账（不出网）"],
    "/playbooks": ["技巧库 · Phase 2", "M4 · 只做回流候选登记（No spec, no task）"],
    "/cli": ["CLI 终端实验室", "回放真实命令 · 干跑优先 · 破坏性操作需确认"],
    "/settings": ["设置", "隐私 · 外观 · CLI · 关于"]
  };
  function syncChrome() {
    var t = TITLES[state.route] || ["OpenVibe", ""];
    $("#page-title").textContent = t[0];
    $("#page-sub").textContent = t[1];
    $$("#nav .nav-item").forEach(function (a) {
      a.classList.toggle("is-active", a.getAttribute("data-route") === state.route);
    });
    var st = routeStage(state.route);
    var sd = S.stageDefs[st] || S.stageDefs[0];
    $("#stage-chip-val").textContent = sd.code;
    $("#stage-chip-name").textContent = sd.name;
    var vb = $("#verify-badge");
    vb.className = "verify-badge " + (state.verify === "CONSISTENT" ? "is-ok" : "is-warn");
    $("#verify-badge-t").textContent = state.verify;
    $("#btn-expert").classList.toggle("is-on", !!state.expert[state.route]);
    DOC.documentElement.setAttribute("data-theme", state.theme);
    $("#nav-badge-loops").textContent = String(loopCount());
  }

  /* ══════════════ 视图：工作台 ══════════════ */
  function viewDashboard() {
    var st = S.stats;
    var wheel = [
      { i: "①", t: "沉淀资产", d: "提示词 / 术语 / Skill 入库", v: st.terms + st.prompts + st.skills, u: "条" },
      { i: "②", t: "组装标准包", d: "挑素材 + 选流程模板 → 版本化", v: st.packs, u: "个" },
      { i: "③", t: "注入项目", d: "CLI 写入 CLAUDE.md / TERMS.md…", v: st.injections, u: "次" },
      { i: "④", t: "项目使用", d: "按流程开发，记 DEV / CHECK 日志", v: 10, u: "次" },
      { i: "⑤", t: "回流新资产", d: "复盘产出 → 人工确认入库", v: st.reflows, u: "条" }
    ];
    var recos = [
      { t: "给 openvibe-web 跑一次 verify", d: "上次注入后你手改过 CLAUDE.md，先确认三方一致性再动。", a: "verify-run", route: "/packs" },
      { t: "处置 CLAUDE.md 的段级漂移", d: "「行为规则」段有 1 行本地改动，可选以包为准或保留本地。", a: "pack-wizard", route: "/packs" },
      { t: "确认 3 条回流候选", d: "技巧「规则漂移迹象」与 2 条术语候选待人工确认。", a: "goto-growth", route: "/growth" }
    ];
    var h = [];
    h.push('<section class="card" style="padding:22px 24px;display:grid;grid-template-columns:minmax(0,1fr) 210px;gap:24px;align-items:center">');
    h.push('<div><div class="eyebrow">v0.2.0 · 定位：意图 → 项目上下文的编译器</div>');
    h.push('<div class="hero-title" style="margin-top:9px">把提示词、Skill、术语、技巧和项目流程<br>变成可管理、可复用、可分发的工程标准。</div>');
    h.push('<p class="hero-sub">「可管理」是手段不是目的：编译（组包与注入）→ 分发（多平台 adapter）→ 反馈回路（复盘回流）。飞轮转起来才是标准。</p>');
    h.push('<div class="row wrap" style="margin-top:16px"><button class="btn btn-primary" data-act="pack-wizard">' + ico("pack") + '组装并注入标准包</button>');
    h.push('<button class="btn" data-act="goto" data-route="/prompts">' + ico("prompt") + '新建提示词</button>');
    h.push('<button class="btn" data-act="verify-run">' + ico("shield") + '运行 openvibe verify</button></div></div>');
    h.push('<div style="text-align:center"><div class="ring" style="--p:' + (st.loops / 5 * 100) + ';margin:0 auto"><b>' + st.loops + '</b></div>');
    h.push('<div class="eyebrow" style="margin-top:10px">北极星</div><div style="font-size:12.5px;color:var(--ink-2);margin-top:2px">完整飞轮圈数</div>');
    h.push('<div style="font-size:11px;color:var(--ink-3);margin-top:6px">本机统计 · 不上报</div></div></section>');

    h.push('<div class="grid grid-4 mt">');
    [
      { k: "资产沉淀", v: st.terms + st.prompts + st.skills, d: "术语 " + st.terms + " · 提示词 " + st.prompts + " · Skill " + st.skills, r: "/terms" },
      { k: "标准包", v: st.packs, d: "内置 1 · 自建 3", r: "/packs" },
      { k: "注入次数", v: st.injections, d: "本月 6 · 全部经 CLI", r: "/packs" },
      { k: "回流条目", v: st.reflows, d: "待人工确认 3", r: "/growth" }
    ].forEach(function (s) {
      h.push('<div class="stat" data-act="goto" data-route="' + s.r + '" style="cursor:pointer"><div class="st-v">' + s.v + '</div><div class="st-k">' + s.k + '</div><div class="st-d">' + ico("branch") + esc(s.d) + "</div></div>");
    });
    h.push("</div>");

    h.push('<section class="card mt"><div class="card-head"><div class="card-title">' + ico("refresh") + '标准化飞轮 <span class="badge b-muted">只用一次是工具，转起来才是标准</span></div>');
    h.push('<span class="muted" style="font-size:11.5px">数据来源：本机事件台账（append-only，不出网）</span></div><div class="card-body">');
    h.push('<div class="wheel">');
    wheel.forEach(function (n) {
      h.push('<div class="wheel-node"><div class="wn-i">' + n.i + '</div><div class="wn-t">' + n.t + '</div><div class="wn-d">' + n.d + '</div><div class="wn-v">' + n.v + '<span style="font-size:11px;color:var(--ink-3);font-weight:400"> ' + n.u + "</span></div></div>");
    });
    h.push("</div>");
    h.push('<div class="wheel-return">' + ico("branch") + '<span>⑤ 回流新资产 → 回到 ① 沉淀资产</span><span class="tag">闭环即护城环</span></div>');
    h.push("</div></section>");

    h.push('<div class="grid grid-2 mt">');
    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("bolt") + '下一步做这个</div><span class="badge b-accent">≤ 3 条</span></div><div class="card-body flush"><div class="list">');
    recos.forEach(function (r) {
      h.push('<div class="list-item" data-act="' + r.a + '" data-route="' + r.route + '"><div class="li-title">' + r.t + '</div><div class="li-meta">' + esc(r.d) + '</div></div>');
    });
    h.push("</div></div></section>");

    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("project") + '项目健康摘要</div><button class="btn btn-sm" data-act="goto" data-route="/projects">全部项目</button></div><div class="card-body flush"><div class="list">');
    S.projects.forEach(function (p) {
      var tpl = find(S.flowTemplates, p.templateId);
      var undone = 0, total = 0;
      tpl.stages.forEach(function (s, si) {
        s.checklist.forEach(function (c, ci) {
          total++;
          if (!state.checks[p.id + ":" + si + ":" + ci]) undone++;
        });
      });
      h.push('<div class="list-item" data-act="proj-open" data-id="' + p.id + '"><div class="li-title">' + esc(p.name) + ' <span class="badge ' + (p.health === "健康" ? "b-jade" : "b-amber") + '">' + p.health + "</span></div>");
      h.push('<div class="li-meta"><span>' + esc(tpl.name) + "</span><span>·</span><span>阶段 " + (p.stageIndex + 1) + "/" + tpl.stages.length + "</span><span>·</span><span>未完检查项 " + undone + "</span><span>·</span><span>最近日志 " + esc(p.logs[0].at) + "</span></div></div>");
    });
    h.push("</div></div></section>");
    h.push("</div>");

    h.push('<section class="card mt"><div class="card-head"><div class="card-title">' + ico("clock") + '最近的本机事件</div><button class="btn btn-sm" data-act="goto" data-route="/growth">打开台账</button></div><div class="card-body flush"><div class="ledger">');
    state.events.slice(0, 6).forEach(function (e) {
      h.push('<div class="ledger-row"><span class="muted">' + esc(e.at) + '</span><span class="ledger-kind">' + esc(S.eventKinds[e.kind] || e.kind) + '</span><span>' + esc(e.subject) + "</span><span class=\"tag\">" + esc(e.kind) + "</span></div>");
    });
    h.push("</div></div></section>");
    return h.join("");
  }

  /* ══════════════ 视图：提示词库 M1 ══════════════ */
  function promptTags() {
    var t = {};
    S.prompts.forEach(function (p) { p.tags.forEach(function (x) { t[x] = 1; }); });
    return Object.keys(t);
  }
  function filteredPrompts() {
    var q = state.promptQ.trim().toLowerCase();
    return S.prompts.filter(function (p) {
      if (state.promptTag !== "all" && p.tags.indexOf(state.promptTag) < 0) return false;
      if (state.promptPlat !== "all" && p.platforms.indexOf(state.promptPlat) < 0) return false;
      if (!q) return true;
      return (p.title + " " + p.tags.join(" ") + " " + promptContent(p)).toLowerCase().indexOf(q) >= 0;
    });
  }
  function promptListHTML() {
    var list = filteredPrompts();
    if (!list.length) return '<div class="empty">' + ico("search") + "<b>没有匹配的提示词</b><p>换个关键词，或把标签筛选切回「全部」。</p></div>";
    return list.map(function (p) {
      var v = promptVersion(p);
      var st = { active: ["b-jade", "生效中"], draft: ["b-amber", "草稿"], deprecated: ["b-muted", "已废弃"] }[p.status];
      return '<div class="list-item' + (p.id === state.selectedPrompt ? " is-active" : "") + '" data-act="prompt-select" data-id="' + p.id + '">' +
        '<div class="li-title">' + esc(p.title) + ' <span class="badge ' + st[0] + '">' + st[1] + "</span></div>" +
        '<div class="li-meta"><span class="tag">v' + v + "</span>" + p.tags.map(function (t) { return '<span class="tag">' + esc(t) + "</span>"; }).join("") +
        '<span class="grow"></span><span>' + esc(p.updated) + "</span></div></div>";
    }).join("");
  }
  function variablesOf(txt) {
    var out = [], seen = {}, m;
    var re = /\{\{\s*([A-Za-z0-9_\u4e00-\u9fa5]+)\s*\}\}/g;
    while ((m = re.exec(txt))) if (!seen[m[1]]) { seen[m[1]] = 1; out.push(m[1]); }
    return out;
  }
  function viewPrompts() {
    var p = getPrompt(state.selectedPrompt) || getPrompt("p-001");
    var h = [];
    h.push('<div class="split">');
    /* 左：列表 */
    h.push('<section class="card" style="overflow:hidden">');
    h.push('<div class="card-head" style="flex-direction:column;align-items:stretch;gap:9px">');
    h.push('<div class="between"><div class="card-title">' + ico("prompt") + '提示词库 <span class="badge b-muted">' + S.prompts.length + " / 21</span></div>");
    h.push('<button class="btn btn-sm" data-act="prompt-new">' + ico("plus") + "新建</button></div>");
    h.push('<div class="search">' + ICONS.search + '<input class="input" placeholder="全文搜索（FTS5）…" value="' + escA(state.promptQ) + '" data-bind="prompt-q" aria-label="搜索提示词"></div>');
    h.push('<div class="chips"><button class="chip' + (state.promptTag === "all" ? " is-on" : "") + '" data-act="prompt-tag" data-v="all">全部</button>' +
      promptTags().map(function (t) { return '<button class="chip' + (state.promptTag === t ? " is-on" : "") + '" data-act="prompt-tag" data-v="' + escA(t) + '">' + esc(t) + "</button>"; }).join("") + "</div>");
    h.push('<select class="select" data-bind="prompt-plat" aria-label="平台筛选"><option value="all">全部平台</option>' +
      S.PLATFORMS.map(function (x) { return '<option value="' + escA(x) + '"' + (state.promptPlat === x ? " selected" : "") + ">" + esc(x) + "</option>"; }).join("") + "</select>");
    h.push("</div>");
    h.push('<div class="card-body flush" id="prompt-list">' + promptListHTML() + "</div>");
    h.push('<div class="card-body" style="border-top:1px solid var(--line);display:flex;gap:8px"><button class="btn btn-sm grow" data-act="prompt-import">' + ico("down") + '从 CLAUDE.md / .cursorrules 反向导入</button></div>');
    h.push("</section>");

    /* 右：详情 */
    var content = promptContent(p);
    var vars = variablesOf(content);
    var dirty = state.patch[p.id] && state.patch[p.id].content != null && state.patch[p.id].content !== p.content;
    h.push('<section class="card">');
    h.push('<div class="card-head"><div><div class="card-title">' + esc(p.title) + ' <span class="tag">v' + promptVersion(p) + "</span>" +
      '<span class="badge b-amber" id="prompt-dirty"' + (dirty ? "" : " style=\"display:none\"") + ">未保存改动</span></div>");
    h.push('<div class="li-meta" style="margin-top:5px">' + p.platforms.map(function (x) { return '<span class="chip is-plain" style="height:20px;font-size:10.5px">' + esc(x) + "</span>"; }).join("") +
      '<span class="grow"></span><span>更新于 ' + esc(p.updated) + "</span></div></div>");
    h.push('<div class="row"><button class="btn btn-sm' + (dirty ? " btn-primary" : "") + '" data-act="prompt-save" id="btn-prompt-save">' + ico("check") + "保存快照</button>");
    h.push('<button class="btn btn-sm" data-act="prompt-copy">' + ico("copy") + "填参复制</button></div></div>");
    h.push('<div class="tabs">' +
      ["edit:编辑", "preview:预览", "versions:版本 (" + promptLog(p).length + ")"].map(function (t) {
        var kv = t.split(":");
        return '<button class="tab' + (state.promptTab === kv[0] ? " is-active" : "") + '" data-act="prompt-tab" data-v="' + kv[0] + '">' + kv[1] + "</button>";
      }).join("") + "</div>");
    h.push('<div class="card-body">');
    if (state.promptTab === "edit" || state.promptTab === "preview") {
      h.push('<div class="editor"><div class="editor-pane"><div class="ep-head"><span>Markdown 源码</span><span class="mono">' + estTokens(content) + " ≈token</span></div>" +
        '<textarea data-bind="prompt-content" data-id="' + p.id + '" spellcheck="false" aria-label="提示词内容">' + esc(content) + "</textarea></div>");
      h.push('<div class="editor-pane"><div class="ep-head"><span>实时预览</span></div><div class="ep-scroll md-body">' + md(content) + "</div></div></div>");
      h.push('<div class="var-panel"><div class="between"><div class="eyebrow">模板变量 · 复制时弹表单填值</div><span class="muted" style="font-size:11.5px">' + vars.length + ' 个占位符</span></div>');
      if (!vars.length) h.push('<p class="muted" style="font-size:12px;margin-top:8px">这条提示词没有 <span class="mono">{{variable}}</span> 占位符。</p>');
      vars.forEach(function (v) {
        h.push('<div class="var-row"><span class="var-name">{{' + esc(v) + "}</span>" +
          '<input class="input" placeholder="为 ' + esc(v) + ' 填值（复制时替换）" data-bind="var" data-var="' + escA(v) + '" data-id="' + p.id + '"></div>');
      });
      h.push("</div>");
    } else if (state.promptTab === "versions") {
      h.push('<div class="grid grid-2" style="align-items:start">');
      h.push('<div class="list">');
      promptLog(p).forEach(function (c) {
        h.push('<div class="list-item" data-act="prompt-diff" data-v="' + c.v + '"><div class="li-title">v' + c.v + (c.v === promptVersion(p) ? ' <span class="badge b-accent">当前</span>' : "") + "</div>" +
          '<div class="li-meta"><span>' + esc(c.at) + "</span></div><div style=\"font-size:12px;color:var(--ink-2);margin-top:3px\">" + esc(c.note) + "</div></div>");
      });
      h.push("</div>");
      var dv = state.diffVersion;
      var snap = dv && p.snaps && p.snaps[dv] != null ? p.snaps[dv] : null;
      if (snap != null) {
        var ops = diffLines(snap, content);
        var adds = ops.filter(function (o) { return o[0] === "add"; }).length;
        var dels = ops.filter(function (o) { return o[0] === "del"; }).length;
        h.push('<div><div class="between" style="margin-bottom:9px"><div class="eyebrow">v' + dv + " → v" + promptVersion(p) + ' 差异</div>' +
          '<span class="muted" style="font-size:11.5px"><span style="color:var(--jade)">+' + adds + '</span> / <span style="color:var(--crimson)">−' + dels + "</span></span></div>");
        h.push('<div class="diff"><div class="diff-head"><span>段级差异高亮</span><span>' + esc(p.title) + "</span></div>");
        var ln = 0, rn = 0;
        ops.forEach(function (o) {
          var cls = o[0] === "add" ? "add" : o[0] === "del" ? "del" : "ctx";
          var num = o[0] === "add" ? ++rn : o[0] === "del" ? ++ln : (++ln, ++rn);
          h.push('<div class="diff-line ' + cls + '"><span class="diff-g">' + num + '</span><span class="diff-c">' + (o[1] === "" ? " " : esc(o[1])) + "</span></div>");
        });
        h.push("</div>");
        h.push('<div class="row" style="margin-top:11px"><button class="btn btn-sm btn-danger" data-act="prompt-rollback" data-v="' + dv + '">' + ico("refresh") + "回滚到 v" + dv + '</button>' +
          '<span class="muted" style="font-size:11.5px">回滚会生成一个新版本，不改写历史</span></div></div>');
      } else {
        h.push('<div class="empty">' + ico("branch") + "<b>选择左侧任一版本查看差异</b><p>每次保存自动快照；差异按行高亮，可一键回滚。</p></div>");
      }
      h.push("</div>");
    }
    h.push("</div></section>");
    h.push("</div>");
    return h.join("");
  }

  /* ══════════════ 视图：术语库 M3 ══════════════ */
  function filteredTerms() {
    var q = state.termQ.trim().toLowerCase();
    if (!q) return S.terms.slice();
    return S.terms.filter(function (t) {
      return (t.zh + " " + t.en + " " + (t.aliases || []).join(" ") + " " + t.definition).toLowerCase().indexOf(q) >= 0;
    });
  }
  function termCard(t) {
    var on = state.termSel.indexOf(t.id) >= 0;
    return '<div class="pick' + (on ? " is-on" : "") + '" data-act="term-sel" data-id="' + t.id + '" style="cursor:pointer">' +
      '<div class="grow"><div class="pk-t">' + esc(t.zh) + ' <span class="muted" style="font-weight:400">' + esc(t.en) + "</span></div>" +
      '<div class="pk-d">' + esc(t.definition) + "</div></div>" +
      '<span class="badge ' + (on ? "b-accent" : "b-muted") + '">' + (on ? "已选" : "选取") + "</span></div>";
  }
  function termTableHTML() {
    var list = filteredTerms();
    var h = [];
    h.push('<table class="table"><thead><tr><th style="width:34px"></th><th>中文名</th><th>英文名</th><th>别名</th><th>定义摘要</th><th>路线站</th></tr></thead><tbody>');
    list.forEach(function (t) {
      var on = state.termSel.indexOf(t.id) >= 0;
      h.push('<tr><td><input type="checkbox" ' + (on ? "checked" : "") + ' data-act="term-sel" data-id="' + t.id + '" aria-label="选择 ' + escA(t.zh) + '"></td>' +
        '<td><a href="javascript:void(0)" data-act="term-open" data-id="' + t.id + '" style="color:var(--accent);font-weight:600">' + esc(t.zh) + "</a></td>" +
        '<td class="mono">' + esc(t.en) + "</td><td>" + (t.aliases || []).map(function (a) { return '<span class="tag">' + esc(a) + "</span>"; }).join(" ") + "</td>" +
        "<td>" + esc(t.definition) + "</td><td>" + (find(S.roadmap.filter(function (r) { return r.termIds.indexOf(t.id) >= 0; }), 0) ? "第 " + (S.roadmap.map(function (r) { return r.termIds.indexOf(t.id) >= 0; }).indexOf(true) + 1) + " 站" : "—") + "</td></tr>");
    });
    h.push("</tbody></table>");
    return h.join("");
  }
  function termCountHTML() { return filteredTerms().length + " / 109"; }
  function termHintHTML() { return state.termQ ? "命中「" + esc(state.termQ) + "」" : "预置种子词条 ≥ 100"; }
  function viewTerms() {
    var h = [];
    var sel = state.termSel;
    h.push('<div class="between wrap" style="margin-bottom:14px">');
    h.push('<div class="search" style="max-width:380px;flex:1;min-width:220px">' + ICONS.search + '<input class="input" placeholder="中文 / 英文 / 别名均可命中…" value="' + escA(state.termQ) + '" data-bind="term-q" aria-label="搜索术语"></div>');
    h.push('<div class="row wrap">');
    h.push('<div class="segmented"><button class="' + (state.termView === "roadmap" ? "is-on" : "") + '" data-act="term-view" data-v="roadmap">术语路线图</button>' +
      '<button class="' + (state.termView === "all" ? "is-on" : "") + '" data-act="term-view" data-v="all">全部词条</button></div>');
    h.push('<button class="btn btn-primary" data-act="term-gen"' + (sel.length ? "" : " disabled") + ">" + ico("file") + "生成 TERMS.md（" + sel.length + "）</button>");
    h.push('<button class="btn" data-act="term-new">' + ico("plus") + "新增词条</button></div></div>");

    if (state.termView === "roadmap") {
      h.push('<div class="callout" style="margin-bottom:14px"><span class="ci">' + ICONS.info + "</span><div><b>四站学习路线</b>（<span class=\"mono\">TERM_ROADMAP</span>）：F0 默认只展开第 1 站，其余折叠但可一键展开——渐进披露红线①：永不隐藏数据。</div></div>");
      h.push('<div class="grid grid-2">');
      S.roadmap.forEach(function (r, ri) {
        var open = ri === 0 || state.expert["/terms"];
        h.push('<section class="card"><div class="card-head"><div><div class="card-title">' + esc(r.name) + "</div>" +
          '<div class="li-meta" style="margin-top:3px">' + esc(r.desc) + "</div></div>" +
          '<span class="badge ' + (open ? "b-jade" : "b-muted") + '">' + r.termIds.length + " 条</span></div>");
        h.push('<div class="card-body" style="display:flex;flex-direction:column;gap:8px">');
        r.termIds.forEach(function (id) {
          var t = find(S.terms, id);
          if (t) h.push(termCard(t));
        });
        h.push("</div></section>");
      });
      h.push("</div>");
    } else {
      h.push('<section class="card"><div class="card-head"><div class="card-title">全部词条 <span class="badge b-muted" id="term-count">' + termCountHTML() + "</span></div>" +
        '<span class="muted" style="font-size:11.5px" id="term-hint">' + termHintHTML() + "</span></div>");
      h.push('<div class="card-body flush scroll-x" id="term-results">' + termTableHTML() + "</div></section>");
    }
    if (state.expert["/terms"]) {
      h.push('<section class="card mt"><div class="card-head"><div class="card-title">' + ico("settings") + '受控词表 / 批量操作 <span class="badge b-indigo">专家视图</span></div></div><div class="card-body">' +
        '<div class="row wrap"><button class="btn btn-sm" data-act="term-batch">批量改标签</button><button class="btn btn-sm" data-act="term-export">导出 JSON</button>' +
        '<button class="btn btn-sm" data-act="copy" data-text="openvibe terms export --format json">复制 CLI 命令</button>' +
        '<span class="muted" style="font-size:11.5px">专家路径：批量 + 键盘优先 + CLI 直接给</span></div></div></section>');
    }
    return h.join("");
  }
  function termDrawer(id) {
    var t = find(S.terms, id);
    if (!t) return "";
    var rel = t.related.map(function (r) { var x = find(S.terms, r); return x ? '<button class="chip" data-act="term-open" data-id="' + x.id + '">' + esc(x.zh) + "</button>" : ""; }).join("");
    var station = S.roadmap.map(function (r) { return r.termIds.indexOf(t.id) >= 0; }).indexOf(true);
    return '<div class="drawer-head"><div><div class="eyebrow">词条 · 第 ' + (station + 1) + ' 站</div>' +
      '<div class="modal-title" style="margin-top:6px">' + esc(t.zh) + '</div><div class="modal-sub mono">' + esc(t.en) + "</div></div>" +
      '<button class="icon-btn" data-act="close-overlay" aria-label="关闭">' + ICONS.x + "</button></div>" +
      '<div class="drawer-body"><dl class="kv">' +
      "<dt>中文名</dt><dd>" + esc(t.zh) + "</dd>" +
      "<dt>英文名</dt><dd class='mono'>" + esc(t.en) + "</dd>" +
      "<dt>别名</dt><dd>" + ((t.aliases || []).length ? t.aliases.map(function (a) { return '<span class="tag">' + esc(a) + "</span>"; }).join(" ") : "—") + "</dd>" +
      "<dt>定义</dt><dd>" + esc(t.definition) + "</dd>" +
      "<dt>示例</dt><dd>" + esc(t.example) + "</dd>" +
      "<dt>相关术语</dt><dd>" + (rel || "—") + "</dd>" +
      "<dt>来源</dt><dd>" + esc(t.source) + "</dd>" +
      "<dt>标签</dt><dd>" + t.tags.map(function (x) { return '<span class="tag">' + esc(x) + "</span>"; }).join(" ") + "</dd>" +
      "</dl>" +
      '<div class="sep"></div><div class="row wrap"><button class="btn btn-sm btn-primary" data-act="term-sel" data-id="' + t.id + '">' + (state.termSel.indexOf(t.id) >= 0 ? "取消选取" : "选入 TERMS.md") + "</button>" +
      '<button class="btn btn-sm" data-act="term-edit" data-id="' + t.id + '">编辑词条</button>' +
      '<button class="btn btn-sm" data-act="copy" data-text="' + escA(t.zh + " / " + t.en + " / " + t.definition) + '">复制定义</button></div>' +
      '<div class="callout" style="margin-top:16px"><span class="ci">' + ICONS.info + "</span><div>M3 只产出 <b>TERMS.md</b> 素材；「注入 AI 上下文」统一经 M6 标准包 + CLI 完成——Web 版无法直接写本地项目文件。</div></div>" +
      "</div>";
  }

  /* ══════════════ 视图：Skill 中心 M2 ══════════════ */
  function viewSkills() {
    var h = [];
    h.push('<div class="between wrap" style="margin-bottom:14px">');
    h.push('<div><div class="card-title" style="font-size:15px">' + ico("skill") + 'Skill 中心 <span class="badge b-muted">M2 瘦身版</span></div>' +
      '<div class="muted" style="font-size:12px;margin-top:4px">扫描 <span class="mono">~/.claude/skills</span>、<span class="mono">.claude/skills</span> 等目录，自动登记已有 SKILL.md</div></div>');
    h.push('<div class="row wrap"><button class="btn btn-primary" data-act="skill-scan">' + ico("refresh") + (state.scanned ? "重新扫描" : "扫描本地目录") + "</button>" +
      '<button class="btn" data-act="skill-register">' + ico("plus") + "手动登记</button></div></div>");

    if (!state.scanned) {
      h.push('<section class="card"><div class="empty">' + ico("skill") + "<b>还没有扫描过</b><p>点「扫描本地目录」：逐根目录隔离失败，一个坏输入（符号链接环 / 不可读文件）只降级为 warning，不会毁掉整次扫描。</p></div></section>");
    } else {
      h.push('<section class="card mb"><div class="card-head"><div class="card-title">扫描结果</div><span class="badge b-jade">4 个目录 · 6 个 skill</span></div><div class="card-body flush"><div class="list">');
      S.scanDirs.forEach(function (d) {
        h.push('<div class="list-item" style="cursor:default"><div class="li-title"><span class="mono">' + esc(d.path) + "</span> " +
          (d.state === "warn" ? '<span class="badge b-amber">warning</span>' : '<span class="badge b-jade">ok</span>') + "</div>" +
          '<div class="li-meta">发现 ' + d.found + " 个" + (d.warn ? " · " + esc(d.warn) : "") + "</div></div>");
      });
      h.push("</div></div></section>");
    }
    h.push('<section class="card"><div class="card-head"><div class="card-title">Skill 台账 <span class="badge b-muted">' + S.skills.length + "</span></div>" +
      '<span class="muted" style="font-size:11.5px">指纹 SHA-256 比对同名 skill；上游 6 个月未更新即标 stale</span></div>');
    h.push('<div class="card-body flush scroll-x"><table class="table"><thead><tr><th>名称</th><th>来源</th><th>版本</th><th>SHA-256</th><th>已分发目标</th><th>状态</th><th></th></tr></thead><tbody>');
    S.skills.forEach(function (s) {
      h.push("<tr><td class='mono' style='font-weight:600'>" + esc(s.name) + "</td><td>" + esc(s.source) + "</td><td class='mono'>" + esc(s.version) + "</td>" +
        "<td class='mono muted'>" + esc(s.sha256.slice(0, 16)) + "…</td><td>" + (s.targets.length ? s.targets.map(function (t) { return '<span class="tag">' + esc(t) + "</span>"; }).join(" ") : '<span class="muted">未分发</span>') + "</td>" +
        '<td><span class="badge ' + (s.status === "stale" ? "b-amber" : "b-jade") + '">' + (s.status === "stale" ? "上游停滞" : "活跃") + "</span></td>" +
        '<td><button class="btn btn-sm" data-act="skill-distribute" data-id="' + escA(s.name) + '">分发</button></td></tr>');
    });
    h.push("</tbody></table></div></section>");
    if (state.expert["/skills"]) {
      h.push('<section class="card mt"><div class="card-head"><div class="card-title">' + ico("settings") + 'CLI / 原始登记 <span class="badge b-indigo">专家视图</span></div></div><div class="card-body">' +
        '<div class="row wrap"><button class="btn btn-sm" data-act="copy" data-text="openvibe scan --dirs ~/.claude/skills,~/projects/.claude/skills">复制 scan 命令</button>' +
        '<button class="btn btn-sm" data-act="copy" data-text="openvibe skill distribute spec-kit-conventions --to claude-code,cursor">复制分发命令</button>' +
        '<span class="muted" style="font-size:11.5px">多平台分发 / 生态源导入属 P1 完整版（Phase 2）</span></div></div></section>');
    }
    return h.join("");
  }

  /* ══════════════ 视图：项目与流程 M5 ══════════════ */
  function getProject(id) { return find(S.projects, id || state.currentProject) || S.projects[0]; }
  function projectTasks(p) {
    if (state.kanban[p.id]) return state.kanban[p.id];
    var kb = { todo: [], doing: [], done: [] };
    p.tasks.forEach(function (t) { kb[t.status].push(t); });
    return kb;
  }
  function viewProjects() {
    var p = getProject();
    var tpl = find(S.flowTemplates, p.templateId);
    var st = tpl.stages[p.stageIndex];
    var h = [];
    h.push('<div class="between wrap" style="margin-bottom:14px">');
    h.push('<div class="row wrap">');
    S.projects.forEach(function (x) {
      h.push('<button class="chip' + (x.id === p.id ? " is-on" : "") + '" data-act="proj-open" data-id="' + x.id + '">' + esc(x.name) + "</button>");
    });
    h.push("</div>");
    h.push('<div class="row wrap"><button class="btn btn-sm" data-act="proj-new">' + ico("plus") + "新建项目</button>" +
      '<button class="btn btn-sm" data-act="pack-wizard">' + ico("pack") + "注入标准包</button></div></div>");

    /* 阶段条 */
    h.push('<section class="card"><div class="card-head"><div><div class="card-title">' + esc(tpl.name) + ' <span class="badge b-muted">' + tpl.stages.length + " 阶段 / " + tpl.stages.reduce(function (a, s) { return a + s.checklist.length; }, 0) + " 检查项</span></div>" +
      '<div class="li-meta" style="margin-top:4px"><span class="mono">' + esc(p.path) + "</span><span>·</span><span>锁定包 " + esc(p.pack.name) + "@" + esc(p.pack.version) + "</span></div></div>" +
      '<span class="badge ' + (p.health === "健康" ? "b-jade" : "b-amber") + '">' + p.health + "</span></div>");
    h.push('<div class="card-body"><div class="stagebar">');
    tpl.stages.forEach(function (s, i) {
      var cls = i < p.stageIndex ? "is-done" : i === p.stageIndex ? "is-cur" : "";
      var done = s.checklist.filter(function (c, ci) { return state.checks[p.id + ":" + i + ":" + ci]; }).length;
      h.push('<button class="stage-node ' + cls + '" data-act="stage-goto" data-i="' + i + '"><div class="sn-i">' + pad(i + 1) + "</div><div class=\"sn-t\">" + esc(s.name) + "</div><div class=\"sn-c\">清单 " + done + "/" + s.checklist.length + "</div></button>");
    });
    h.push("</div>");
    h.push('<div class="callout" style="margin-top:14px"><span class="ci">' + ICONS.info + "</span><div>" + esc(p.note) + "</div></div></div></section>");

    /* 清单 + 看板/日志 */
    h.push('<div class="grid grid-side mt">');
    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("check") + esc(st.name) + ' · 检查清单</div>' +
      '<span class="badge b-accent">' + st.checklist.filter(function (c, ci) { return state.checks[p.id + ":" + p.stageIndex + ":" + ci]; }).length + "/" + st.checklist.length + "</span></div>");
    h.push('<div class="card-body"><div class="bar mb"><i style="width:' + (st.checklist.filter(function (c, ci) { return state.checks[p.id + ":" + p.stageIndex + ":" + ci]; }).length / st.checklist.length * 100) + '%"></i></div>');
    st.checklist.forEach(function (c, ci) {
      var on = !!state.checks[p.id + ":" + p.stageIndex + ":" + ci];
      h.push('<label class="row" style="align-items:flex-start;gap:9px;padding:7px 0;cursor:pointer;' + (ci ? "border-top:1px dashed var(--line);" : "") + '">' +
        '<input type="checkbox" ' + (on ? "checked" : "") + ' data-act="check-toggle" data-i="' + ci + '" style="margin-top:3px;accent-color:var(--accent)">' +
        '<span style="font-size:12.5px;' + (on ? "color:var(--ink-3);text-decoration:line-through" : "") + '">' + esc(c) + "</span></label>");
    });
    h.push('<div class="sep"></div><div class="eyebrow">本阶段产物</div><div class="chips" style="margin-top:7px">' +
      st.artifacts.map(function (a) { return '<span class="chip">' + ico("file") + esc(a) + "</span>"; }).join("") + "</div>");
    h.push('<div class="row" style="margin-top:14px"><button class="btn btn-sm btn-primary" data-act="stage-advance">推进到下一阶段</button>' +
      '<button class="btn btn-sm" data-act="flow-run">运行问参式流程</button></div></div></section>');

    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("project") + '任务看板</div>' +
      '<div class="segmented"><button class="' + (state.projTab === "board" ? "is-on" : "") + '" data-act="proj-tab" data-v="board">看板</button>' +
      '<button class="' + (state.projTab === "logs" ? "is-on" : "") + '" data-act="proj-tab" data-v="logs">开发日志</button></div></div>');
    h.push('<div class="card-body">');
    if (state.projTab === "board") {
      var kb = projectTasks(p);
      var cols = [
        { k: "todo", n: "待办" }, { k: "doing", n: "进行" }, { k: "done", n: "完成" }
      ];
      h.push('<div class="kanban">');
      cols.forEach(function (c) {
        h.push('<div class="kb-col" data-col="' + c.k + '"><div class="kb-head"><span>' + c.n + '</span><span class="n">' + kb[c.k].length + "</span></div>");
        h.push('<div class="kb-cards">');
        kb[c.k].forEach(function (t) {
          h.push('<div class="kb-card" draggable="true" data-task="' + t.id + '"><div class="kc-t">' + esc(t.title) + '</div><div class="kc-m"><span class="tag">' + esc(t.stage) + "</span>" +
            (c.k === "done" ? '<span class="badge b-jade">完成</span>' : "") + "</div></div>");
        });
        h.push("</div></div>");
      });
      h.push("</div>");
      h.push('<div class="row" style="margin-top:12px"><button class="btn btn-sm" data-act="task-add">' + ico("plus") + "添加任务</button>" +
        '<span class="muted" style="font-size:11.5px">任务挂到阶段 · 可拖拽换列</span></div>');
    } else {
      h.push('<div class="between" style="margin-bottom:11px"><div class="eyebrow">DEV-LOG / CHECK-LOG · 编号递增 + 时间戳 + 关联文件 + 验证记录</div>' +
        '<button class="btn btn-sm btn-primary" data-act="log-new">' + ico("plus") + "追加记录</button></div>");
      var logs = (state.extraLogs[p.id] || []).concat(p.logs);
      logs.forEach(function (l) {
        h.push('<div style="padding:11px 0;' + (l !== logs[0] ? "border-top:1px dashed var(--line);" : "") + '">' +
          '<div class="row wrap"><span class="badge ' + (l.type === "CHECK" ? "b-indigo" : "b-accent") + '">' + l.type + "-" + pad(l.no) + "</span>" +
          '<span class="muted mono" style="font-size:11.5px">' + esc(l.at) + "</span><span class=\"grow\"></span>" +
          '<span class="tag">' + esc(l.files) + "</span></div>" +
          '<p style="font-size:12.5px;color:var(--ink-2);margin-top:6px;line-height:1.65">' + esc(l.body) + "</p>" +
          '<div class="row wrap" style="margin-top:6px"><span class="tag">命令 ' + esc(l.cmd) + "</span><span class=\"tag\">结果 " + esc(l.result) + "</span>" +
          '<button class="btn btn-sm btn-ghost" data-act="log-reflow" data-no="' + l.no + '">存为资产候选</button></div></div>');
      });
    }
    h.push("</div></section></div>");
    return h.join("");
  }

  /* ══════════════ 视图：标准包 M6 ══════════════ */
  function packCard(pk) {
    var m = pk.manifest;
    var n = m.promptIds.length + m.skillIds.length + m.termIds.length;
    var tpl = find(S.flowTemplates, m.flowTemplateId);
    var density = Math.round(pk.tokens / n);
    return '<section class="card"><div class="card-head"><div><div class="card-title">' + esc(pk.name) + ' <span class="tag">v' + esc(pk.version) + "</span>" +
      (pk.builtin ? ' <span class="badge b-indigo">预置</span>' : ' <span class="badge b-muted">自建</span>') + "</div>" +
      '<div class="li-meta" style="margin-top:5px">提示词 ' + m.promptIds.length + " · Skill " + m.skillIds.length + " · 术语 " + m.termIds.length + " · 流程模板 " + esc(tpl.name) + "</div></div>" +
      '<span class="badge ' + (density > 1500 ? "b-amber" : "b-jade") + '">密度 ' + density + "</span></div>" +
      '<div class="card-body"><div class="grid grid-3" style="gap:10px">' +
      '<div><div class="eyebrow">体量</div><div class="num" style="font-size:18px">' + pk.sizeKb.toFixed(1) + ' kB</div></div>' +
      '<div><div class="eyebrow">≈token（中文感知）</div><div class="num" style="font-size:18px">' + pk.tokens.toLocaleString() + "</div></div>" +
      '<div><div class="eyebrow">产物文件</div><div class="num" style="font-size:18px">' + (m.skillIds.length + 3) + "</div></div></div>" +
      '<div class="row wrap" style="margin-top:14px"><button class="btn btn-sm btn-primary" data-act="pack-inject" data-id="' + pk.id + '">' + ico("pack") + "注入（dry-run）</button>" +
      '<button class="btn btn-sm" data-act="pack-detail" data-id="' + pk.id + '">' + ico("eye") + "看 manifest</button>" +
      '<button class="btn btn-sm" data-act="copy" data-text="openvibe sync &lt;project-path&gt; --pack ' + escA(pk.name) + '">复制 sync 命令</button></div></div></section>';
  }
  function viewPacks() {
    var h = [];
    h.push('<div class="between wrap" style="margin-bottom:14px">');
    h.push('<div><div class="card-title" style="font-size:15px">' + ico("pack") + '标准包与注入 <span class="badge b-muted">价值出口</span></div>' +
      '<div class="muted" style="font-size:12px;margin-top:4px">产物为纯 Markdown / YAML：git 友好、工具无关、零锁定</div></div>');
    h.push('<div class="row wrap"><button class="btn btn-primary" data-act="pack-wizard">' + ico("plus") + "组包向导</button>" +
      '<button class="btn" data-act="verify-run">' + ico("shield") + "运行 verify</button></div></div>");

    h.push('<div class="grid grid-2">');
    S.packs.forEach(function (pk) { h.push(packCard(pk)); });
    h.push("</div>");

    /* 三层保证 */
    h.push('<section class="card mt"><div class="card-head"><div class="card-title">' + ico("shield") + '三层保证 <span class="badge b-muted">dry-run 默认 · 自动备份 · 显式确认 · 可自证</span></div>' +
      '<span class="badge ' + (state.verify === "CONSISTENT" ? "b-jade" : "b-amber") + '" id="verify-inline">' + state.verify + "</span></div>");
    h.push('<div class="card-body"><div class="grid grid-3">' +
      [["L1 完整性", "每一次写都有前置备份，备份可定位", ".openvibe/backup/<utc>/"],
       ["L2 可恢复性", "中断后能回到一致态；verify 四态判定", "CONSISTENT / PARTIAL / STALE_LOCK / ORPHAN"],
       ["L3 可解释性", "看得懂「为什么是这个决策」", "每文件一行：三方哈希对照"]].map(function (x) {
        return '<div style="padding:13px;border:1px solid var(--line);border-radius:var(--r-md);background:var(--surface-2)"><div class="eyebrow">' + x[0] + "</div>" +
          '<div style="font-size:12.5px;margin-top:5px;color:var(--ink-2)">' + x[1] + '</div><div class="mono" style="font-size:10.5px;color:var(--ink-3);margin-top:7px">' + esc(x[2]) + "</div></div>";
      }).join("") + "</div></div></section>");

    /* adapter 矩阵 */
    h.push('<div class="grid grid-2 mt">');
    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("branch") + '平台 adapter（6 个专用）</div></div><div class="card-body flush scroll-x"><table class="table"><thead><tr><th>平台</th><th>产物文件</th><th>契约</th></tr></thead><tbody>');
    S.adapters.forEach(function (a) {
      h.push("<tr><td style='font-weight:600'>" + esc(a.name) + "</td><td class='mono'>" + a.files.map(esc).join("<br>") + "</td><td class='muted'>" + esc(a.note) + "</td></tr>");
    });
    h.push("</tbody></table></div></section>");
    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("info") + '兼容矩阵（AGENTS.md 覆盖）</div></div><div class="card-body flush scroll-x"><table class="table"><thead><tr><th>平台</th><th>经</th><th>证据强度</th></tr></thead><tbody>');
    S.compatMatrix.forEach(function (c) {
      h.push("<tr><td style='font-weight:600'>" + esc(c.name) + "</td><td class='mono'>" + esc(c.via) + "</td><td class='muted'>" + esc(c.strength) + "</td></tr>");
    });
    h.push("</tbody></table></div>");
    h.push('<div class="card-body" style="border-top:1px solid var(--line)"><div class="callout"><span class="ci">' + ICONS.warn + "</span><div>平台目录契约频繁变化（高概率 / 高影响）⇒ adapter 层隔离；标准包纯 Markdown 的底线不失效。</div></div></div></section>");
    h.push("</div>");
    return h.join("");
  }

  /* ══════════════ 视图：成长与统计 ══════════════ */
  function viewGrowth() {
    var h = [];
    var st = S.stats;
    h.push('<div class="grid grid-side">');
    h.push('<div>');
    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("growth") + '成长阶段向量</div>' +
      '<button class="btn btn-sm" data-act="stage-reset">重置阶段</button></div>');
    h.push('<div class="card-body flush"><table class="table"><thead><tr><th>模块</th><th>阶段</th><th>毕业信号</th><th></th></tr></thead><tbody>');
    S.moduleStages.forEach(function (m) {
      var cur = state.stageOverride[m.route] != null ? state.stageOverride[m.route] : m.stage;
      var sd = S.stageDefs[cur];
      h.push("<tr><td style='font-weight:600'>" + esc(m.module) + "</td><td><span class=\"badge b-accent\">" + sd.code + " " + esc(sd.name) + "</span></td>" +
        "<td class='muted' style='font-size:11.5px'>" + esc(m.next) + "</td>" +
        '<td><button class="btn btn-sm btn-ghost" data-act="stage-cycle" data-route="' + m.route + '">切换视图</button></td></tr>');
    });
    h.push("</tbody></table></div></section>");

    h.push('<section class="card mt"><div class="card-head"><div class="card-title">' + ico("shield") + '渐进披露五红线</div><span class="badge b-indigo">D28</span></div><div class="card-body">');
    S.redlines.forEach(function (r, i) {
      h.push('<div class="redline"><span class="rl-i">' + (i + 1) + "</span><span>" + esc(r) + "</span></div>");
    });
    h.push('<div class="callout" style="margin-top:14px"><span class="ci">' + ICONS.info + "</span><div>阶段定义在「用户 × 资产类型 × 任务」上，<b>不是账号属性</b>——同一个人在术语上可以是 F2，在 Skill 上还是 F0。</div></div>");
    h.push("</div></section>");
    h.push("</div>");

    h.push('<div>');
    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("gauge") + '飞轮面板 <span class="badge b-muted">本地统计 · 不上报</span></div></div><div class="card-body">');
    h.push('<div class="grid grid-2" style="gap:10px">' +
      '<div class="stat" style="box-shadow:none"><div class="st-v">' + st.loops + '</div><div class="st-k">完整飞轮圈数</div></div>' +
      '<div class="stat" style="box-shadow:none"><div class="st-v">' + st.injections + '</div><div class="st-k">注入次数</div></div>' +
      '<div class="stat" style="box-shadow:none"><div class="st-v">' + st.reflows + '</div><div class="st-k">回流条数</div></div>' +
      '<div class="stat" style="box-shadow:none"><div class="st-v">' + (st.terms + st.prompts + st.skills) + '</div><div class="st-k">资产总数</div></div></div>');
    h.push('<div class="sep"></div><div class="between wrap"><div class="eyebrow">回流候选（M4 · Phase 2）</div>' +
      '<button class="btn btn-sm btn-ghost" data-act="goto" data-route="/playbooks">打开登记管道</button></div>' +
      '<p class="muted" style="font-size:11.5px;margin-top:6px">候选来自日志与回顾，必须能指回原始事件；当前版本只登记，不做创建与分发。</p>');
    h.push('<div class="sep"></div><div class="eyebrow">有效上下文密度（D1）</div>' +
      '<div class="row" style="margin-top:7px"><div class="bar grow"><i style="width:38%"></i></div><span class="num" style="font-size:12px">41 → 12 token/资产</span></div>' +
      '<p class="muted" style="font-size:11.5px;margin-top:7px">默认包两次组装的密度差可复算，并可归因到具体资产（哪 3 条最占地方）。</p>');
    h.push('<div class="sep"></div><div class="eyebrow">首次见效时间（D2）</div>' +
      '<div class="row" style="margin-top:7px"><span class="num" style="font-size:20px">3 分 12 秒</span><span class="badge b-jade">≤ 5 分钟验收线内</span></div>' +
      '<p class="muted" style="font-size:11.5px;margin-top:6px">首启事件 → injection_confirmed 的墙钟时间差，进成长面板。</p>');
    h.push("</div></section>");

    h.push('<section class="card mt"><div class="card-head"><div class="card-title">' + ico("clock") + '本机事件台账 <span class="badge b-muted">append-only · 可清空 · 不出网</span></div>' +
      '<button class="btn btn-sm btn-danger" data-act="events-clear">' + ico("trash") + "清空</button></div>");
    h.push('<div class="card-body" style="padding-bottom:10px"><div class="chips">' +
      '<button class="chip' + (state.ledgerFilter === "all" ? " is-on" : "") + '" data-act="events-filter" data-k="all">全部 ' + state.events.length + "</button>" +
      Object.keys(S.eventKinds).map(function (k) {
        var n = state.events.filter(function (e) { return e.kind === k; }).length;
        if (!n) return "";
        return '<button class="chip' + (state.ledgerFilter === k ? " is-on" : "") + '" data-act="events-filter" data-k="' + k + '">' + S.eventKinds[k] + " " + n + "</button>";
      }).join("") + "</div></div>");
    h.push('<div class="card-body flush" style="padding-top:0"><div class="ledger">');
    var evs = state.ledgerFilter === "all" ? state.events : state.events.filter(function (e) { return e.kind === state.ledgerFilter; });
    if (!evs.length) h.push('<div class="empty"><b>该类目下没有事件</b></div>');
    evs.forEach(function (e) {
      h.push('<div class="ledger-row"><span class="muted">' + esc(e.at) + '</span><span class="ledger-kind">' + esc(S.eventKinds[e.kind] || e.kind) + '</span><span>' + esc(e.subject) + '</span><span class="tag">' + esc(e.kind) + "</span></div>");
    });
    h.push("</div></div>");
    h.push('<div class="card-body" style="border-top:1px solid var(--line)"><div class="callout"><span class="ci">' + ICONS.shield + "</span><div><b>与遥测正交，不是替代</b>：台账是本机数据，无网络路径；D3 的三类白名单、五段体与「机器标识不带出」承诺一字不改。</div></div></div></section>");
    h.push("</div></div>");
    return h.join("");
  }

  /* ══════════════ 视图：设置 ══════════════ */
  function viewSettings() {
    var h = [];
    h.push('<div class="grid grid-2">');
    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("shield") + '隐私与数据</div></div><div class="card-body">');
    h.push('<div class="between" style="padding:10px 0;border-bottom:1px dashed var(--line)"><div><div style="font-size:13px;font-weight:600">本机统计</div>' +
      '<div class="muted" style="font-size:11.5px;margin-top:2px">事件台账只写在 <span class="mono">~/.openvibe/data/openvibe.db</span>，永不上报</div></div>' +
      '<label class="switch"><input type="checkbox" ' + (state.localStats ? "checked" : "") + ' data-act="toggle-local"><span></span></label></div>');
    h.push('<div class="between" style="padding:10px 0"><div><div style="font-size:13px;font-weight:600">匿名遥测</div>' +
      '<div class="muted" style="font-size:11.5px;margin-top:2px">默认关 · 事件清单公开三类 · 可随时关 · 关闭即零外联</div></div>' +
      '<label class="switch"><input type="checkbox" ' + (state.telemetry ? "checked" : "") + ' data-act="toggle-telemetry"><span></span></label></div>');
    h.push('<div class="callout"><span class="ci">' + ICONS.info + "</span><div>白名单三类：<b>注入成功</b> / <b>流程模板选用</b> / <b>活跃项目去标识计数</b>。不含任何路径、内容或用户标识。首次注入成功后一次性询问，拒绝后本地标记永不再问。</div></div>");
    h.push('<div class="row wrap" style="margin-top:12px"><button class="btn btn-sm" data-act="events-clear">清空本机事件台账</button>' +
      '<button class="btn btn-sm" data-act="copy" data-text="openvibe telemetry off">复制关闭命令</button></div>');
    h.push("</div></section>");

    h.push('<section class="card"><div class="card-head"><div class="card-title">' + ico("settings") + '外观与视图</div></div><div class="card-body">');
    h.push('<div class="between" style="padding-bottom:12px;border-bottom:1px dashed var(--line)"><div><div style="font-size:13px;font-weight:600">主题</div>' +
      '<div class="muted" style="font-size:11.5px;margin-top:2px">设计令牌化后支持暗色（P2）</div></div>' +
      '<div class="segmented"><button class="' + (state.theme === "light" ? "is-on" : "") + '" data-act="theme" data-v="light">纸</button>' +
      '<button class="' + (state.theme === "dark" ? "is-on" : "") + '" data-act="theme" data-v="dark">墨</button></div></div>');
    h.push('<div class="between" style="padding-top:12px"><div><div style="font-size:13px;font-weight:600">当前模块视图</div>' +
      '<div class="muted" style="font-size:11.5px;margin-top:2px">' + esc((TITLES[state.route] || ["", ""])[0]) + " · 阶段 " + (S.stageDefs[routeStage(state.route)] || S.stageDefs[0]).code + "</div></div>" +
      '<div class="segmented"><button class="' + (state.expert[state.route] ? "" : "is-on") + '" data-act="expert-set" data-v="0">渐进</button>' +
      '<button class="' + (state.expert[state.route] ? "is-on" : "") + '" data-act="expert-set" data-v="1">专家</button></div></div>');
    h.push('<div class="callout" style="margin-top:14px"><span class="ci">' + ICONS.eye + "</span><div>渐进披露只重排与预填，<b>永不隐藏数据</b>；专家视图按模块记忆。</div></div>");
    h.push("</div></section>");
    h.push("</div>");

    h.push('<section class="card mt"><div class="card-head"><div class="card-title">' + ico("bolt") + 'CLI 命令 <span class="badge b-muted">注入是唯一物理通道</span></div></div><div class="card-body flush">');
    S.cliRefs.forEach(function (c, i) {
      h.push('<div class="between" style="padding:11px 16px;' + (i ? "border-top:1px dashed var(--line);" : "") + '"><div class="grow"><div class="mono" style="font-size:12px">' + esc(c.cmd) + "</div>" +
        '<div class="muted" style="font-size:11.5px;margin-top:3px">' + esc(c.desc) + "</div></div>" +
        '<button class="btn btn-sm" data-act="copy" data-text="' + escA(c.cmd) + '">' + ico("copy") + "</button></div>");
    });
    h.push("</div></section>");

    h.push('<section class="card mt"><div class="card-head"><div class="card-title">' + ico("info") + '关于</div></div><div class="card-body"><dl class="kv">' +
      "<dt>产品</dt><dd>OpenVibe / 灵典 · v0.2.0（重构版开档）</dd>" +
      "<dt>定位</dt><dd>意图 → 项目上下文的编译器 + 分发器 + 反馈回路</dd>" +
      "<dt>形态</dt><dd>自部署 Web SPA + 本地 CLI（硬依赖）· 只听回环</dd>" +
      "<dt>存储</dt><dd>SQLite（FTS5 全文搜索）· 单用户本地优先</dd>" +
      "<dt>平台</dt><dd>macOS / Linux / Windows 三平台硬要求，CI 矩阵</dd>" +
      "<dt>协议</dt><dd>Apache-2.0（代码与种子内容同协议）</dd>" +
      "<dt>模块</dt><dd>M1 提示词库 · M2 Skill 中心 · M3 术语库 · M4 技巧库（Phase 2）· M5 项目与流程 · M6 标准包与注入 · M7 团队（Phase 2）</dd>" +
      "</dl></div></section>");
    return h.join("");
  }

  /* ══════════════ M4 技巧库（Phase 2 · 只做回流候选登记） ══════════════ */
  function reflowStateOf(r) { return state.reflow[r.id] || r.state; }
  var RF_COLS = [
    { key: "candidate", title: "候选池", desc: "从日志与回顾里捞出来的模式，等人认领" },
    { key: "reviewing", title: "评审中", desc: "有人在判断它该进哪个模块" },
    { key: "archived", title: "已关闭", desc: "已有更好解法或被 CLI 覆盖" },
    { key: "rejected", title: "已驳回", desc: "与既有契约冲突，明确不做" }
  ];
  function reflowColHTML(key, title, desc) {
    var list = S.reflows.filter(function (r) { return reflowStateOf(r) === key; });
    var h = [];
    h.push('<section class="card"><div class="card-head"><div class="card-title">' + esc(title) + ' <span class="badge b-muted">' + list.length + "</span></div></div>");
    h.push('<div class="card-body"><div class="muted" style="font-size:11.5px;margin-bottom:10px">' + esc(desc) + "</div>");
    if (!list.length) {
      h.push('<div class="empty">' + ico("info") + "<b>这一列是空的</b><span>把候选拖去别的列，或从日志里再捞一条</span></div>");
    }
    list.forEach(function (r) {
      h.push('<div class="rf-card"><div class="between wrap" style="gap:6px"><div class="rf-t grow">' + esc(r.title) + "</div>" +
        '<span class="badge ' + (key === "rejected" ? "b-crimson" : key === "archived" ? "b-muted" : key === "reviewing" ? "b-amber" : "b-indigo") + '">' + esc(key) + "</span></div>" +
        '<div class="rf-m">' + esc(r.from) + " · 命中 " + r.hits + " 次 · 归属 " + esc(r.owner) + "</div>" +
        '<div class="rf-e">证据：' + esc(r.evidence) + "</div>" +
        '<div class="rf-e">去向：' + esc(r.target) + "</div>" +
        '<div class="rf-a">');
      if (key !== "reviewing") h.push('<button class="btn btn-sm" data-act="reflow-state" data-id="' + r.id + '" data-v="reviewing">送审</button>');
      if (key !== "archived") h.push('<button class="btn btn-sm" data-act="reflow-state" data-id="' + r.id + '" data-v="archived">关闭</button>');
      if (key !== "rejected") h.push('<button class="btn btn-sm" data-act="reflow-state" data-id="' + r.id + '" data-v="rejected">驳回</button>');
      if (key === "rejected" || key === "archived") h.push('<button class="btn btn-sm" data-act="reflow-state" data-id="' + r.id + '" data-v="candidate">重开</button>');
      h.push('<button class="btn btn-sm" data-act="reflow-src" data-id="' + r.id + '">' + ico("search") + "来源</button></div></div>");
    });
    h.push("</div></section>");
    return h.join("");
  }
  function reflowBoardHTML() {
    return '<div class="grid grid-4">' + RF_COLS.map(function (c) { return reflowColHTML(c.key, c.title, c.desc); }).join("") + "</div>";
  }
  function viewPlaybooks() {
    var h = [];
    var gaps = [
      ["输入输出契约", "候选从哪来（事件类型）、以什么形态流出（资产草稿 / 任务）", "未写"],
      ["判定规则", "什么算「值得回流的模式」：频次阈值、影响面、可复用性", "未写"],
      ["与 M2 / M3 的边界", "技巧与 Skill、术语的职责划分，避免三处都能放", "未写"],
      ["退场策略", "候选过期如何处理，归档与删除的判定", "未写"],
      ["验收标准", "Phase 2 上线前必须可机判或一眼判的条件", "未写"]
    ];
    h.push('<section class="card mb"><div class="card-head"><div><div class="card-title">' + ico("playbook") + 'M4 技巧库 <span class="badge b-amber">Phase 2 · 未开 spec</span></div>' +
      '<div class="li-meta" style="margin-top:3px">No spec, no task —— 本页只做回流候选的登记与流转，不提供技巧的创建、编辑与分发</div></div>' +
      '<span class="badge b-muted">' + S.reflows.length + " 条候选</span></div>");
    h.push('<div class="card-body">');
    h.push('<div class="warnbar"><span class="ci">' + ICONS.warn + "</span><div><b>为什么锁着</b>：D22 勘误明确 M4 归 Phase 2，进入实施前须先补 spec。这里展示的是登记管道的形状，不是功能承诺。</div></div>");
    h.push('<div class="grid grid-2 mt">');
    gaps.forEach(function (g) {
      h.push('<div class="spec-gap"><span class="sg-i">' + ICONS.file + "</span><div class=\"grow\"><div class=\"between wrap\" style=\"gap:6px\"><b style=\"font-size:12.5px\">" + esc(g[0]) + "</b>" +
        '<span class="badge b-muted">' + esc(g[2]) + "</span></div>" +
        '<div class="muted" style="font-size:11.5px;margin-top:4px">' + esc(g[1]) + "</div></div>" +
        '<button class="btn btn-sm" data-act="spec-claim" data-id="' + escA(g[0]) + '">认领</button></div>');
    });
    h.push("</div>");
    h.push('<div class="row wrap mt"><button class="btn btn-sm" data-act="copy" data-text="openvibe playbooks --help">复制 CLI 占位命令</button>' +
      '<span class="muted" style="font-size:11.5px">当前版本 CLI 会返回「M4 未实现（Phase 2）」</span></div>');
    h.push("</div></section>");
    h.push('<div class="between wrap" style="margin-bottom:12px"><div><div class="eyebrow">回流候选管道</div>' +
      '<div class="muted" style="font-size:11.5px">候选必须能指回原始事件，否则不可评审（见术语「回流」）</div></div>' +
      '<button class="btn btn-sm" data-act="reflow-new">' + ico("plus") + "从最近日志捞一条</button></div>");
    h.push('<div id="reflow-board">' + reflowBoardHTML() + "</div>");
    return h.join("");
  }

  /* ══════════════ CLI 终端实验室 ══════════════ */
  var cli = { lines: [], hist: [], hi: -1, pending: null, last: null };
  function cliPush(text, cls) { cli.lines.push({ t: text, c: cls || "" }); if (cli.lines.length > 400) cli.lines.splice(0, cli.lines.length - 400); }
  function cliEcho(cmd) { cliPush("$ " + cmd, "cl-acc"); }
  function cliAuto(text) {
    if (/^\s*$/.test(text)) return "";
    if (/✓|一致|完成|可用|已生成|已登记/.test(text)) return "cl-ok";
    if (/!|警告|DRIFT|BLOCKING|不一致|需决策|不可撤销|冲突/.test(text)) return "cl-warn";
    if (/✗|失败|未实现|错误/.test(text)) return "cl-err";
    if (/^OpenVibe|^用法|^[系资流交系]/.test(text)) return "cl-h";
    return "";
  }
  function cliOutHTML() {
    if (!cli.lines.length) {
      cliPush("OpenVibe 灵典 v0.2.0 · 终端实验室", "cl-h");
      cliPush("", "");
      cliPush("这是 CLI 的回放环境：左侧点一条命令，或直接输入后回车。", "cl-dim");
      cliPush("所有破坏性操作默认 dry-run；注入与回滚在真实产品里只能由 CLI 完成。", "cl-dim");
      cliPush("", "");
      cliPush("输入 openvibe --help 查看全部命令。", "cl-dim");
    }
    return cli.lines.map(function (l) {
      var c = l.c || cliAuto(l.t);
      return '<div class="' + c + '">' + esc(l.t || " ") + "</div>";
    }).join("");
  }
  function cliRiskBadge() {
    if (!cli.last) return '<span class="risk risk-safe">就绪</span>';
    return '<span class="risk risk-' + cli.last.risk + '">' + (cli.last.risk === "danger" ? "破坏性" : cli.last.risk === "warn" ? "需决策" : "只读") + "</span>";
  }
  function cliRun(raw) {
    var cmd = String(raw || "").trim();
    if (!cmd) return;
    cli.hist.unshift(cmd);
    if (cli.hist.length > 40) cli.hist.pop();
    cli.hi = -1;
    cliEcho(cmd);
    if (cli.pending) {
      var p = cli.pending;
      cli.pending = null;
      if (p === "clean") {
        if (/^y(es)?$/i.test(cmd)) {
          cliPush("删除 CHECKLIST.md · skills/legacy-lint.md（已备份）", "cl-warn");
          cliPush("更新 lock.json → 4 个受管文件", "cl-dim");
          cliPush("退场完成。本地新增内容一个都没动。", "cl-ok");
          logEvent("cleaned", "openvibe-web / 2 个无引用受管文件");
          toast("退场完成", "只删了未改动的受管文件，本地内容未动。");
        } else {
          cliPush("已取消。没有删除任何文件。", "cl-dim");
        }
        cli.last = { risk: "danger" };
        rerender("cli-out", cliOutHTML());
        return;
      }
    }
    var norm = cmd.replace(/\s+/g, " ");
    var hit = null;
    S.cliCommands.forEach(function (c) { if (norm === c.cmd) hit = c; });
    if (!hit) {
      S.cliCommands.forEach(function (c) {
        var base = c.cmd.split(" ").slice(0, 3).join(" ");
        if (norm.indexOf(base) === 0) hit = hit || c;
      });
    }
    if (!hit) {
      cliPush("未知命令：" + cmd, "cl-err");
      cliPush("输入 openvibe --help 查看可用命令；或点左侧任意一条。", "cl-dim");
      cli.last = null;
      rerender("cli-out", cliOutHTML());
      return;
    }
    cli.last = hit;
    hit.out.forEach(function (l) { cliPush(l, ""); });
    if (norm.indexOf("clean") >= 0) { cli.pending = "clean"; }
    if (norm.indexOf("--apply") >= 0 && norm.indexOf("inject") >= 0) {
      logEvent("injection_confirmed", "default@1.3.0 → ~/proj-a（CLI 实验室回放）");
      toast("注入已确认", "事件已写入本机台账；遥测仍为关闭状态。");
    }
    if (norm.indexOf("verify") >= 0) { state.verify = /DRIFT/.test(hit.out.join("\n")) ? "DRIFT" : "CONSISTENT"; syncChrome(); }
    if (norm.indexOf("scan") >= 0) { state.scanned = true; syncChrome(); }
    rerender("cli-out", cliOutHTML());
  }
  function viewCli() {
    var h = [];
    var groups = [];
    S.cliCommands.forEach(function (c) { if (groups.indexOf(c.group) < 0) groups.push(c.group); });
    h.push('<div class="callout" style="margin-bottom:14px"><span class="ci">' + ICONS.bolt + "</span><div><b>CLI 是唯一的物理写入通道。</b>Web 界面负责理解、预览与决策；真正落盘的动作在这里回放。所有破坏性命令默认 dry-run，写入前自动备份。</div></div>");
    h.push('<div class="cli-layout"><div class="cli-side">');
    groups.forEach(function (g) {
      h.push('<div class="cli-side-h">' + esc(g) + "</div>");
      S.cliCommands.filter(function (c) { return c.group === g; }).forEach(function (c) {
        h.push('<button class="cli-cmd' + (cli.last === c ? " is-on" : "") + '" data-act="cli-use" data-cmd="' + escA(c.cmd) + '">' +
          '<span class="cc-c">' + esc(c.cmd) + "</span>" +
          '<span class="between wrap" style="gap:6px;margin-top:4px"><span class="cc-d grow">' + esc(c.desc) + "</span>" +
          '<span class="risk risk-' + c.risk + '">' + (c.risk === "danger" ? "破坏性" : c.risk === "warn" ? "需决策" : "只读") + "</span></span></button>");
      });
    });
    h.push("</div>");
    h.push("<div>");
    h.push('<div class="cli-term"><div class="cli-bar"><span class="cli-dots"><i></i><i></i><i></i></span>' +
      '<span class="cli-title grow">zsh · ~/proj-a · openvibe v0.2.0</span><span id="cli-risk">' + cliRiskBadge() + "</span>" +
      '<button class="btn btn-sm" data-act="cli-clear">' + ico("trash") + "清空</button></div>");
    h.push('<div class="cli-out" id="cli-out">' + cliOutHTML() + "</div>");
    h.push('<div class="cli-in-row"><span class="cli-ps1">$</span>' +
      '<input class="cli-in" id="cli-input" data-bind="cli-input" placeholder="输入命令后回车 · ↑↓ 翻历史" autocomplete="off" spellcheck="false" aria-label="CLI 输入">' +
      '<button class="btn btn-sm btn-primary" data-act="cli-run">执行</button></div>');
    h.push('<div class="cli-chip-row">');
    ["openvibe --help", "openvibe scan", "openvibe inject ~/proj-a --pack default", "openvibe verify ~/proj-a", "openvibe rollback ~/proj-a --to 1.2.0", "openvibe clean ~/proj-a"].forEach(function (c) {
      h.push('<button class="chip" data-act="cli-use" data-cmd="' + escA(c) + '">' + esc(c) + "</button>");
    });
    h.push("</div></div>");
    h.push('<div class="grid grid-3 mt">');
    h.push('<div class="card"><div class="card-body"><div class="eyebrow">干跑优先</div><div class="muted" style="font-size:12px;margin-top:5px">不带 --apply 时只输出写入计划。计划里出现冲突，必须逐段确认，--yes 也不能跳过。</div></div></div>');
    h.push('<div class="card"><div class="card-body"><div class="eyebrow">备份与指纹</div><div class="muted" style="font-size:12px;margin-top:5px">写入前备份到 .openvibe/backup/；写入后更新 lock.json 的期望指纹，verify 才有基准。</div></div></div>');
    h.push('<div class="card"><div class="card-body"><div class="eyebrow">本机台账</div><div class="muted" style="font-size:12px;margin-top:5px">实验室里的注入与退场会真实追加到事件台账（不出网），可在「成长与统计」里看到。</div></div></div>');
    h.push("</div></div></div>");
    return h.join("");
  }
  var VIEWS = {
    "/dashboard": viewDashboard,
    "/prompts": viewPrompts,
    "/skills": viewSkills,
    "/terms": viewTerms,
    "/projects": viewProjects,
    "/packs": viewPacks,
    "/growth": viewGrowth,
    "/settings": viewSettings,
    "/playbooks": viewPlaybooks,
    "/cli": viewCli
  };

  /* ══════════════ 渲染 ══════════════ */
  function render(focusSel) {
    syncChrome();
    var fn = VIEWS[state.route] || viewDashboard;
    $("#view-inner").innerHTML = fn();
    save();
    window.scrollTo(0, 0);
    if (focusSel) {
      var f = $(focusSel);
      if (f) { f.focus(); try { f.setSelectionRange(f.value.length, f.value.length); } catch (e) {} }
    }
  }
  function logEvent(kind, subject) {
    state.events.unshift({ kind: kind, subject: subject, at: now() });
    save();
  }
  function loopCount() {
    var inj = state.events.filter(function (e) { return e.kind === "injection_confirmed"; }).length;
    var reflow = state.events.filter(function (e) { return e.kind === "asset_reflowed"; }).length;
    return Math.min(inj, reflow) + S.stats.loops;
  }
  function rerender(id, html) {
    var el = $("#" + id);
    if (el) el.innerHTML = html;
  }
  function route() {
    var h = location.hash.replace(/^#/, "") || "/dashboard";
    if (!VIEWS[h]) h = "/dashboard";
    state.route = h;
    render();
  }
  window.addEventListener("hashchange", route);

  /* ══════════════ 组包向导 ══════════════ */
  var wiz = null, wizEl = null;
  function wizAssets() {
    return {
      prompts: ["p-001", "p-002", "p-003", "p-004", "p-007", "p-008"],
      skills: ["spec-kit-conventions", "commit-message-cn"],
      terms: ["t-01", "t-02", "t-04", "t-05", "t-09", "t-10", "t-13"]
    };
  }
  function openWizard(step) {
    if (!wiz) {
      wiz = { step: 0, assets: wizAssets(), templateId: "f-light", platform: "claude-code", decisions: {}, applied: false, applying: false, size: null };
      S.injectPlan.files.forEach(function (f) {
        f.segments.forEach(function (s) { wiz.decisions[f.name + "|" + s.key] = s.decision; });
      });
    }
    if (step != null) wiz.step = step;
    renderWizard();
  }
  function wizTotal() {
    var a = wiz.assets;
    var kb = 41.2, tk = 18640;
    var n = a.prompts.length + a.skills.length + a.terms.length;
    return { kb: kb, tokens: tk, n: n, density: Math.round(tk / Math.max(1, n)) };
  }
  function renderWizard() {
    if (wizEl && wizEl.parentNode && overlayStack[overlayStack.length - 1] === wizEl) closeOverlay();
    var steps = ["选择资产", "流程模板", "目标平台", "预览体量", "注入"];
    var t = wizTotal();
    var h = [];
    h.push('<div class="modal-head"><div><div class="modal-title">组装标准包</div><div class="modal-sub">从资产层挑素材 + 选定流程模板 → 生成带版本号的 StandardPack</div></div>' +
      '<button class="icon-btn" data-act="close-overlay" aria-label="关闭">' + ICONS.x + "</button></div>");
    h.push('<div class="stepper">');
    steps.forEach(function (s, i) {
      h.push('<button class="step' + (i < wiz.step ? " is-done" : i === wiz.step ? " is-cur" : "") + '" data-act="wiz-goto" data-i="' + i + '"' + (i > wiz.step && !wiz.applied ? " disabled" : "") + '><div class="st-n">' + pad(i + 1) + "</div><div class=\"st-t\">" + s + "</div></button>");
    });
    h.push("</div>");
    h.push('<div class="modal-body">');

    if (wiz.step === 0) {
      h.push('<div class="callout" style="margin-bottom:14px"><span class="ci">' + ICONS.info + "</span><div>五类资产一处沉淀；这里只挑<b>要进这一包</b>的素材。已选 " + t.n + " 条。</div></div>");
      [["prompts", "提示词（M1）", S.prompts], ["terms", "术语（M3）", S.terms], ["skills", "Skill（M2）", S.skills]].forEach(function (g) {
        h.push('<div class="eyebrow" style="margin:12px 0 7px">' + g[1] + "</div>");
        h.push('<div class="grid grid-2">');
        g[2].slice(0, 8).forEach(function (it) {
          var key = it.id || it.name;
          var on = wiz.assets[g[0]].indexOf(key) >= 0;
          h.push('<label class="pick' + (on ? " is-on" : "") + '"><input type="checkbox" ' + (on ? "checked" : "") + ' data-act="wiz-asset" data-kind="' + g[0] + '" data-id="' + escA(key) + '">' +
            '<div class="grow"><div class="pk-t">' + esc(it.title || it.zh || it.name) + "</div>" +
            '<div class="pk-d">' + esc((it.tags || it.aliases || []).join(" · ") || it.definition || it.source || "") + "</div></div></label>");
        });
        h.push("</div>");
      });
    } else if (wiz.step === 1) {
      h.push('<div class="eyebrow" style="margin-bottom:9px">内置流程模板（3 套内置 / 7 套总计）</div><div class="grid grid-2">');
      S.flowTemplates.forEach(function (f) {
        var on = wiz.templateId === f.id;
        var items = f.stages.reduce(function (a, s) { return a + s.checklist.length; }, 0);
        h.push('<label class="pick' + (on ? " is-on" : "") + '"><input type="radio" name="tpl" ' + (on ? "checked" : "") + ' data-act="wiz-tpl" data-id="' + f.id + '">' +
          '<div class="grow"><div class="pk-t">' + esc(f.name) + ' <span class="badge b-muted">' + f.stages.length + " 阶段 / " + items + " 检查项</span></div>" +
          '<div class="pk-d">' + esc(f.stages.map(function (s) { return s.name; }).join(" → ")) + "</div></div></label>");
      });
      h.push("</div>");
      h.push('<div class="callout" style="margin-top:14px"><span class="ci">' + ICONS.branch + "</span><div>可视化流程模板是社区传播<b>双钩子</b>之一：对比 BMAD 只发文件，这里是可裁剪的工作台。</div></div>");
    } else if (wiz.step === 2) {
      h.push('<div class="eyebrow" style="margin-bottom:9px">目标平台（决定产物文件长相）</div><div class="grid grid-2">');
      S.adapters.forEach(function (a) {
        var on = wiz.platform === a.id;
        h.push('<label class="pick' + (on ? " is-on" : "") + '"><input type="radio" name="plat" ' + (on ? "checked" : "") + ' data-act="wiz-plat" data-id="' + a.id + '">' +
          '<div class="grow"><div class="pk-t">' + esc(a.name) + "</div><div class=\"pk-d\">" + a.files.map(function (f) { return '<span class="tag">' + esc(f) + "</span>"; }).join(" ") + "</div></div></label>");
      });
      h.push("</div>");
      h.push('<div class="eyebrow" style="margin:16px 0 7px">兼容矩阵（AGENTS.md 覆盖）</div><div class="row wrap">' +
        S.compatMatrix.map(function (c) { return '<span class="chip">' + esc(c.name) + " → " + esc(c.via) + "</span>"; }).join("") + "</div>");
    } else if (wiz.step === 3) {
      h.push('<div class="between wrap" style="margin-bottom:12px"><div class="eyebrow">产物体量与 token 估算</div>' +
        '<div class="row"><span class="badge b-muted">合计 ' + t.kb.toFixed(1) + " kB</span><span class=\"badge b-indigo\">≈ " + t.tokens.toLocaleString() + " token</span>" +
        '<span class="badge ' + (t.density > 1500 ? "b-amber" : "b-jade") + '">密度 ' + t.density + "</span></div></div>");
      if (t.density > 1500) h.push('<div class="warnbar" style="margin-bottom:12px"><span style="flex:none">' + ICONS.warn + "</span><div>超过密度阈值：<b>只亮黄条不阻断</b>。建议裁掉占比最高但被引用最少的段落。</div></div>");
      h.push('<div class="diff"><div class="diff-head"><span>文件</span><span>体量 · ≈token</span></div>');
      S.injectPlan.files.forEach(function (f) {
        h.push('<div class="diff-line ctx"><span class="diff-g">·</span><span class="diff-c"><span class="mono">' + esc(f.name) + "</span></span>" +
          '<span class="diff-c mono" style="text-align:right">' + f.kb.toFixed(1) + " kB · " + f.tokens.toLocaleString() + "</span></div>");
      });
      h.push("</div>");
      h.push('<div class="callout" style="margin-top:14px"><span class="ci">' + ICONS.info + "</span><div>口径：中文按 <b>1 字 ≈ 1 token</b>，英文/代码按 <b>4 字符 ≈ 1 token</b>——不是 chars/4 一刀切。</div></div>");
    } else {
      if (wiz.applying) {
        h.push('<div class="empty"><div class="row"><span class="spinner"></span><b>正在应用注入…</b></div><p>写入顺序：先备份 → 写 lock 临时文件 → 逐文件写 → 原子替换 lock。</p></div>');
      } else if (wiz.applied) {
        h.push('<div class="callout" style="border-color:var(--jade);background:var(--jade-soft)"><span class="ci" style="color:var(--jade)">' + ICONS.check + "</span><div><b>注入完成</b>：写入 " + S.injectPlan.files.length + " 个产物、登记 lock、备份至 <span class=\"mono\">.openvibe/backup/" + esc(now().replace(/[: ]/g, "")) + "/</span>。台账新增 <span class=\"mono\">injection_confirmed</span>。</div></div>");
        h.push('<div class="sep"></div><div class="eyebrow">应用结果</div>');
        h.push('<table class="table mt-s"><thead><tr><th>文件</th><th>结果</th><th>决策</th></tr></thead><tbody>');
        S.injectPlan.files.forEach(function (f) {
          var dec = f.segments.map(function (s) { return wiz.decisions[f.name + "|" + s.key]; }).filter(function (d) { return d && d !== "skip"; });
          var res = f.state === "FOREIGN" ? '<span class="badge b-muted">未触碰</span>' : f.state === "NEW" ? '<span class="badge b-jade">已写入</span>' : dec.length ? '<span class="badge b-accent">段级应用</span>' : '<span class="badge b-jade">已写入</span>';
          h.push("<tr><td class='mono'>" + esc(f.name) + "</td><td>" + res + "</td><td class='muted'>" + esc(f.segments.map(function (s) { return s.key; }).join(" / ")) + "</td></tr>");
        });
        h.push("</tbody></table>");
        h.push('<div class="row wrap" style="margin-top:14px"><button class="btn btn-primary" data-act="verify-run">' + ico("shield") + "运行 verify 核验</button>" +
          '<button class="btn" data-act="goto" data-route="/packs">回到标准包</button></div>');
      } else {
        h.push('<div class="callout" style="margin-bottom:14px"><span class="ci">' + ICONS.shield + "</span><div><b>dry-run 预览</b>：这是将发生的全部写入。冲突默认倒向「保留本地」——不静默覆盖用户手改。</div></div>");
        S.injectPlan.files.forEach(function (f) {
          var badge = { DRIFT: "b-amber", IN_SYNC: "b-jade", FOREIGN: "b-muted", NEW: "b-indigo" }[f.state];
          h.push('<div class="plan-file"><div class="pf-head"><span class="pf-name">' + esc(f.name) + "</span>" +
            '<span class="badge ' + badge + '">' + f.state + "</span><span class=\"grow\"></span>" +
            '<span class="muted mono" style="font-size:11px">' + f.kb.toFixed(1) + " kB</span></div>");
          f.segments.forEach(function (s) {
            var key = f.name + "|" + s.key;
            var cur = wiz.decisions[key];
            h.push('<div class="pf-seg"><span class="seg-key">' + esc(s.key) + "</span>" +
              '<span class="muted" style="font-size:11.5px">' + esc(s.detail) + "</span><span class=\"grow\"></span>");
            if (s.state === "FREE" || s.state === "FOREIGN") {
              h.push('<span class="badge b-muted">永不触碰</span>');
            } else if (s.state === "IN_SYNC") {
              h.push('<span class="badge b-jade">一致</span>');
            } else {
              h.push('<span class="radio-row">' +
                [["pack", "以包为准"], ["keep_local", "保留本地"], ["skip", "跳过"]].map(function (o) {
                  return '<label class="' + (cur === o[0] ? "is-on" : "") + '"><input type="radio" name="' + escA(key) + '" ' + (cur === o[0] ? "checked" : "") + ' data-act="wiz-decide" data-file="' + escA(f.name) + '" data-seg="' + escA(s.key) + '" data-v="' + o[0] + '">' + o[1] + "</label>";
                }).join("") + "</span>");
            }
            h.push("</div>");
          });
          h.push('<div style="padding:0 12px 10px"><div class="why"><b>为什么：</b>' + f.why + "</div></div>");
          h.push("</div>");
        });
      }
    }
    h.push("</div>");
    h.push('<div class="modal-foot">');
    h.push('<div class="row"><span class="muted" style="font-size:11.5px">' + (wiz.step + 1) + " / 5</span>" +
      (wiz.step > 0 && !wiz.applied ? '<button class="btn btn-sm" data-act="wiz-prev">上一步</button>' : "") + "</div>");
    h.push('<div class="row">');
    if (wiz.applied) {
      h.push('<button class="btn" data-act="close-overlay">完成</button>');
    } else if (wiz.step < 4) {
      h.push('<button class="btn btn-primary" data-act="wiz-next">下一步 ' + ico("down") + "</button>");
    } else {
      h.push('<button class="btn btn-primary" data-act="wiz-apply">' + ico("shield") + "应用注入（写入 + 备份 + lock）</button>");
    }
    h.push("</div></div>");
    openModal(h.join(""), "is-wide");
    wizEl = overlayStack[overlayStack.length - 1];
  }
  function wizApply() {
    wiz.applying = true;
    renderWizard();
    setTimeout(function () {
      wiz.applying = false;
      wiz.applied = true;
      state.verify = "CONSISTENT";
      state.events.unshift({ kind: "injection_confirmed", subject: wizPlatformName() + " → openvibe-web", at: now() });
      state.events.unshift({ kind: "injection_conflict_resolved", subject: "CLAUDE.md / 行为规则 → " + (wiz.decisions["CLAUDE.md|行为规则"] === "pack" ? "以包为准" : "保留本地"), at: now() });
      renderWizard();
      syncChrome();
      save();
      toast("注入完成", "产物已写入，lock 已登记，备份已生成；台账新增 2 条事件。");
    }, 900);
  }
  function wizPlatformName() {
    var a = find(S.adapters, wiz.platform);
    return a ? a.name : "Claude Code";
  }

  /* ══════════════ verify ══════════════ */
  function runVerify() {
    toast("正在核验三方一致性…", "包内容 vs lock 期望 vs 磁盘实际", "info");
    setTimeout(function () {
      state.verify = "CONSISTENT";
      render();
      toast("CONSISTENT", "包 / lock / 磁盘三方哈希一致。");
    }, 700);
  }

  /* ══════════════ 命令面板 ══════════════ */
  function paletteItems() {
    var items = [];
    Object.keys(TITLES).forEach(function (r) {
      items.push({ g: "导航", t: TITLES[r][0], k: r, act: "goto", route: r });
    });
    S.prompts.forEach(function (p) { items.push({ g: "提示词", t: p.title, k: "M1", act: "prompt-jump", id: p.id }); });
    S.terms.forEach(function (t) { items.push({ g: "术语", t: t.zh + " / " + t.en, k: "M3", act: "term-open", id: t.id }); });
    S.projects.forEach(function (p) { items.push({ g: "项目", t: p.name, k: "M5", act: "proj-open", id: p.id }); });
    S.packs.forEach(function (p) { items.push({ g: "标准包", t: p.name + "@" + p.version, k: "M6", act: "pack-detail", id: p.id }); });
    items.push({ g: "命令", t: "组装标准包（组包向导）", k: "M6", act: "pack-wizard" });
    items.push({ g: "命令", t: "运行 openvibe verify", k: "M6", act: "verify-run" });
    items.push({ g: "命令", t: "切换专家视图（当前模块）", k: "D28", act: "expert-toggle" });
    items.push({ g: "命令", t: "切换主题 纸 / 墨", k: "设置", act: "theme-toggle" });
    items.push({ g: "命令", t: "打开 CLI 终端实验室", k: "CLI", act: "goto", route: "/cli" });
    items.push({ g: "命令", t: "查看回流候选（M4 Phase 2）", k: "M4", act: "goto", route: "/playbooks" });
    items.push({ g: "命令", t: "键盘快捷键", k: "帮助", act: "shortcuts" });
    return items;
  }
  var palSel = 0;
  function openPalette() {
    palSel = 0;
    renderPalette("");
    var m = overlay('<div class="palette" role="dialog" aria-modal="true"><input class="pal-input" id="pal-input" placeholder="搜索页面、提示词、术语、项目、命令…" aria-label="命令面板"><div class="pal-list" id="pal-list"></div>' +
      '<div class="pal-foot"><span><span class="kbd">↑↓</span> 选择</span><span><span class="kbd">↵</span> 执行</span><span><span class="kbd">esc</span> 关闭</span></div></div>', "palette-mask");
    var input = $("#pal-input", m);
    input.addEventListener("input", function () { palSel = 0; renderPalette(input.value, m); });
    input.addEventListener("keydown", function (e) {
      var list = paletteItems().filter(function (it) { return it.t.toLowerCase().indexOf(input.value.trim().toLowerCase()) >= 0; });
      if (e.key === "ArrowDown") { e.preventDefault(); palSel = Math.min(palSel + 1, list.length - 1); renderPalette(input.value, m); }
      else if (e.key === "ArrowUp") { e.preventDefault(); palSel = Math.max(palSel - 1, 0); renderPalette(input.value, m); }
      else if (e.key === "Enter") { e.preventDefault(); if (list[palSel]) { closeOverlay(); runAct(list[palSel].act, list[palSel]); } }
    });
    setTimeout(function () { input.focus(); }, 30);
  }
  function renderPalette(q, mask) {
    q = (q || "").trim().toLowerCase();
    var list = paletteItems().filter(function (it) { return !q || it.t.toLowerCase().indexOf(q) >= 0; });
    var html = "", lastG = "";
    list.forEach(function (it, i) {
      if (it.g !== lastG) { html += '<div class="pal-group">' + it.g + "</div>"; lastG = it.g; }
      html += '<div class="pal-item' + (i === palSel ? " is-sel" : "") + '" data-act="' + it.act + '"' +
        (it.route ? ' data-route="' + it.route + '"' : "") + (it.id ? ' data-id="' + escA(it.id) + '"' : "") + ">" +
        "<span>" + esc(it.t) + '</span><span class="pi-k">' + esc(it.k) + "</span></div>";
    });
    if (!list.length) html = '<div class="empty"><b>没有匹配项</b></div>';
    var el = $("#pal-list", mask || DOC);
    if (el) el.innerHTML = html;
  }

  /* ══════════════ 首启向导 ══════════════ */
  var onboard = { step: 0, copied: false, ask: false };
  function openOnboard() {
    renderOnboard();
  }
  function renderOnboard() {
    var steps = [
      { t: "资产库已经就位", d: "种子内容随代码同协议发布：109 条术语、21 条提示词、7 套流程模板、6 个 skill。你不用从空库开始。", b: "下一步" },
      { t: "看一眼预置的标准包", d: "首启时由种子内容自动组装 1 个 default 包：精选提示词 + 术语 + 个人轻量流模板。开箱即可注入到测试项目。", b: "下一步" },
      { t: "复制这一条命令", d: "注入是唯一物理通道——浏览器写不了你的本地项目文件。把命令贴到终端跑一次，然后回来。", b: "我跑完了" }
    ];
    var s = steps[onboard.step];
    var h = [];
    h.push('<div class="onboard"><div class="onboard-body">');
    h.push('<div class="row between"><span class="onboard-step">首启向导 · 可跳过 · ' + (onboard.step + 1) + " / 3</span>" +
      '<span class="badge b-muted">每步都有真实副作用</span></div>');
    h.push("<h2>" + s.t + "</h2><p>" + s.d + "</p>");
    if (onboard.step === 1) {
      h.push('<div class="diff" style="margin-top:16px"><div class="diff-head"><span>default 包组成</span><span>v1.3.0</span></div>' +
        '<div class="diff-line ctx"><span class="diff-g">·</span><span class="diff-c">提示词 6 · Skill 2 · 术语 7 · 流程模板「个人轻量流」</span></div>' +
        '<div class="diff-line ctx"><span class="diff-g">·</span><span class="diff-c">41.2 kB · ≈18,640 token · 产物 5 个文件</span></div></div>');
    }
    if (onboard.step === 2) {
      h.push('<div class="row wrap" style="margin-top:16px;gap:8px"><span class="mono" style="font-size:12.5px;background:var(--surface-2);border:1px solid var(--line);padding:8px 12px;border-radius:8px">npx openvibe serve --open</span>' +
        '<button class="btn btn-sm" data-act="onboard-copy">' + ico("copy") + "复制</button></div>");
      h.push('<div class="row wrap" style="margin-top:9px;gap:8px"><span class="mono" style="font-size:12.5px;background:var(--surface-2);border:1px solid var(--line);padding:8px 12px;border-radius:8px">openvibe sync ~/test --pack default</span>' +
        '<button class="btn btn-sm" data-act="onboard-copy2">' + ico("copy") + "复制</button></div>");
    }
    if (onboard.ask) {
      h.push('<div class="callout" style="margin-top:18px"><span class="ci">' + ICONS.shield + "</span><div><b>要不要开启匿名统计？</b><br>默认关。只报三类事件（注入成功 / 流程模板选用 / 活跃项目去标识计数），不含路径、内容与用户标识。拒绝后本地标记，永不再问。</div></div>");
      h.push('<div class="row wrap" style="margin-top:12px"><button class="btn btn-primary" data-act="telemetry-set" data-v="1">开启</button>' +
        '<button class="btn" data-act="telemetry-set" data-v="0">保持关闭</button></div>');
    }
    h.push("</div>");
    h.push('<div class="onboard-foot"><div class="dots">' + [0, 1, 2].map(function (i) { return '<i class="' + (i === onboard.step ? "is-on" : "") + '"></i>'; }).join("") + "</div>" +
      '<div class="row"><button class="btn btn-ghost" data-act="onboard-skip">跳过向导</button>' +
      (onboard.ask ? '<button class="btn btn-primary" data-act="onboard-finish">进入工作台</button>' :
        '<button class="btn btn-primary" data-act="onboard-next">' + s.b + "</button>") + "</div></div>");
    h.push("</div>");
    DOC.body.style.overflow = "hidden";
    var m = overlay(h.join(""), "onboard-mask");
    return m;
  }
  function onboardFinish() {
    state.onboarded = true;
    closeAllOverlays();
    DOC.body.style.overflow = "";
    save();
    toast("向导完成", "已生成 1 条本机事件：flow_template_run。可以开始转飞轮了。");
  }

  /* ══════════════ 动作分发 ══════════════ */
  function runAct(act, d) {
    switch (act) {
      case "goto":
        if (d.route) location.hash = "#" + d.route;
        break;
      case "close-overlay": closeOverlay(); break;
      case "theme-toggle": state.theme = state.theme === "light" ? "dark" : "light"; syncChrome(); save(); break;
      case "theme": state.theme = d.v; syncChrome(); save(); break;
      case "expert-toggle": state.expert[state.route] = !state.expert[state.route]; render(); break;
      case "expert-set": state.expert[state.route] = d.v === "1"; render(); break;
      case "copy": copyText(decodeURIComponent(d.text || "")); break;

      /* M1 */
      case "prompt-select": state.selectedPrompt = d.id; state.promptTab = "edit"; state.diffVersion = null; render(); break;
      case "prompt-tag": state.promptTag = d.v; render(); break;
      case "prompt-tab": state.promptTab = d.v; state.diffVersion = null; render(); break;
      case "prompt-save": {
        var p = getPrompt(state.selectedPrompt);
        var c = promptContent(p);
        var pt = state.patch[p.id] || {};
        pt.version = promptVersion(p) + 1;
        pt.content = c;
        pt.changelog = [{ v: pt.version, at: now(), note: "编辑保存（自动快照）" }].concat(promptLog(p));
        state.patch[p.id] = pt;
        state.promptTab = "versions";
        state.diffVersion = pt.version - 1;
        render();
        toast("已保存快照 v" + pt.version, "每次保存自动快照，可对比与回滚。");
        break;
      }
      case "prompt-copy": {
        var pp = getPrompt(state.selectedPrompt);
        var txt = promptContent(pp);
        $$('[data-bind="var"]').forEach(function (inp) {
          var v = inp.getAttribute("data-var"), val = inp.value;
          if (val) txt = txt.split("{{" + v + "}}").join(val);
        });
        var left = (txt.match(/\{\{[^}]+\}\}/g) || []).length;
        copyText(txt);
        if (left) toast("已复制（" + left + " 个变量未填）", "未填的变量按原文保留。", "warn");
        break;
      }
      case "prompt-diff": state.diffVersion = parseInt(d.v, 10); render(); break;
      case "prompt-rollback": {
        var pr = getPrompt(state.selectedPrompt), rv = parseInt(d.v, 10);
        var old = pr.snaps && pr.snaps[rv] != null ? pr.snaps[rv] : pr.content;
        var pt2 = state.patch[pr.id] || {};
        pt2.content = old;
        pt2.version = promptVersion(pr) + 1;
        pt2.changelog = [{ v: pt2.version, at: now(), note: "回滚到 v" + rv }].concat(promptLog(pr));
        state.patch[pr.id] = pt2;
        state.diffVersion = null;
        state.promptTab = "edit";
        render();
        toast("已回滚到 v" + rv, "历史不被改写：回滚生成新版本 v" + pt2.version + "。");
        break;
      }
      case "prompt-new": toast("新建提示词", "已建草稿：进入编辑器，支持 Markdown、代码高亮与实时预览。"); state.selectedPrompt = "p-006"; state.promptTab = "edit"; render(); break;
      case "prompt-import": toast("反向导入", "从 .cursorrules / CLAUDE.md 读取内容并生成新词条，原文件不动。", "info"); break;

      /* M3 */
      case "term-view": state.termView = d.v; render(); break;
      case "term-sel": {
        var i = state.termSel.indexOf(d.id);
        if (i >= 0) state.termSel.splice(i, 1); else state.termSel.push(d.id);
        render();
        break;
      }
      case "term-open": {
        var dr = openDrawer(termDrawer(d.id));
        dr.drawer.setAttribute("data-drawer", "1");
        break;
      }
      case "term-gen": {
        var chosen = S.terms.filter(function (t) { return state.termSel.indexOf(t.id) >= 0; });
        var body = "# TERMS.md\n\n> 由 OpenVibe 术语库生成 · " + chosen.length + " 条 · " + now() + "\n\n";
        chosen.forEach(function (t) {
          body += "## " + t.zh + " / " + t.en + "\n\n" + t.definition + "\n\n**示例**：" + t.example + "\n\n";
          if ((t.aliases || []).length) body += "**别名**：" + t.aliases.join("、") + "\n\n";
          body += "---\n\n";
        });
        var tk = estTokens(body);
        openModal('<div class="modal-head"><div><div class="modal-title">生成 TERMS.md</div><div class="modal-sub">' + chosen.length + ' 条词条 · ' + tk + ' ≈token · 纯 Markdown，供标准包注入</div></div>' +
          '<button class="icon-btn" data-act="close-overlay">' + ICONS.x + "</button></div>" +
          '<div class="modal-body"><div class="editor"><div class="editor-pane"><div class="ep-head"><span>产物预览</span></div><div class="ep-scroll md-body">' + md(body) + "</div></div>" +
          '<div class="editor-pane"><div class="ep-head"><span>Markdown 源码</span></div><textarea readonly spellcheck="false">' + esc(body) + "</textarea></div></div></div>" +
          '<div class="modal-foot"><span class="muted" style="font-size:11.5px">M3 只产出素材；注入经 M6 + CLI</span>' +
          '<div class="row"><button class="btn" data-act="close-overlay">关闭</button><button class="btn btn-primary" data-act="copy" data-text="' + escA(body) + '">' + ico("copy") + "复制 TERMS.md</button></div></div>", "is-wide");
        break;
      }
      case "term-new": toast("新增词条", "字段：中文名 / 英文名 / 别名 / 定义 / 示例 / 相关术语 / 来源 / 标签。", "info"); break;
      case "term-edit": closeOverlay(); toast("编辑词条", "社区提案-审核流在 Phase 2 团队版。", "info"); break;
      case "term-batch": case "term-export": toast("批量操作", "专家路径：受控词表编辑 / 批量改 tag / 导出 JSON。", "info"); break;

      /* M2 */
      case "skill-scan": {
        state.scanned = false;
        render();
        toast("正在扫描本地目录…", "逐根目录隔离失败", "info");
        setTimeout(function () {
          state.scanned = true;
          render();
          state.events.unshift({ kind: "asset_created", subject: "skill 扫描：6 个登记（1 条 warning）", at: now() });
          save();
          toast("扫描完成", "6 个 skill 已登记；1 个目录有符号链接环，已降级为 warning 未中断扫描。", "warn");
        }, 800);
        break;
      }
      case "skill-register": toast("手动登记", "记录名称、来源、版本与 SHA-256 指纹。", "info"); break;
      case "skill-distribute": toast("分发到多平台", "symlink / copy 双模式；属 M2 完整版（Phase 2）。当前为瘦身版：扫描 + 登记。", "info"); break;

      /* M5 */
      case "proj-open": state.currentProject = d.id; render(); break;
      case "proj-new": toast("新建项目", "选流程模板 → 选/组标准包 → CLI 注入（dry-run）→ 开工。10 分钟完成。", "info"); break;
      case "proj-tab": state.projTab = d.v; render(); break;
      case "stage-goto": {
        var pj = getProject();
        pj.stageIndex = parseInt(d.i, 10);
        render();
        break;
      }
      case "stage-advance": {
        var p2 = getProject(), t2 = find(S.flowTemplates, p2.templateId);
        if (p2.stageIndex < t2.stages.length - 1) {
          p2.stageIndex++;
          state.events.unshift({ kind: "stage_advanced", subject: p2.name + " → " + t2.stages[p2.stageIndex].name + "（" + (p2.stageIndex + 1) + "/" + t2.stages.length + "）", at: now() });
          render();
          toast("已推进到「" + t2.stages[p2.stageIndex].name + "」", "台账新增 stage_advanced。");
        } else toast("已是最后阶段", "走一遍复盘流即可闭环。", "warn");
        break;
      }
      case "check-toggle": {
        var p3 = getProject();
        var k = p3.id + ":" + p3.stageIndex + ":" + d.i;
        state.checks[k] = !state.checks[k];
        render();
        if (state.checks[k]) {
          state.events.unshift({ kind: "checklist_item_checked", subject: p3.name + " / " + find(S.flowTemplates, p3.templateId).stages[p3.stageIndex].name + " / " + find(S.flowTemplates, p3.templateId).stages[p3.stageIndex].checklist[d.i], at: now() });
          save();
        }
        break;
      }
      case "task-add": {
        var p4 = getProject();
        var kb = state.kanban[p4.id] || (state.kanban[p4.id] = JSON.parse(JSON.stringify(projectTasks(p4))));
        var stg = find(S.flowTemplates, p4.templateId).stages[p4.stageIndex].name;
        kb.todo.push({ id: "k" + Date.now(), title: "新任务（挂在「" + stg + "」）", stage: stg, status: "todo" });
        render();
        toast("已添加任务", "任务挂到当前阶段。");
        break;
      }
      case "log-new": {
        var p5 = getProject();
        var t5 = find(S.flowTemplates, p5.templateId);
        var last = (state.extraLogs[p5.id] || []).concat(p5.logs)[0];
        var no = (last ? last.no : 0) + 1;
        state.extraLogs[p5.id] = (state.extraLogs[p5.id] || []).concat([{
          no: no, type: "DEV", at: now(),
          body: "模板预填：编号递增 + 时间戳 + 关联文件 + 验证记录。在这里写你这一轮做了什么、验证结果是什么。",
          files: t5.stages[p5.stageIndex].artifacts[0] || "—", cmd: "npx vitest run", result: "待填"
        }]);
        state.projTab = "logs";
        render();
        toast("DEV-" + pad(no) + " 已追加", "编号自动递增；CHECK 报告每月一次。");
        break;
      }
      case "log-reflow": {
        state.events.unshift({ kind: "asset_reflowed", subject: "来自 DEV-" + pad(parseInt(d.no, 10)) + " 的资产候选（待人工确认）", at: now() });
        save();
        toast("已提为回流候选", "候选不会自动入库——人工确认后才进资产库。", "info");
        break;
      }
      case "flow-run": {
        var p6 = getProject();
        state.events.unshift({ kind: "flow_template_run", subject: find(S.flowTemplates, p6.templateId).name + " / " + p6.name, at: now() });
        save();
        toast("问参式流程已启动", "两段式问参：先问不答，答够 3 个再收敛。", "info");
        break;
      }

      /* M6 */
      case "pack-wizard": openWizard(0); break;
      case "pack-detail": {
        var pk = find(S.packs, d.id);
        var mf = JSON.stringify(pk.manifest, null, 2);
        openModal('<div class="modal-head"><div><div class="modal-title">' + esc(pk.name) + '@' + esc(pk.version) + ' manifest</div><div class="modal-sub">纯文件契约 · 可 git 版本化 · 工具无关</div></div>' +
          '<button class="icon-btn" data-act="close-overlay">' + ICONS.x + "</button></div>" +
          '<div class="modal-body"><div class="editor"><div class="editor-pane"><div class="ep-head"><span>manifest JSON</span></div><div class="ep-scroll"><pre class="md-body"><code>' + hi(mf, "json") + "</code></pre></div></div>" +
          '<div class="editor-pane"><div class="ep-head"><span>指纹</span></div><div class="ep-scroll"><dl class="kv"><dt>artifacts</dt><dd class="mono">' + sha(JSON.stringify(pk.manifest)) + '</dd>' +
          "<dt>schemaVersion</dt><dd>1</dd><dt>sizeKb</dt><dd>" + pk.sizeKb.toFixed(1) + '</dd><dt>≈token</dt><dd>' + pk.tokens.toLocaleString() + '</dd><dt>产物</dt><dd class="mono">CLAUDE.md<br>TERMS.md<br>CHECKLIST.md<br>skills/×' + pk.manifest.skillIds.length + "</dd></dl>" +
          '<div class="callout" style="margin-top:14px"><span class="ci">' + ICONS.shield + "</span><div>同版本重导指纹不一致 → <b>409</b>：库版本不可变。</div></div></div></div></div></div>" +
          '<div class="modal-foot"><span class="muted" style="font-size:11.5px">schemaVersion 1 → 2 属 A 级契约变更（D32/D33 待签）</span>' +
          '<button class="btn btn-primary" data-act="pack-inject" data-id="' + pk.id + '">注入（dry-run）</button></div>', "is-wide");
        break;
      }
      case "pack-inject": openWizard(4); break;
      case "verify-run": closeOverlay(); runVerify(); break;
      case "wiz-goto": if (d.i <= wiz.step || wiz.applied) { wiz.step = parseInt(d.i, 10); renderWizard(); } break;
      case "wiz-next": wiz.step = Math.min(4, wiz.step + 1); renderWizard(); break;
      case "wiz-prev": wiz.step = Math.max(0, wiz.step - 1); renderWizard(); break;
      case "wiz-asset": {
        var kind = d.kind, id2 = decodeURIComponent(d.id);
        var arr = wiz.assets[kind];
        var ix = arr.indexOf(id2);
        if (ix >= 0) arr.splice(ix, 1); else arr.push(id2);
        renderWizard();
        break;
      }
      case "wiz-tpl": wiz.templateId = d.id; renderWizard(); break;
      case "wiz-plat": wiz.platform = d.id; renderWizard(); break;
      case "wiz-decide": wiz.decisions[decodeURIComponent(d.file) + "|" + decodeURIComponent(d.seg)] = d.v; renderWizard(); break;
      case "wiz-apply": wizApply(); break;

      /* 成长 / 系统 */
      case "goto-growth": location.hash = "#/growth"; break;
      case "stage-cycle": {
        var r = d.route;
        var mm = S.moduleStages.filter(function (x) { return x.route === r; })[0];
        var cur = state.stageOverride[r] != null ? state.stageOverride[r] : (mm ? mm.stage : 0);
        state.stageOverride[r] = (cur + 1) % 4;
        render();
        toast("视图已切换", "阶段可显式覆盖；红线④：一键越级，按模块记忆。", "info");
        break;
      }
      case "stage-reset": state.stageOverride = {}; render(); toast("阶段已重置", "毕业信号只升不降，但可随时手动回退视图。", "info"); break;
      case "events-filter": state.ledgerFilter = d.k; render(); break;
      case "events-clear": state.events = []; state.localStats = false; save(); render(); toast("台账已清空", "本机统计开关一并关闭；遥测白名单不受影响。", "warn"); break;
      case "toggle-local": state.localStats = !state.localStats; save(); render(); break;
      case "toggle-telemetry": state.telemetry = !state.telemetry; save(); render(); toast(state.telemetry ? "匿名遥测已开启" : "匿名遥测已关闭", state.telemetry ? "仅三类白名单事件，不含路径与内容。" : "关闭即零外联。"); break;
      case "telemetry-set": state.telemetry = d.v === "1"; onboard.ask = false; save(); renderOnboard(); break;

      /* 向导 */
      case "onboard-next": {
        onboard.step++;
        if (onboard.step > 2) { onboard.ask = true; onboard.step = 2; }
        renderOnboard();
        break;
      }
      case "onboard-skip": onboardFinish(); break;
      case "onboard-finish": onboardFinish(); break;
      case "onboard-copy": copyText("npx openvibe serve --open"); break;
      case "onboard-copy2": copyText("openvibe sync ~/test --pack default"); break;

      /* 面板 */
      case "prompt-jump": state.selectedPrompt = d.id; state.promptTab = "edit"; location.hash = "#/prompts"; break;
      case "stage-info": {
        var rows = S.moduleStages.map(function (m) {
          var cur = state.stageOverride[m.route] != null ? state.stageOverride[m.route] : m.stage;
          var sd = S.stageDefs[cur];
          return "<tr><td style='font-weight:600'>" + esc(m.module) + "</td><td><span class=\"badge b-accent\">" + sd.code + " " + esc(sd.name) + "</span></td><td class='muted'>" + esc(sd.mind) + "</td><td class='muted'>" + esc(m.next) + "</td></tr>";
        }).join("");
        openModal('<div class="modal-head"><div><div class="modal-title">成长阶段</div><div class="modal-sub">阶段是「用户 × 资产类型 × 任务」的三元组判定，不是账号属性</div></div>' +
          '<button class="icon-btn" data-act="close-overlay">' + ICONS.x + "</button></div>" +
          '<div class="modal-body"><table class="table"><thead><tr><th>模块</th><th>当前阶段</th><th>典型心声</th><th>毕业信号</th></tr></thead><tbody>' + rows + "</tbody></table>" +
          '<div class="callout" style="margin-top:14px"><span class="ci">' + ICONS.info + "</span><div>同一人在术语上可以是 F2，在 Skill 上还是 F0。可一键越级，且按模块记忆；渐进披露五红线见「成长与统计」。</div></div></div>" +
          '<div class="modal-foot"><span class="muted" style="font-size:11.5px">红线段落可展开查看全部</span><button class="btn btn-primary" data-act="goto" data-route="/growth">打开成长面板</button></div>', "is-wide");
        break;
      }
      case "cli-use": {
        if (cli.pending) { cli.pending = null; cliPush("已取消上一次待确认操作。", "cl-dim"); }
        cliRun(d.cmd);
        rerender("cli-out", cliOutHTML());
        rerender("cli-risk", cliRiskBadge());
        break;
      }
      case "cli-run": {
        var inp = $("#cli-input");
        var v = inp ? inp.value : "";
        if (inp) inp.value = "";
        cliRun(v);
        rerender("cli-out", cliOutHTML());
        rerender("cli-risk", cliRiskBadge());
        if (inp) inp.focus();
        break;
      }
      case "cli-clear": cli.lines = []; cli.last = null; cli.pending = null; rerender("cli-out", cliOutHTML()); rerender("cli-risk", cliRiskBadge()); break;
      case "reflow-state": {
        state.reflow[d.id] = d.v;
        logEvent("asset_reflowed", "回流候选「" + esc(find(S.reflows, d.id).title) + "」→ " + d.v);
        rerender("reflow-board", reflowBoardHTML());
        toast("候选已更新", find(S.reflows, d.id).title + " → " + d.v, "info");
        break;
      }
      case "reflow-src": {
        var rf = find(S.reflows, d.id);
        toast("来源 · " + rf.from, rf.evidence, "info");
        break;
      }
      case "reflow-new": {
        var cand = find(S.reflows, "rf-02");
        logEvent("asset_reflowed", "候选「" + cand.title + "」送审（来自最近日志捞取）");
        state.reflow["rf-02"] = "reviewing";
        rerender("reflow-board", reflowBoardHTML());
        toast("已送审", cand.title + "：11 次命中，其中 4 次与别称重复。", "info");
        break;
      }
      case "spec-claim": toast("已记入待办", "「" + d.id + "」需要先写 spec；本原型不实现 M4 的创建与分发。", "warn"); break;
      case "shortcuts": {
        var rows = [
          ["⌘ K / Ctrl K", "命令面板：搜页面、提示词、术语、项目、命令"],
          ["g + 字母", "d 工作台 · p 提示词 · s Skill · t 术语 · j 技巧库 · r 项目 · k 标准包 · c CLI · x 成长 · , 设置"],
          ["?", "打开本快捷键面板"],
          ["esc", "关闭最上层浮层（抽屉 / 模态 / 命令面板）"],
          ["↑ ↓ / ↵", "终端实验室：翻历史 / 执行命令"],
          ["点击阶段徽标", "按模块一键越级（F0→F3 循环），状态按模块记忆"]
        ];
        openModal('<div class="modal-head"><div><div class="modal-title">键盘快捷键</div><div class="modal-sub">键盘优先是专家路径的一部分；鼠标永远有等价入口</div></div>' +
          '<button class="icon-btn" data-act="close-overlay">' + ICONS.x + "</button></div>" +
          '<div class="modal-body"><dl class="kv">' + rows.map(function (r) {
            return "<dt><span class=\"kbd\">" + esc(r[0]) + "</span></dt><dd>" + esc(r[1]) + "</dd>";
          }).join("") + "</dl></div>" +
          '<div class="modal-foot"><span class="muted" style="font-size:11.5px">输入框内快捷键不生效</span><button class="btn btn-primary" data-act="close-overlay">知道了</button></div>');
        break;
      }
      case "locked": toast("M4 技巧库归 Phase 2", "D22 勘误：进入实施前须先补 spec（No spec, no task）。当前版本只做回流候选登记。", "warn"); break;
    }
  }
  DOC.addEventListener("click", function (e) {
    var t = e.target.closest ? e.target.closest("[data-act]") : null;
    if (!t) return;
    var tag = t.tagName;
    if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return; // 表单控件走 change / input
    var act = t.getAttribute("data-act");
    var d = {
      v: t.getAttribute("data-v"), id: t.getAttribute("data-id"),
      route: t.getAttribute("data-route"), i: t.getAttribute("data-i"),
      file: t.getAttribute("data-file"), seg: t.getAttribute("data-seg"),
      kind: t.getAttribute("data-kind"), k: t.getAttribute("data-k"), no: t.getAttribute("data-no"),
      text: t.getAttribute("data-text"), cmd: t.getAttribute("data-cmd")
    };
    if (tag === "A" && act === "goto") return; // 让 hash 跳转自己发生
    e.preventDefault();
    runAct(act, d);
  });

  /* ---------- 输入绑定 ---------- */
  DOC.addEventListener("input", function (e) {
    var el = e.target, b = el.getAttribute && el.getAttribute("data-bind");
    if (!b) return;
    if (b === "prompt-q") {
      state.promptQ = el.value;
      rerender("prompt-list", promptListHTML());
    } else if (b === "term-q") {
      state.termQ = el.value;
      if (state.termView !== "all") {
        state.termView = "all";
        render('[data-bind="term-q"]');
      } else {
        rerender("term-results", termTableHTML());
        rerender("term-count", termCountHTML());
        rerender("term-hint", termHintHTML());
        save();
      }
    } else if (b === "prompt-content") {
      var id = el.getAttribute("data-id");
      var pt = state.patch[id] || {};
      pt.content = el.value;
      state.patch[id] = pt;
      var ed = el.closest(".editor");
      if (ed) {
        var pv = $(".ep-scroll", ed);
        if (pv) pv.innerHTML = md(el.value);
        var head = $(".ep-head .mono", ed);
        if (head) head.textContent = estTokens(el.value) + " ≈token";
      }
      var dEl = $("#prompt-dirty");
      if (dEl) {
        var base = find(S.prompts, id);
        var isDirty = base && el.value !== base.content;
        dEl.style.display = isDirty ? "" : "none";
        var sb = $("#btn-prompt-save");
        if (sb) sb.classList.toggle("btn-primary", !!isDirty);
      }
      save();
    }
  });
  DOC.addEventListener("change", function (e) {
    var el = e.target;
    var act = el.getAttribute && el.getAttribute("data-act");
    var b = el.getAttribute && el.getAttribute("data-bind");
    if (b === "prompt-plat") { state.promptPlat = el.value; rerender("prompt-list", promptListHTML()); save(); return; }
    if (act) {
      runAct(act, {
        i: el.getAttribute("data-i"), id: el.getAttribute("data-id"),
        kind: el.getAttribute("data-kind"), v: el.getAttribute("data-v"),
        file: el.getAttribute("data-file"), seg: el.getAttribute("data-seg"),
        route: el.getAttribute("data-route"), k: el.getAttribute("data-k"), no: el.getAttribute("data-no"),
        text: el.getAttribute("data-text"), cmd: el.getAttribute("data-cmd")
      });
    }
  });

  /* ---------- 看板拖拽 ---------- */
  var dragId = null;
  DOC.addEventListener("dragstart", function (e) {
    var c = e.target.closest && e.target.closest("[data-task]");
    if (!c) return;
    dragId = c.getAttribute("data-task");
    c.classList.add("is-drag");
    if (e.dataTransfer) { e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", dragId); }
  });
  DOC.addEventListener("dragend", function (e) {
    $$(".kb-card.is-drag").forEach(function (x) { x.classList.remove("is-drag"); });
    $$(".kb-col.is-over").forEach(function (x) { x.classList.remove("is-over"); });
    dragId = null;
  });
  DOC.addEventListener("dragover", function (e) {
    var col = e.target.closest && e.target.closest("[data-col]");
    if (!col) return;
    e.preventDefault();
    $$(".kb-col.is-over").forEach(function (x) { x.classList.remove("is-over"); });
    col.classList.add("is-over");
  });
  DOC.addEventListener("drop", function (e) {
    var col = e.target.closest && e.target.closest("[data-col]");
    if (!col || !dragId) return;
    e.preventDefault();
    var p = getProject();
    var kb = state.kanban[p.id] || (state.kanban[p.id] = JSON.parse(JSON.stringify(projectTasks(p))));
    var to = col.getAttribute("data-col");
    var moved = null;
    ["todo", "doing", "done"].forEach(function (k) {
      kb[k] = kb[k].filter(function (t) {
        if (t.id === dragId) { moved = t; return false; }
        return true;
      });
    });
    if (moved) { moved.status = to; kb[to].push(moved); }
    state.kanban[p.id] = kb;
    state.events.unshift({ kind: "checklist_item_checked", subject: "看板任务「" + (moved ? moved.title : "") + "」→ " + ({ todo: "待办", doing: "进行", done: "完成" })[to], at: now() });
    render();
    toast("任务已移动", "看板变更已记入台账。", "info");
  });

  /* ---------- 移动端抽屉 ---------- */
  DOC.addEventListener("click", function (e) {
    if (e.target.closest && e.target.closest("#btn-menu")) {
      $(".sidebar").classList.toggle("is-open");
    }
    if (e.target.closest && e.target.closest(".nav-item.is-locked")) {
      runAct("locked", {});
    }
  });

  /* ---------- 键盘：终端 + 全局快捷键 ---------- */
  var gPrefix = false, gTimer = null;
  DOC.addEventListener("keydown", function (e) {
    var el = e.target;
    var b = el.getAttribute && el.getAttribute("data-bind");
    if (b === "cli-input") {
      if (e.key === "Enter") {
        e.preventDefault();
        var v = el.value; el.value = "";
        cliRun(v);
        rerender("cli-out", cliOutHTML());
        rerender("cli-risk", cliRiskBadge());
        el.focus();
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        if (cli.hist.length) { cli.hi = Math.min(cli.hi + 1, cli.hist.length - 1); el.value = cli.hist[cli.hi]; }
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        cli.hi = Math.max(cli.hi - 1, -1);
        el.value = cli.hi < 0 ? "" : cli.hist[cli.hi];
      }
      return;
    }
    var tag = el.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable) return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    var G = { d: "/dashboard", p: "/prompts", s: "/skills", t: "/terms", j: "/playbooks", r: "/projects", k: "/packs", c: "/cli", x: "/growth", ",": "/settings" };
    if (gPrefix && G[e.key]) {
      e.preventDefault();
      gPrefix = false;
      location.hash = "#" + G[e.key];
      return;
    }
    if (e.key === "g") {
      gPrefix = true;
      clearTimeout(gTimer);
      gTimer = setTimeout(function () { gPrefix = false; }, 1500);
      toast("g + 键", "d 工作台 · p 提示词 · s Skill · t 术语 · j 技巧库 · r 项目 · k 标准包 · c CLI · x 成长 · , 设置", "info");
    } else if (e.key === "?") {
      e.preventDefault();
      runAct("shortcuts", {});
    } else if (e.key === "Escape") {
      if (overlayStack.length) closeOverlay();
    }
  });

  /* ---------- 顶栏按钮 ---------- */
  [
    ["#btn-palette", function () { openPalette(); }],
    ["#btn-stage", function () { runAct("stage-info", {}); }],
    ["#btn-expert", function () { runAct("expert-toggle", {}); }],
    ["#btn-theme", function () { runAct("theme-toggle", {}); }]
  ].forEach(function (pair) {
    var el = $(pair[0]);
    if (el) el.addEventListener("click", pair[1]);
  });

  /* ---------- 导航图标注入 ---------- */
  $$("#nav .ni-ico[data-ico]").forEach(function (el) {
    var n = el.getAttribute("data-ico");
    if (ICONS[n]) el.innerHTML = ICONS[n];
  });

  /* ══════════════ 启动 ══════════════ */
  window.OV = {
    state: state, VIEWS: VIEWS, render: render, runAct: runAct, toast: toast,
    openWizard: openWizard, openPalette: openPalette, md: md, hi: hi, diffLines: diffLines,
    estTokens: estTokens, promptListHTML: promptListHTML, termTableHTML: termTableHTML, getPrompt: getPrompt
  };

  if (!location.hash) location.hash = "#" + (state.route || "/dashboard");
  route();
  if (!state.onboarded) setTimeout(openOnboard, 420);
  else setTimeout(function () {
    toast("欢迎回来", "本地优先 · 数据不出本机。按 ⌘K 打开命令面板。", "info");
  }, 500);
})();
