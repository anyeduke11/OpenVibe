/* ============================================================
   OpenVibe 灵典 · 种子数据（演示用，对应 content/seed/*.json）
   ============================================================ */
window.OV_SEED = (function () {
  "use strict";

  var PLATFORMS = ["Claude Code", "Cursor", "CodeBuddy", "Trae", "MiniCode", "通用"];

  /* ---------------- 提示词库 M1 ---------------- */
  var prompts = [
    {
      id: "p-001", title: "需求澄清问参（两段式）", tags: ["需求", "问参"], platforms: ["Claude Code", "通用"],
      status: "active", version: 4, updated: "2026-09-30 10:12", author: "owner",
      content:
"# 需求澄清问参\n\n你是一位资深产品分析师。请按**两段式**与我澄清需求，不要在信息不足时直接给方案。\n\n## 第一段 · 只问不答\n\n针对下面的目标，提出**不超过 5 个**最关键的问题，每个问题附上你为什么需要它：\n\n- 目标：{{goal}}\n- 用户：{{audience}}\n- 约束：{{constraints}}\n\n> 规则：如果我已经答过某个问题，不要重复问；答过 3 个以上就进入第二段。\n\n## 第二段 · 收敛\n\n基于我的回答，输出：\n\n1. 一句话问题陈述\n2. 三条可验证的验收标准\n3. 两个必须先排除的风险\n4. 你需要我补充的材料清单\n\n```json\n{\n  \"mode\": \"interview\",\n  \"maxQuestions\": 5,\n  \"stopWhen\": \"answered >= 3\"\n}\n```\n\n产出用中文，术语与我的术语库保持一致。",
      changelog: [
        { v: 4, at: "2026-09-30 10:12", note: "把「最多 5 问」改为硬上限，避免长会话退化" },
        { v: 3, at: "2026-09-24 16:40", note: "补第二段的风险排除项" },
        { v: 2, at: "2026-09-18 09:05", note: "加入变量约束字段" },
        { v: 1, at: "2026-09-11 20:31", note: "初稿" }
      ]
    },
    {
      id: "p-002", title: "代码审查 · 规则漂移检查", tags: ["审查", "质量"], platforms: ["Claude Code", "Cursor"],
      status: "active", version: 3, updated: "2026-09-28 14:02", author: "owner",
      content:
"# 代码审查 · 规则漂移检查\n\n审查以下改动，**先查漂移再查缺陷**。\n\n## 改动\n\n```diff\n{{diff}}\n```\n\n## 第一步 · 规则漂移（最重要）\n\n逐条对照项目规则文件，指出任何越界之处：\n\n- [ ] 是否改写了标注为「只读」的模块\n- [ ] 是否引入了规则文件中未声明的新依赖\n- [ ] 是否改变了既有的错误码词表\n- [ ] 是否绕过了受管文件的块标记\n\n## 第二步 · 缺陷\n\n按严重度排序，最多 5 条。每条给出：文件:行号、问题、最小修法。\n\n## 输出格式\n\n| 严重度 | 位置 | 问题 | 建议 |\n|---|---|---|---|\n| 高 | `path:12` | … | … |\n\n不要夸奖，不要总结我写得好的部分。",
      changelog: [
        { v: 3, at: "2026-09-28 14:02", note: "漂移检查提前到缺陷之前" },
        { v: 2, at: "2026-09-21 11:20", note: "加入只读模块与错误码词表两项" },
        { v: 1, at: "2026-09-14 08:47", note: "初稿" }
      ]
    },
    {
      id: "p-003", title: "提交信息生成（Conventional）", tags: ["git", "自动化"], platforms: ["通用"],
      status: "active", version: 2, updated: "2026-09-26 19:33", author: "owner",
      content:
"# 提交信息生成\n\n根据下面的 diff 写一条 Conventional Commits 提交信息。\n\n```diff\n{{diff}}\n```\n\n规则：\n\n1. 类型取 `feat|fix|refactor|perf|docs|test|build|ci|chore`\n2. 主题行 ≤ 50 字，用中文，动词开头，句末不加标点\n3. body 说明**为什么**，不说明改了什么（diff 已经说了）\n4. 若涉及破坏性变更，footer 写 `BREAKING CHANGE: …`\n5. 关联范围写 `{{scope}}`\n\n只输出提交信息本身，不要解释。",
      changelog: [
        { v: 2, at: "2026-09-26 19:33", note: "主题行上限从 72 收到 50" },
        { v: 1, at: "2026-09-15 09:00", note: "初稿" }
      ]
    },
    {
      id: "p-004", title: "Bug 根因排查（五问法）", tags: ["排障", "方法论"], platforms: ["Claude Code", "CodeBuddy"],
      status: "active", version: 5, updated: "2026-10-01 09:18", author: "owner",
      content:
"# Bug 根因排查\n\n## 现象\n\n{{symptom}}\n\n## 日志\n\n```\n{{logs}}\n```\n\n## 五问法\n\n对现象连续追问五个「为什么」，每一问都要给出**证据**（日志行、堆栈、复现步骤）。追问不到第五层就停在能解释全部现象的那一层，并在该层标注 `[根因]`。\n\n## 约束\n\n- 不要提出没有复现路径的修复\n- 不要修改与现象无因果链的代码\n- 如果证据不足，直接说「证据不足，需要 X」\n\n## 输出\n\n1. 因果链（5 层以内）\n2. 最小复现\n3. 最小修复 + 回归测试点",
      changelog: [
        { v: 5, at: "2026-10-01 09:18", note: "补「证据不足」出口" },
        { v: 4, at: "2026-09-19 15:02", note: "五问改为可提前停止" },
        { v: 1, at: "2026-09-08 10:00", note: "初稿" }
      ]
    },
    {
      id: "p-005", title: "测试用例生成（边界优先）", tags: ["测试", "质量"], platforms: ["Claude Code", "Trae"],
      status: "active", version: 2, updated: "2026-09-27 11:45", author: "owner",
      content:
"# 测试用例生成\n\n为模块 `{{module}}` 生成测试，框架 `{{framework}}`。\n\n## 优先级\n\n1. 边界（空、单元素、上限、越界）\n2. 异常路径（失败、超时、并发）\n3. 正常路径（每个用例一条即可）\n\n## 要求\n\n- 每个用例三行以内：安排 / 行动 / 断言\n- 断言必须可判定，禁止 `toBeTruthy()` 这类空断言\n- 用中文写用例名，描述「在什么条件下应当怎样」\n\n```ts\nit(\"当输入为空数组时，应当返回空结果而不是抛错\", () => {\n  // arrange\n  // act\n  // assert\n});\n```",
      changelog: [
        { v: 2, at: "2026-09-27 11:45", note: "禁空断言" },
        { v: 1, at: "2026-09-12 14:20", note: "初稿" }
      ]
    },
    {
      id: "p-006", title: "PRD 三段式撰写", tags: ["需求", "文档"], platforms: ["Claude Code"],
      status: "draft", version: 1, updated: "2026-10-02 08:40", author: "owner",
      content:
"# PRD 三段式撰写\n\n为功能 `{{feature}}` 写一份 PRD，读者是 `{{audience}}`。\n\n## 结构（固定三段）\n\n### 一、问题与目标\n- 用户在当前流程里具体卡在哪一步\n- 不解决会怎样（可观察的代价）\n\n### 二、方案与边界\n- 做什么 / 明确不做什么\n- 交互主线（不超过 5 步）\n\n### 三、验收与风险\n- 每条验收都要能机器判定或人工一眼判定\n- 风险表：概率 × 影响 × 缓解\n\n## 纪律\n\n- 不写「等等」「若干」这类不可判定的量词\n- 每个数字给出来源或估算口径\n- 与既有文档冲突时，指出冲突而不是默默选一个",
      changelog: [{ v: 1, at: "2026-10-02 08:40", note: "初稿（草稿态，未审校）" }]
    },
    {
      id: "p-007", title: "术语统一校对", tags: ["术语", "治理"], platforms: ["通用"],
      status: "active", version: 2, updated: "2026-09-25 16:12", author: "owner",
      content:
"# 术语统一校对\n\n校对下面文本中的术语，输出**替换表**而不是改写后的全文。\n\n```\n{{text}}\n```\n\n判定规则（按顺序）：\n\n1. 同一概念出现多个说法 → 统一为词条正名\n2. 出现别名 → 保留首次，其余替换\n3. 出现词库外的新词 → 列入「候选词条」，不要擅自替换\n\n候选词条格式：`中文名 / 英文名 / 一句话定义 / 出现次数`",
      changelog: [
        { v: 2, at: "2026-09-25 16:12", note: "候选词条格式固定" },
        { v: 1, at: "2026-09-10 09:30", note: "初稿" }
      ]
    },
    {
      id: "p-008", title: "上下文裁剪建议", tags: ["上下文", "token"], platforms: ["Claude Code", "Cursor"],
      status: "active", version: 3, updated: "2026-09-29 21:05", author: "owner",
      content:
"# 上下文裁剪建议\n\n下面是准备注入 AI 上下文的文件清单与体量：\n\n```\n{{files}}\n```\n\n请按「有效上下文密度」给建议：\n\n1. 指出占比最高但被引用最少的 3 个文件\n2. 指出可以下沉到「按需检索」而不必常驻的段落\n3. 给出裁剪后的预估 token 与裁剪前对比\n\n口径：中文按 1 字 ≈ 1 token 估算，英文/代码按 4 字符 ≈ 1 token，**不要**用 chars/4 一刀切。",
      changelog: [
        { v: 3, at: "2026-09-29 21:05", note: "token 口径改为中文感知" },
        { v: 2, at: "2026-09-20 10:11", note: "补按需检索建议" },
        { v: 1, at: "2026-09-05 22:00", note: "初稿" }
      ]
    },
    {
      id: "p-009", title: "周度复盘提问", tags: ["复盘", "流程"], platforms: ["通用"],
      status: "deprecated", version: 2, updated: "2026-09-22 18:00", author: "owner",
      content:
"# 周度复盘提问\n\n回答下面四个问题，每个不超过 3 句：\n\n1. 本周最省时间的一个决定是什么？\n2. 本周最浪费时间的重复劳动是什么？\n3. 有哪件事你做了两遍以上？它该变成资产吗？\n4. 下周最重要的一件事是什么？\n\n输出格式：四个小标题 + 结论。",
      changelog: [
        { v: 2, at: "2026-09-22 18:00", note: "由四问收敛为三问" },
        { v: 1, at: "2026-08-30 09:00", note: "初稿" }
      ]
    },
    {
      id: "p-010", title: "重构前置检查清单", tags: ["重构", "质量"], platforms: ["Cursor", "Claude Code"],
      status: "active", version: 1, updated: "2026-10-01 15:26", author: "owner",
      content:
"# 重构前置检查\n\n重构前必须全部打勾，否则不要动手：\n\n- [ ] 目标模块已有可运行的测试基线\n- [ ] 已记录当前行为快照（输入 → 输出样例）\n- [ ] 改动范围能在一次提交内说完\n- [ ] 已确认没有外部调用方依赖即将改名的符号\n- [ ] 回滚路径明确（`git revert` 可回到当前状态）\n\n若任一项不成立，先补那一项，不要「顺手改」。",
      changelog: [{ v: 1, at: "2026-10-01 15:26", note: "初稿" }]
    },
    {
      id: "p-011", title: "变量填充校验（防默认值幻觉）", tags: ["需求", "质量"], platforms: ["Claude Code", "通用"],
      status: "active", version: 3, updated: "2026-10-04 21:07", author: "owner",
      content:
"# 变量填充校验\n\n下面是一条待执行的提示词与已填变量。**先校验再执行**。\n\n```\n{{template}}\n```\n\n已填变量：{{filled}}\n\n## 第一步 · 缺失与可疑\n\n逐项列出：\n\n1. 模板中声明但未填的变量\n2. 填了但明显是占位默认值的（如 `xxx`、`TODO`、`example.com`）\n3. 填了但类型不对的（该给路径给了句子、该给枚举给了自由文本）\n\n## 第二步 · 提问\n\n只对第 1、2 项提问，一次不超过 3 个问题。第 3 项直接给出你的推断并标注 `[推断]`。\n\n## 规则\n\n- 变量不齐时**禁止**用默认值继续执行\n- 不要复述模板内容\n- 全部通过才输出「校验通过，可执行」",
      changelog: [
        { v: 3, at: "2026-10-04 21:07", note: "把「禁止默认值继续」提到规则区" },
        { v: 2, at: "2026-09-22 10:15", note: "补类型不符这一类" },
        { v: 1, at: "2026-09-05 14:40", note: "初稿" }
      ]
    },
    {
      id: "p-012", title: "目录结构规划（先树后码）", tags: ["设计", "方法论"], platforms: ["Claude Code", "Cursor", "Trae"],
      status: "active", version: 2, updated: "2026-10-03 09:52", author: "owner",
      content:
"# 目录结构规划\n\n为下面的目标先给出目录树，**不要写任何实现代码**。\n\n目标：{{goal}}\n约束：{{constraints}}\n\n## 输出\n\n1. 目录树（到文件级，标出哪些是受管文件）\n2. 每个目录一句话职责\n3. 三个「以后一定会加」的扩展点及预留位置\n4. 两处你主动放弃的复杂度，并说明为什么\n\n## 约束\n\n- 单文件不超过 200 行，超过就拆\n- 不在根目录放散落文件\n- 配置与代码分离\n\n等我确认树之后再写代码。",
      changelog: [
        { v: 2, at: "2026-10-03 09:52", note: "加「主动放弃的复杂度」两项" },
        { v: 1, at: "2026-09-02 11:20", note: "初稿" }
      ]
    },
    {
      id: "p-013", title: "增量日志生成（append-only）", tags: ["自动化", "流程"], platforms: ["Claude Code", "CodeBuddy"],
      status: "active", version: 4, updated: "2026-10-06 18:30", author: "owner",
      content:
"# 增量日志生成\n\n把下面的原始记录整理成一行一条的增量日志，**append-only**：只追加，不改写历史行。\n\n```\n{{raw}}\n```\n\n## 行格式\n\n`日期 时间 | 类型 | 对象 | 结果 | 一句话说明`\n\n类型只取：`injected / verified / rolled_back / cleaned / scanned / reflow_candidate`\n\n## 要求\n\n- 时间升序\n- 一行不超过 80 字\n- 不确定的字段写 `?`，不要猜\n- 输出必须是可直接追加到 `LOG.md` 的纯文本，不要 Markdown 表格\n- 若发现与已有日志重复的条目，列在最后的「疑似重复」区，不要合并",
      changelog: [
        { v: 4, at: "2026-10-06 18:30", note: "补「疑似重复」区，避免合并历史" },
        { v: 3, at: "2026-09-25 08:40", note: "行格式收紧到 80 字" },
        { v: 2, at: "2026-09-12 16:10", note: "类型改为封闭枚举" },
        { v: 1, at: "2026-08-28 10:00", note: "初稿" }
      ]
    },
    {
      id: "p-014", title: "术语一致性校对（对照 TERMS.md）", tags: ["术语", "质量"], platforms: ["Claude Code", "Cursor"],
      status: "active", version: 2, updated: "2026-10-05 15:41", author: "owner",
      content:
"# 术语一致性校对\n\n下面是待校对文本与受控词表。逐段找出**同一概念用了不同说法**的地方。\n\n词表：\n\n```\n{{terms}}\n```\n\n待校对：\n\n```\n{{text}}\n```\n\n## 输出\n\n| 位置 | 现用词 | 词表规范词 | 处理 |\n|---|---|---|---|\n| 段落/行号 | … | … | 替换 / 保留并说明 |\n\n## 规则\n\n- 只在**同一篇文档内**不一致才报；跨文档保留各自的别称\n- 代码标识符、路径、命令行参数**一律不改**\n- 已收录的别称不算错，标 `[别称]` 即可\n- 不要改写句子结构，只做词级替换建议",
      changelog: [
        { v: 2, at: "2026-10-05 15:41", note: "明确别称不算错" },
        { v: 1, at: "2026-09-18 20:05", note: "初稿" }
      ]
    },
    {
      id: "p-015", title: "迁移脚本评审（破坏性变更前置）", tags: ["审查", "治理"], platforms: ["Claude Code", "CodeBuddy", "Trae"],
      status: "active", version: 3, updated: "2026-10-07 11:26", author: "owner",
      content:
"# 迁移脚本评审\n\n评审下面的迁移脚本。**先判破坏性，再看正确性**。\n\n```sql\n{{migration}}\n```\n\n## 第一段 · 破坏性判定（必答）\n\n1. 是否删列/删表/改类型/加非空约束而无默认值\n2. 是否有长时间锁表操作（全表重写、加索引无 CONCURRENTLY）\n3. 回滚脚本是否存在且**已被验证**\n\n任一项为是 → 结论写 `BLOCKING`，并给出分批或双写的替代方案。\n\n## 第二段 · 正确性\n\n- 边界：空表、超大表、并发写入\n- 幂等：重复执行是否安全\n\n## 输出\n\n`结论：BLOCKING / 需改 / 可执行` + 三行以内理由。",
      changelog: [
        { v: 3, at: "2026-10-07 11:26", note: "回滚脚本要求「已验证」而非「存在」" },
        { v: 2, at: "2026-09-29 09:30", note: "补并发写入边界" },
        { v: 1, at: "2026-09-06 13:15", note: "初稿" }
      ]
    },
    {
      id: "p-016", title: "使用文档生成（面向使用者）", tags: ["文档"], platforms: ["通用"],
      status: "active", version: 2, updated: "2026-10-02 17:08", author: "owner",
      content:
"# 使用文档生成\n\n为下面的能力写一份使用者文档，**只写使用者需要知道的**。\n\n能力：{{capability}}\n已知限制：{{limits}}\n\n## 结构\n\n1. 一句话它是什么\n2. 三十秒上手（一条可复制的命令或三步）\n3. 常用场景三个，每个一段\n4. 出问题时先看什么（按概率排序的三条）\n5. 已知限制（如实写，不美化）\n\n## 约束\n\n- 不写实现原理，不写架构图\n- 每个命令都给可复制的完整形式\n- 不用「简单」「强大」「优雅」这类空词\n- 使用者是工程师，不要教基础概念",
      changelog: [
        { v: 2, at: "2026-10-02 17:08", note: "禁空词清单" },
        { v: 1, at: "2026-08-25 10:40", note: "初稿" }
      ]
    },
    {
      id: "p-017", title: "性能问题定位（先量后改）", tags: ["排障", "性能"], platforms: ["Claude Code", "Cursor"],
      status: "active", version: 2, updated: "2026-09-30 08:22", author: "owner",
      content:
"# 性能问题定位\n\n现象：{{symptom}}\n\n## 第一步 · 量化\n\n给出可执行的测量命令与判读标准（多少次采样、看哪个分位、阈值多少算异常）。**没有测量不许进第二步。**\n\n## 第二步 · 假设\n\n列出最多三个假设，每个附一条能证伪它的观测。\n\n## 第三步 · 最小验证\n\n对最可能的假设给出最小改动与预期收益（数量级即可）。\n\n## 约束\n\n- 禁止「加缓存」「上异步」这类无定位的方案\n- 不引入新依赖\n- 改动必须可一键回退",
      changelog: [
        { v: 2, at: "2026-09-30 08:22", note: "明确禁止无定位方案" },
        { v: 1, at: "2026-09-01 15:00", note: "初稿" }
      ]
    },
    {
      id: "p-018", title: "依赖升级影响面分析", tags: ["治理", "自动化"], platforms: ["Claude Code", "Trae"],
      status: "active", version: 2, updated: "2026-10-06 09:14", author: "owner",
      content:
"# 依赖升级影响面\n\n待升级：{{dep}} {{from}} → {{to}}\n\n## 输出\n\n1. 破坏性变更清单（只列**会影响本仓库**的，附 changelog 依据）\n2. 本仓库中的调用点（文件:行号）\n3. 每个调用点的风险等级与最小适配\n4. 升级顺序建议（先升谁风险最低）\n5. 回滚命令\n\n## 约束\n\n- 没有 changelog 依据的猜测标 `[未证实]`\n- 跨大版本必须给双跑方案，不许直接替换\n- 不顺手升级传递依赖",
      changelog: [
        { v: 2, at: "2026-10-06 09:14", note: "补升级顺序与回滚命令" },
        { v: 1, at: "2026-09-10 11:11", note: "初稿" }
      ]
    },
    {
      id: "p-019", title: "安全审查（密钥与注入面）", tags: ["审查", "安全"], platforms: ["Claude Code", "CodeBuddy"],
      status: "active", version: 3, updated: "2026-10-08 10:03", author: "owner",
      content:
"# 安全审查\n\n审查以下改动，只关注两类问题：**密钥泄露**与**注入面**。\n\n```diff\n{{diff}}\n```\n\n## 密钥\n\n- 新增的硬编码凭据、token、私钥（含测试夹具里的）\n- 日志与会话回显中可能打印的敏感字段\n\n## 注入面\n\n- 拼接进 shell / SQL / HTML / 模板的未转义变量\n- 新增的外部输入入口（文件、环境变量、网络）\n- 权限变宽（sudo、chmod、放宽 CORS、关闭校验）\n\n## 输出\n\n| 等级 | 位置 | 问题 | 最小修法 |\n|---|---|---|---|\n\n等级只取 `高/中/低`。**没有发现问题就明确说「未发现」，不要凑数。**",
      changelog: [
        { v: 3, at: "2026-10-08 10:03", note: "加「未发现就明说」" },
        { v: 2, at: "2026-09-27 14:55", note: "补权限变宽一类" },
        { v: 1, at: "2026-09-03 09:30", note: "初稿" }
      ]
    },
    {
      id: "p-020", title: "重构护栏（行为保持）", tags: ["重构", "质量"], platforms: ["Claude Code", "Cursor"],
      status: "active", version: 2, updated: "2026-10-04 16:12", author: "owner",
      content:
"# 重构护栏\n\n目标：{{target}}\n\n## 硬约束\n\n- 公开签名、错误码、返回形状**一律不变**\n- 每一轮改动后测试必须全绿，红则立即回退该轮\n- 一次只做一类重构（改名 / 提取 / 移动 不混在同一次提交）\n\n## 步骤\n\n1. 先补缺失的 characterization 测试，把当前行为钉住\n2. 按「最安全的一类」推进，每步一个提交\n3. 提交信息写 `refactor(scope): 做了什么 · 行为不变`\n\n## 若必须改行为\n\n停下来，先问我，并给出迁移方案。不要「顺手优化」。",
      changelog: [
        { v: 2, at: "2026-10-04 16:12", note: "一次一类重构" },
        { v: 1, at: "2026-09-16 10:20", note: "初稿" }
      ]
    },
    {
      id: "p-021", title: "会话交接说明（给下一个会话）", tags: ["流程", "文档"], platforms: ["Claude Code", "通用"],
      status: "active", version: 1, updated: "2026-10-08 22:40", author: "owner",
      content:
"# 会话交接说明\n\n把当前进度写成给**下一个会话**的交接，它没有你的记忆。\n\n## 必含\n\n1. 目标与当前所处流程站（含出口清单完成度）\n2. 已确认的决策（含被否掉的方案及原因）\n3. 未完成项，按优先级排序，每条附「下一步第一个动作」\n4. 环境与前提（分支、包版本、开关状态）\n5. 已知坑与临时绕过（标注 `[临时]` 与清理条件）\n\n## 约束\n\n- 只写可验证的事实，不写感受\n- 每条未完成项必须能独立执行\n- 总长不超过一屏",
      changelog: [{ v: 1, at: "2026-10-08 22:40", note: "初稿" }]
    }
  ];

  /* 由当前版本反推历史快照（用于版本对比演示）：每退一版去掉最后一个二级小节 */
  function olderVersion(txt) {
    var lines = String(txt).replace(/\s+$/, "").split("\n");
    for (var i = lines.length - 1; i >= 2; i--) {
      if (/^##\s/.test(lines[i])) return lines.slice(0, i).join("\n");
    }
    return lines.slice(0, Math.max(4, Math.floor(lines.length * 0.6))).join("\n");
  }
  prompts.forEach(function (p) {
    p.snaps = {};
    p.snaps[p.version] = p.content;
    var cur = p.content;
    for (var v = p.version - 1; v >= 1; v--) {
      cur = olderVersion(cur);
      p.snaps[v] = cur;
    }
  });

  /* ---------------- 术语库 M3 ---------------- */
  var terms = [
    { id: "t-01", zh: "氛围编程", en: "vibe coding", aliases: ["氛围式编程", "Vibe 编程"], station: 1,
      definition: "以自然语言意图驱动、AI 生成代码、人负责意图与验收的开发方式。", example: "我用 vibe coding 两天搭好了内部工具，自己只写需求和不超 20 行的胶水代码。",
      related: ["t-05", "t-09"], source: "社区高频词", tags: ["基础"] },
    { id: "t-02", zh: "提示词", en: "prompt", aliases: ["指令", "Prompt 模板"], station: 1,
      definition: "喂给模型的任务指令文本，含上下文、约束与期望输出。", example: "把这条提示词存进库，下次直接填变量复用。",
      related: ["t-07"], source: "通用", tags: ["基础", "M1"] },
    { id: "t-03", zh: "技能", en: "skill", aliases: ["Skill", "SKILL.md"], station: 1,
      definition: "打包为 SKILL.md 的可复用能力单元，供编码代理按需加载。", example: "这个 skill 扫进来之后，五个项目都能用。",
      related: ["t-04"], source: "Claude Code 契约", tags: ["基础", "M2"] },
    { id: "t-04", zh: "规则文件", en: "rules / CLAUDE.md / AGENTS.md", aliases: ["规则", "上下文文件"], station: 2,
      definition: "注入项目的持久化行为约束，决定 AI 的默认工作方式。", example: "CLAUDE.md 里那句「不许改受管文件」就是规则文件。",
      related: ["t-03", "t-06"], source: "平台契约", tags: ["上下文"] },
    { id: "t-05", zh: "上下文窗口", en: "context window", aliases: ["上下文长度"], station: 2,
      definition: "模型单次可感知的输入长度上限，超出即截断或压缩。", example: "塞了 800 行规则后，上下文窗口被噪声占满，AI 反而记不住关键约束。",
      related: ["t-06", "t-11"], source: "通用", tags: ["上下文"] },
    { id: "t-06", zh: "规则漂移", en: "rule drift", aliases: ["漂移"], station: 2,
      definition: "长会话中模型逐渐偏离规则文件约束的现象。", example: "改到第 40 轮时它开始绕开块标记直接重写整文件——这是典型的规则漂移。",
      related: ["t-04"], source: "实践总结", tags: ["上下文"] },
    { id: "t-07", zh: "规格驱动开发", en: "spec-driven development", aliases: ["SDD", "规格先行"], station: 3,
      definition: "先写规格（spec）再生成代码的开发范式（spec-kit / BMAD 等）。", example: "Spec 驱动流把「需求→PRD→Spec→计划」钉成七站，每站挂检查清单。",
      related: ["t-08"], source: "spec-kit / BMAD", tags: ["流程"] },
    { id: "t-08", zh: "检查清单", en: "checklist", aliases: ["清单"], station: 3,
      definition: "挂在流程阶段上的可勾选验证项，用于把「记得做」变成「可证明做了」。", example: "实现前那一站的清单第一项：上下文文件已注入。",
      related: ["t-07", "t-12"], source: "通用", tags: ["流程"] },
    { id: "t-09", zh: "标准包", en: "StandardPack", aliases: ["包", "standard pack"], station: 3,
      definition: "从资产库挑选素材并选定流程模板后生成的、带版本号的确定性文件集合。", example: "default 包 v1.3.0 一路注入到四个项目。",
      related: ["t-04", "t-10"], source: "产品概念", tags: ["流程", "M6"] },
    { id: "t-10", zh: "注入", en: "sync / inject", aliases: ["写入", "落地"], station: 3,
      definition: "把标准包渲染成目标平台的文件并写入项目目录的动作，必须经 CLI 完成。", example: "`openvibe sync ~/proj --pack default` 干跑通过后再真写。",
      related: ["t-09", "t-13"], source: "产品概念", tags: ["流程", "M6"] },
    { id: "t-11", zh: "有效上下文密度", en: "effective context density", station: 4,
      definition: "一次注入写入的受管 token 数 ÷ 该包在库里覆盖的资产数；回答「塞进去的东西有多少是空的」。", example: "密度从 41 降到 12，说明裁剪掉了 3 条没人引用的长段落。",
      related: ["t-05"], source: "分析文 §9.1", tags: ["度量"] },
    { id: "t-12", zh: "受管文件", en: "managed file", station: 4,
      definition: "由标准包写入并在 lock 中登记的文件；未改动的可退场，改过的默认保留。", example: "这个文件是受管的，`clean` 只会删它没被改过的版本。",
      related: ["t-13", "t-14"], source: "产品概念", tags: ["治理"] },
    { id: "t-13", zh: "干跑", en: "dry-run", aliases: ["预演"], station: 4,
      definition: "只输出将发生的写入计划而不真正落盘的模式，是注入的默认形态。", example: "干跑显示会覆盖 CLAUDE.md，你选了保留本地。",
      related: ["t-10"], source: "CLI 语义", tags: ["治理"] },
    { id: "t-14", zh: "三方一致性", en: "three-way consistency", station: 4,
      definition: "包内容 / lock 期望 / 磁盘实际三者哈希一致；`openvibe verify` 的判定对象。", example: "verify 报 CONSISTENT，说明磁盘、lock 和包没有互相偏离。",
      related: ["t-12"], source: "产品概念", tags: ["治理"] },
    { id: "t-15", zh: "成长阶段", en: "growth stage", aliases: ["F0–F3"], station: 4,
      definition: "定义在「用户 × 资产类型 × 任务」上的四阶段模型（跟随者/实践者/作者/定标者），不是账号属性。", example: "我在术语上是 F2，在 Skill 上还是 F0。",
      related: ["t-16"], source: "分析文 §5.1", tags: ["度量"] },
    { id: "t-16", zh: "渐进披露", en: "progressive disclosure", station: 4,
      definition: "按阶段重排与预填界面，但永不隐藏数据与错误的披露策略。", example: "F0 只露阶段条和清单，看板折叠——但「查看全部」一键可达。",
      related: ["t-15"], source: "分析文 §5.3", tags: ["度量"] },
    { id: "t-17", zh: "段级合并", en: "section-level merge", station: 4,
      definition: "以产物内的块标记为单位做差异比对与选择，而非整文件二选一。", example: "改了一行不必做全文件决策，只对「行为规则」这一段选择以谁为准。",
      related: ["t-12"], source: "分析文 §4.5", tags: ["治理"] },
    { id: "t-18", zh: "本地事件台账", en: "local event ledger", station: 4,
      definition: "append-only 的本机事件记录，只在本机、可清空、不出网，是飞轮圈数的机读源。", example: "台账里 23 条 injection_confirmed，就是注入次数的来源。",
      related: ["t-11"], source: "分析文 §4.3", tags: ["度量"] }
  ];

  /* ---- 扩展种子词条：紧凑写法 → 完整对象（合计 109 条，与 stats.terms 一致） ---- */
  var termExtra = [
    ["意图", "intent", "本意", 1, "人在动手前想要达成的那件事，是整条链路的源头。", "「意图只有一句话：把这周的三张日报合成一张周报。」", "基础"],
    ["上下文工程", "context engineering", "上下文设计", 1, "决定在有限的上下文窗口里放什么、按什么顺序放、放多少的实践。", "与其把提示词写得更长，不如做上下文工程：把无关的三百行日志挪出去。", "基础"],
    ["验收", "acceptance", "确认", 1, "人对照可判定标准检查产物是否合格的动作，是 vibe coding 里不可外包的一步。", "我不审过程，只验收：三条标准有一条不过就打回。", "基础"],
    ["胶水代码", "glue code", "粘合层", 1, "为把两个工具接起来而写的少量过渡代码，越少越好。", "真正手写的只有 18 行胶水代码，其余都是生成后审过的。", "基础"],
    ["一次性脚本", "throwaway script", "临时脚本", 1, "用完即弃、不进入资产库的脚本；它的归宿是删掉或被提炼成提示词。", "用 Python 拼了个一次性脚本跑完迁移，第二天就删了。", "基础"],
    ["原型", "prototype", "样机", 1, "用来验证判断而非直接上线的版本，允许粗糙。", "先用可点击原型把流程跑通，再决定要不要写实现。", "基础"],
    ["自然语言接口", "natural language interface", "NLI", 1, "用日常语言而非代码操作软件的那层交互。", "自然语言接口把「怎么做」换成「要什么」，代价是结果不确定。", "基础"],
    ["代理", "agent", "智能体", 1, "能自主规划并调用工具完成多步任务的程序。", "编码代理自己读了三个文件、跑了测试，才回来报告。", "基础"],
    ["任务拆解", "task decomposition", "拆分", 1, "把大目标切成可独立验收的小步骤。", "任务拆解到每步半小时内能验收，长会话才不会跑偏。", "基础"],

    ["系统提示", "system prompt", "系统指令", 2, "平台在会话最前面注入的行为层指令，优先级高于用户提示。", "系统提示里写了「先问再答」，它这一轮才没有直接开写。", "上下文"],
    ["用户提示", "user prompt", "用户指令", 2, "人发出的那一轮指令，通常携带本次任务的具体变量。", "同一条用户提示换个平台结果差别很大——差异在系统提示层。", "上下文"],
    ["变量", "variable", "占位符", 2, "提示词里用 {{name}} 标出的待填位置，是模板复用的关键。", "把仓库路径提成变量，这条提示词才能给五个项目用。", "上下文"],
    ["少样本示例", "few-shot example", "示例", 2, "在提示词里给出输入输出样例，让模型照样子做。", "给了两个少样本示例之后，输出格式终于稳定了。", "上下文"],
    ["结构化输出", "structured output", "结构化返回", 2, "要求模型按固定 schema 返回，便于机读。", "强制结构化输出之后，解析失败从每周三次降到零。", "上下文"],
    ["模式", "schema", "结构定义", 2, "对数据形状的显式约定，是结构化输出的判定依据。", "schema 里字段可选性写清楚，才不会每次多出个 null。", "上下文"],
    ["工具调用", "tool use", "function calling", 2, "模型请求执行外部函数并接收返回结果的机制。", "它靠工具调用读文件，而不是靠我粘贴内容。", "上下文"],
    ["MCP", "Model Context Protocol", "模型上下文协议", 2, "一套让外部工具与数据源以统一方式接入模型的开放协议。", "接一个 MCP 服务，六个工具一起进来了。", "上下文"],
    ["检索增强生成", "RAG", "检索增强", 2, "先检索相关资料再生成的模式，用外部知识补上下文。", "RAG 把术语表检索进来，它就不会自造名词了。", "上下文"],
    ["代码库索引", "codebase index", "代码索引", 2, "对仓库做的可检索结构，用于定位符号与依赖。", "重建代码库索引之后，「改这个方法会影响谁」才有答案。", "上下文"],
    ["符号引用", "symbol reference", "符号", 2, "按名字而非位置引用代码元素，重构时才不容易断。", "用符号引用而不是行号，插入一行不会让引用失效。", "上下文"],
    ["上下文预算", "context budget", "预算", 2, "一次会话可分配给各部分的 token 额度，需要主动分配。", "上下文预算的 40% 给规则，20% 给代码，剩下留给输出。", "上下文"],
    ["截断", "truncation", "砍断", 2, "超出窗口时被丢掉的尾部内容，常表现为「它忘了前面说过的话」。", "日志被截断了，所以它看不到最初那条报错。", "上下文"],
    ["压缩", "compaction", "上下文压缩", 2, "用摘要替代原文以腾出窗口空间，会损失细节。", "压缩之后它还记得结论，却忘了得出结论的证据。", "上下文"],
    ["会话", "session", "对话", 2, "一次连续的交互过程，长会话是漂移的高发区。", "第 60 轮会话里它开始自作主张改风格。", "上下文"],
    ["多轮退化", "multi-turn degradation", "长会话退化", 2, "轮次增加导致遵循度下降的现象。", "多轮退化不是因为模型变笨，是噪声把约束挤了出去。", "上下文"],
    ["首轮定调", "first-turn anchoring", "首轮锚定", 2, "第一轮指令对后续全部输出的强约束作用。", "首轮定调没做好，后面十轮都在纠偏。", "上下文"],
    ["块标记", "block marker", "段落标记", 2, "产物里标识受管区段起止的注释，是段级合并的边界。", "只重写块标记之间的那段，别动我自己的部分。", "上下文"],
    ["噪声", "noise", "上下文噪声", 2, "与当前任务无关却占用窗口的内容。", "把构建日志当上下文就是纯噪声。", "上下文"],

    ["需求澄清", "requirement clarification", "澄清", 3, "在动手前把目标、用户、约束问清楚的阶段。", "需求澄清花了二十分钟，省下两天返工。", "流程"],
    ["用户故事", "user story", "故事", 3, "以「作为…我希望…以便…」描述的需求单元。", "用户故事写成可验收的三句话，评审才有抓手。", "流程"],
    ["验收标准", "acceptance criteria", "AC", 3, "判定需求是否完成的可检验条件，通常可逐条勾选。", "三条验收标准，两条能自动验，一条人工看。", "流程"],
    ["PRD", "Product Requirements Document", "产品需求文档", 3, "描述做什么、为什么、不做什么的产品文档。", "PRD 里那句「不做协作编辑」挡掉了后面三次范围蔓延。", "流程"],
    ["规格", "spec", "规格说明", 3, "比 PRD 更接近实现、可被工具消费的需求描述。", "spec 写清输入输出契约，生成代码才有验收基准。", "流程"],
    ["计划", "plan", "实施计划", 3, "把 spec 拆成有序步骤与检查点的执行方案。", "计划第七步挂了检查点，回滚只回到那一站。", "流程"],
    ["检查点", "checkpoint", "存档点", 3, "流程中可返回的确定状态，是回滚的落点。", "每个检查点都带指纹，verify 才能判断有没有被改过。", "流程"],
    ["里程碑", "milestone", "节点", 3, "对外可宣布的阶段性成果。", "里程碑不按天数定，按验收标准定。", "流程"],
    ["回顾", "retro", "复盘", 3, "事后审视过程与结果的固定动作，是回流候选的来源。", "回顾里那条「每次都要我提醒备份」就是回流候选。", "流程"],
    ["站", "station", "阶段站", 3, "流程模板里的一个阶段，带进入条件与出口清单。", "这一站的出口清单三项全勾，才允许进下一站。", "流程"],
    ["流程模板", "flow template", "模板", 3, "把一组站按顺序编排好的可复用流程定义。", "七个流程模板覆盖了从需求到交付的常见路径。", "流程"],
    ["变更集", "changeset", "改动集", 3, "一次提交所包含的全部改动及其说明。", "变更集只做一件事，评审才能十分钟内完成。", "流程"],
    ["提交", "commit", "提交", 3, "把变更固化到版本库的动作，带提交信息。", "提交信息写为什么，diff 自己会说改了什么。", "流程"],
    ["拉取请求", "pull request", "PR", 3, "请求把分支合并入主线的评审单元。", "PR 描述里贴验收标准，评审者不用猜。", "流程"],
    ["评审", "review", "代码评审", 3, "由人或代理对变更做系统检查。", "评审先看漂移再看缺陷，顺序反了就容易被细节带走。", "流程"],
    ["驾驶-导航", "driver-navigator", "驾驶员-领航员", 3, "一人操作一人观察思考的结对方式，人机协作常取其形。", "我当领航员：它开车，我盯路线和边界。", "流程"],
    ["意图编译", "intent compilation", "意图转译", 3, "把自然语言意图翻译成可执行上下文与步骤的过程。", "意图编译的产物不是代码，是一份带检查点的计划。", "流程"],
    ["反馈环", "feedback loop", "反馈回路", 3, "产出回给生产者以修正下一轮输出的闭环。", "反馈环越短质量越稳：跑测试就是最快的环。", "流程"],
    ["迭代", "iteration", "迭代", 3, "以小步前进、每步可验收的方式推进。", "一次迭代只解决一个问题，别把三个改动混在一起。", "流程"],
    ["范围蔓延", "scope creep", "范围膨胀", 3, "执行中不断增加未规划需求的现象。", "每次「顺手也改一下」都是范围蔓延的开头。", "流程"],
    ["最小可用", "minimal viable", "MVP", 3, "能验证核心判断所需的最小实现。", "最小可用版本只要三步：生成、干跑、注入。", "流程"],
    ["测试驱动", "test-driven development", "TDD", 3, "先写失败测试再写实现的开发方式。", "测试驱动在这里的收益是：验收标准变成了代码。", "流程"],
    ["红-绿-重构", "red-green-refactor", "红绿重构", 3, "先看到失败、再让它通过、最后整理结构的循环。", "红-绿-重构每一步都可回退，所以敢大步改。", "流程"],
    ["变更日志", "changelog", "更新记录", 3, "按版本记录改了什么、为什么的记录文件。", "变更日志里每条都对应一个真实用户的痛点。", "流程"],
    ["语义化版本", "semantic versioning", "SemVer", 3, "用 主.次.补丁 表达兼容性的版本约定。", "语义化版本让「升个小版本要不要重测」有确定答案。", "流程"],
    ["兼容性矩阵", "compatibility matrix", "兼容矩阵", 3, "资产与平台之间的支持关系表，注入前的判定依据。", "兼容性矩阵里 Cursor 那格是黄标：部分支持。", "流程"],
    ["平台适配器", "platform adapter", "适配器", 3, "把标准包翻译成某平台文件形态的转换层。", "换平台只换适配器，资产库一行不改。", "流程"],
    ["回退", "fallback", "兜底", 3, "主路径失败时的替代方案。", "每个平台适配器都要有回退：至少导出纯文件。", "流程"],

    ["幂等", "idempotent", "幂等性", 4, "同一操作重复执行结果一致，不会累积副作用。", "注入必须幂等：跑两遍和跑一遍的磁盘状态相同。", "治理"],
    ["指纹", "fingerprint", "哈希", 4, "内容的短摘要，用于判断「有没有被改过」。", "指纹不一致，就是有人动过受管文件。", "治理"],
    ["锁文件", "lock file", "lock", 4, "记录期望状态与实际指纹的受管清单。", "lock 里记着这个文件该长什么样，verify 拿它当基准。", "治理"],
    ["备份", "backup", "自动备份", 4, "改动前留存原状的行为，是冲突保护的第一层。", "自动备份放在 .openvibe/backup/，带时间戳。", "治理"],
    ["冲突", "conflict", "冲突", 4, "本地改动与包期望不一致的状态，需要人决策。", "409 不是错误，是在问你「这段以谁为准」。", "治理"],
    ["退场", "clean / cleanup", "清理", 4, "移除已无人引用的受管内容，只删未被改动的部分。", "退场跑完少了三个文件，都是我确认过的。", "治理"],
    ["回滚", "rollback", "回退", 4, "把包恢复到上一个已知良好版本的动作。", "回滚到 1.2.0 只花了三秒，因为资产都在库里。", "治理"],
    ["升级", "upgrade", "升级", 4, "把已注入项目迁移到包的新版本。", "升级走增量注入，不会整文件覆盖。", "治理"],
    ["迁移", "migration", "迁移", 4, "跨版本或跨平台搬移状态与数据的过程。", "迁移最怕隐式假设，所以每步都干跑。", "治理"],
    ["契约", "contract", "接口契约", 4, "双方必须遵守的显式约定，破坏它需要版本号。", "schemaVersion 1→2 是 A 级契约变更，要重新签。", "治理"],
    ["不可变", "immutable", "只读", 4, "一旦发布就不再修改的属性，是信任的基础。", "库版本不可变：1.3.0 发布后，内容再也不变。", "治理"],
    ["确定性", "deterministic", "可复现", 4, "相同输入必然得到相同输出的属性。", "同一版本包重复生成，字节级一致——这才叫确定性。", "治理"],
    ["可复现", "reproducible", "可重现", 4, "别人能在自己机器上得到同样结果的能力。", "可复现的交付才敢在 CI 里跑 verify。", "治理"],
    ["可观测", "observability", "可观测性", 4, "从外部判断系统内部状态的能力。", "没有可观测性，你只能靠猜它有没有漂移。", "治理"],
    ["遥测", "telemetry", "上报", 4, "采集使用情况外传的行为，默认关闭且需明示。", "遥测关着：统计只在本机，你能自己看。", "治理"],
    ["本机优先", "local-first", "本地优先", 4, "数据与状态默认留在用户设备上的设计取向。", "本机优先意味着断网也能查术语、能注入。", "治理"],
    ["数据主权", "data sovereignty", "数据自主", 4, "用户对自己数据的控制权与处置权。", "数据主权不是功能，是默认值。", "治理"],
    ["单点故障", "single point of failure", "SPOF", 4, "一处失效导致全局停摆的结构性弱点。", "全押一个平台就是单点故障，所以资产库工具无关。", "治理"],
    ["供应商锁定", "vendor lock-in", "锁定", 4, "迁移成本高到无法离开某供应商的状态。", "纯文件 + 兼容矩阵是对供应商锁定最便宜的解药。", "治理"],
    ["工具无关", "tool-agnostic", "平台中立", 4, "不依赖特定工具即可使用与迁移。", "资产库工具无关：今天在 Claude Code，明天在 Trae。", "治理"],
    ["纯文件", "pure file", "文件形态", 4, "只用普通文件与目录表达状态，无需专有服务。", "纯文件方案的好处是 git 就能版本化。", "治理"],
    ["可移植", "portable", "可迁移", 4, "能在不同环境间低成本搬移。", "可移植的包才敢发给同事，他不用装你的工具链。", "治理"],
    ["git 版本化", "git-versioned", "纳入 git", 4, "用 git 管理资产与产物历史的方式。", "包 git 版本化之后，回滚就是一次 checkout。", "治理"],
    ["注册表", "registry", "登记表", 4, "记录可用资产及其元数据的清单。", "注册表只记元数据，内容仍是纯文件。", "治理"],
    ["依赖图", "dependency graph", "依赖关系", 4, "资产之间引用关系的图结构，用于判断影响面。", "看一眼依赖图就知道这条术语被五个提示词引用。", "治理"],
    ["循环依赖", "circular dependency", "环", 4, "互相引用导致无法线性解析的关系。", "组包时检出循环依赖，直接拒绝生成。", "治理"],
    ["告警", "alert", "警告", 4, "对异常状态的显式提示，必须可定位可处置。", "告警要能点到具体文件和行，否则等于没有。", "治理"],
    ["度量", "metric", "指标", 4, "可量化观察的量，是「变好了」的证据。", "度量只留三个：注入次数、密度、回滚率。", "治理"],
    ["飞轮", "flywheel", "增长飞轮", 4, "用一次产出加速下一次产出的正循环结构。", "飞轮转一圈的标志是一次完整回流，不是一次使用。", "治理"],
    ["回流", "reflow", "反哺", 4, "把使用中发现的模式送回资产库的动作。", "回流候选要能指回原始事件，否则不可评审。", "治理"],
    ["定标", "calibration", "校准", 4, "用真实结果修正判断标准的过程。", "定标之后，「够好了」有了可复述的定义。", "治理"],
    ["资产", "asset", "资产", 4, "库中被管理、可复用、可版本化的内容单元。", "提示词、Skill、术语都是资产，行为不是。", "治理"],
    ["素材", "material", "物料", 4, "组包时被选中的资产快照，是包的组成单位。", "素材一旦进包就冻结，库里再改也不影响已发布的版本。", "治理"],
    ["覆盖率", "coverage", "覆盖", 4, "资产被实际引用或使用的比例。", "覆盖率低于三成的长段落，就是该裁剪的对象。", "治理"],
    ["弃用", "deprecation", "废弃预告", 4, "宣布某资产将停止支持但暂保留的过渡状态。", "弃用要写迁移路径，只标红不管用。", "治理"]
  ];
  termExtra.forEach(function (r, i) {
    terms.push({
      id: "t-" + (19 + i),
      zh: r[0], en: r[1], aliases: r[2] ? String(r[2]).split("|") : [],
      station: r[3], definition: r[4], example: r[5],
      related: [], source: "种子词表", tags: r[6].split("|")
    });
  });

  var roadmap = [
    { name: "第 1 站 · 起步", desc: "先把嘴上的话变成可复用的指令" },
    { name: "第 2 站 · 上下文", desc: "规则怎么写、怎么不被稀释" },
    { name: "第 3 站 · 流程", desc: "从写对一段到走完一站" },
    { name: "第 4 站 · 治理", desc: "让「它真的变好了」可被证明" }
  ];
  roadmap.forEach(function (r, i) {
    r.termIds = terms.filter(function (t) { return t.station === i + 1; }).map(function (t) { return t.id; });
  });

  /* ---------------- M4 回流候选（Phase 2 只做登记） ---------------- */
  var reflows = [
    { id: "rf-01", title: "注入前自动备份提醒", from: "回顾 · 2026-09-21", hits: 6, state: "reviewing",
      evidence: "3 次 409 都是因为没开自动备份；事件台账 injection_failed 前后无 backup_created",
      target: "M6 组包向导默认勾选「注入前备份」", owner: "owner" },
    { id: "rf-02", title: "术语新增走「先查后建」", from: "日志高频", hits: 11, state: "candidate",
      evidence: "11 次 term_created 中有 4 次与既有别称重复（t-31 / t-58 / t-72 / t-90）",
      target: "M3 新增词条前先做别名命中检索", owner: "owner" },
    { id: "rf-03", title: "长会话主动提醒 compaction", from: "回顾 · 2026-09-28", hits: 4, state: "candidate",
      evidence: "超过 40 轮的会话里 rule_violation 占比从 6% 升到 19%",
      target: "M5 流程站出口清单加一项「会话轮次」", owner: "—" },
    { id: "rf-04", title: "干跑结果一键复制为 PR 描述", from: "使用观察", hits: 3, state: "candidate",
      evidence: "用户连续 3 次手动把 dry-run 计划粘进 PR 描述",
      target: "M6 注入计划加「复制为 Markdown」", owner: "owner" },
    { id: "rf-05", title: "Skill 扫描结果按平台分组", from: "日志高频", hits: 5, state: "reviewing",
      evidence: "扫描 26 个目录后用户平均滚动 4.2 屏才找到目标平台",
      target: "M2 扫描结果加平台筛选", owner: "owner" },
    { id: "rf-06", title: "版本对比支持「只看结构变化」", from: "回顾 · 2026-10-02", hits: 2, state: "candidate",
      evidence: "两次 diff 都只关心标题层级，被正文噪声淹没",
      target: "M1 diff 视图加结构模式", owner: "—" },
    { id: "rf-07", title: "术语路线图允许自定义站", from: "用户反馈", hits: 2, state: "rejected",
      evidence: "与「四站由协议发布」冲突，自定义会导致跨项目术语不一致",
      target: "不做；改为允许隐藏已掌握站点", owner: "owner" },
    { id: "rf-08", title: "事件台账支持导出 CSV", from: "回顾 · 2026-09-14", hits: 3, state: "archived",
      evidence: "已由 `openvibe events --format csv` 覆盖，UI 重复建设",
      target: "关闭，指向 CLI", owner: "owner" },
    { id: "rf-09", title: "组包时提示 token 预算", from: "使用观察", hits: 7, state: "reviewing",
      evidence: "7 次生成后密度高于 60，用户随后手动删素材",
      target: "M6 第 4 步加预算滑块与超限警告", owner: "owner" },
    { id: "rf-10", title: "冲突决策可批量「全部以包为准」", from: "日志高频", hits: 4, state: "candidate",
      evidence: "同一会话内 4 次逐个确认相同类型冲突",
      target: "M6 决策页加批量按钮（保留逐段模式）", owner: "—" },
    { id: "rf-11", title: "看板卡片显示所属流程站", from: "使用观察", hits: 2, state: "candidate",
      evidence: "用户需要回到流程模板确认当前站，平均 1.8 次/会话",
      target: "M5 看板卡片加站徽标", owner: "owner" }
  ];

  /* ---------------- CLI 命令目录（终端实验室用） ---------------- */
  var cliCommands = [
    { cmd: "openvibe --help", group: "系统", desc: "列出全部命令与全局参数", risk: "safe",
      out: [
        "OpenVibe 灵典 v0.2.0 · 把人的意图编译成项目上下文",
        "",
        "用法：openvibe <command> [options]",
        "",
        "资产   prompts | skills | terms | playbooks(Phase 2)",
        "流程   project | flow | log",
        "交付   pack | inject | verify | rollback | clean",
        "系统   scan | events | doctor | config",
        "",
        "全局参数：--json  --dry-run  --pack <name@version>  --adapter <id>  -C <dir>",
        "",
        "提示：注入与回滚必须经 CLI 完成；所有破坏性操作默认 dry-run。"
      ] },
    { cmd: "openvibe scan", group: "资产", desc: "扫描本机 skill 目录并登记", risk: "safe",
      out: [
        "扫描 4 个目录（~/.claude/skills ~/.cursor/rules ~/.openvibe/skills ~/Code/tools）",
        "  ~/.claude/skills          6 个 SKILL.md",
        "  ~/.cursor/rules          12 个 .mdc",
        "  ~/.openvibe/skills        1 个 SKILL.md",
        "  ~/Code/tools              !  ELOOP：符号链接成环，已跳过 2 项",
        "",
        "登记 6 个 skill 候选 → openvibe skills 查看",
        "未改动任何文件。加 --write 后写入注册表。"
      ] },
    { cmd: "openvibe terms list --station 4", group: "资产", desc: "按路线站列出术语", risk: "safe",
      out: [
        "第 4 站 · 治理（43 条）",
        "  t-11  有效上下文密度  effective context density",
        "  t-12  受管文件        managed file",
        "  t-13  干跑            dry-run",
        "  t-14  三方一致性      three-way consistency",
        "  … 共 43 条，--json 可机读",
        "",
        "生成路线图：openvibe terms roadmap"
      ] },
    { cmd: "openvibe pack create default", group: "交付", desc: "由向导结果生成标准包", risk: "safe",
      out: [
        "读取向导结果（5 资产组 / 6 平台 / 7 术语）",
        "渲染 4 个产物 → CLAUDE.md  TERMS.md  CHECKLIST.md  skills/",
        "计算指纹 sha256:9f2c…",
        "",
        "已生成 default@1.4.0（38.2 KB · 约 9,860 token）",
        "同一版本重复生成指纹一致 → 可复现 ✓",
        "",
        "干跑注入：openvibe inject ~/proj-a --pack default@1.4.0"
      ] },
    { cmd: "openvibe inject ~/proj-a --pack default", group: "交付", desc: "干跑注入（默认 dry-run）", risk: "warn",
      out: [
        "目标 ~/proj-a · 适配器 claude-code · 包 default@1.3.0",
        "",
        "计划（不会写入）：",
        "  + CLAUDE.md        新建（含 3 个受管块）",
        "  ~ TERMS.md         已存在 · 本地有改动 → 需决策",
        "  ~ CHECKLIST.md     已存在 · 与包一致 → 跳过",
        "  + skills/          2 个文件",
        "",
        "1 处冲突需人工决策。加 --yes 也不够：冲突必须逐段确认。",
        "加 --apply 进入写入（写入前自动备份到 .openvibe/backup/）。"
      ] },
    { cmd: "openvibe inject ~/proj-a --pack default --apply", group: "交付", desc: "真正写入（含自动备份）", risk: "danger",
      out: [
        "备份 .openvibe/backup/2026-10-09T1023/（4 个文件）",
        "写入 CLAUDE.md（3 块）· skills/（2 个）",
        "TERMS.md 段级合并：「术语表」段取包，「项目用语」段取本地",
        "更新 .openvibe/lock.json（期望指纹已登记）",
        "",
        "注入完成 default@1.3.0 → ~/proj-a",
        "事件已追加到本机台账（injection_confirmed）。"
      ] },
    { cmd: "openvibe verify ~/proj-a", group: "交付", desc: "三方一致性校验", risk: "safe",
      out: [
        "比对 包内容 / lock 期望 / 磁盘实际",
        "  CLAUDE.md     一致",
        "  TERMS.md      不一致（本地改动了 1 段）",
        "  CHECKLIST.md  一致",
        "  skills/       一致",
        "",
        "结论：DRIFT · 1 个文件偏离期望",
        "处理：openvibe inject --apply 重新对齐，或 openvibe rollback 回退。"
      ] },
    { cmd: "openvibe rollback ~/proj-a --to 1.2.0", group: "交付", desc: "回滚到上一个版本", risk: "danger",
      out: [
        "目标版本 default@1.2.0（库内不可变，可直接取用）",
        "备份当前状态 → .openvibe/backup/2026-10-09T1120/",
        "增量回写 2 个文件，删除 1 个仅在 1.3.0 引入的受管文件",
        "更新 lock.json → 1.2.0",
        "",
        "回滚完成。未删除任何本地新增内容。",
        "验证：openvibe verify ~/proj-a → CONSISTENT"
      ] },
    { cmd: "openvibe clean ~/proj-a", group: "交付", desc: "退场：删除无人引用的受管内容", risk: "danger",
      out: [
        "扫描受管文件 6 个，其中 2 个已无任何引用：",
        "  - CHECKLIST.md（0 引用）",
        "  - skills/legacy-lint.md（0 引用）",
        "",
        "这两个文件本地均未改动，可安全删除。",
        "此操作不可撤销（已备份）。确认请输入：yes"
      ] },
    { cmd: "openvibe events --format csv", group: "系统", desc: "导出本机事件台账", risk: "safe",
      out: [
        "本机台账（append-only · 不上报 · 可清空）",
        "ts,kind,object,result",
        "2026-10-08T20:14,injection_confirmed,default@1.3.0,ok",
        "2026-10-08T20:14,verify_run,proj-a,drift",
        "… 共 23 条，其中 injection_confirmed 11 条",
        "",
        "飞轮圈数 = 完整回流次数 = 2"
      ] },
    { cmd: "openvibe doctor", group: "系统", desc: "环境自检", risk: "safe",
      out: [
        "node      v22.11.0   ✓",
        "git       2.39.3     ✓",
        "资产库    ~/.openvibe ✓ 109 术语 / 21 提示词 / 6 skill",
        "平台      claude-code ✓ cursor △（部分支持）",
        "遥测      已关闭（本机统计）✓",
        "",
        "结论：可用。1 项警告：Cursor 适配器缺少 rules 目录。"
      ] }
  ];

  /* ---------------- Skill 中心 M2 ---------------- */
  var skills = [
    { name: "spec-kit-conventions", source: "本地扫描", version: "1.4.0", sha256: "9f2c1ab47e0d5b83c6a1f4e2d7089b3c5a6e7f8012345678abcdef0123456789",
      targets: ["Claude Code", "Cursor"], status: "active", updated: "2026-09-21" },
    { name: "openvibe-pack-audit", source: "手动登记", version: "0.9.2", sha256: "3b7d9e15c2a4f680b1d3e5f7092a4c6b8d0e1f2a3b4c5d6e7f8091a2b3c4d5e6",
      targets: ["Claude Code"], status: "active", updated: "2026-09-30" },
    { name: "commit-message-cn", source: "本地扫描", version: "2.1.1", sha256: "c4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d",
      targets: ["Claude Code", "CodeBuddy", "Trae"], status: "active", updated: "2026-09-18" },
    { name: "test-pyramid-guard", source: "GitHub", version: "0.3.0", sha256: "7a8b9c0d1e2f30415263748596a7b8c9d0e1f2031425364758697a8b9c0d1e2f",
      targets: ["Cursor"], status: "active", updated: "2026-09-26" },
    { name: "changelog-writer", source: "本地扫描", version: "1.0.3", sha256: "1f2e3d4c5b6a79887766554433221100ffeeddccbbaa9988776655443322110",
      targets: ["Claude Code"], status: "stale", updated: "2026-04-11" },
    { name: "rules-sync-helper", source: "手动登记", version: "0.1.0", sha256: "5566778899aabbccddeeff00112233445566778899aabbccddeeff0011223344",
      targets: [], status: "active", updated: "2026-10-01" }
  ];

  var scanDirs = [
    { path: "~/.claude/skills", found: 3, state: "ok" },
    { path: "~/projects/.claude/skills", found: 2, state: "ok" },
    { path: "~/archive/old-skills", found: 0, state: "warn", warn: "符号链接环（ELOOP）：已降级为 warning，未中断整次扫描" },
    { path: "~/.openvibe/skills", found: 1, state: "ok" }
  ];

  /* ---------------- 流程模板 M5 ---------------- */
  var flowTemplates = [
    { id: "f-light", name: "个人轻量流", kind: "light", stages: [
      { name: "启动", checklist: ["选定流程模板", "选定标准包并干跑注入", "确认上下文文件已生成"], artifacts: ["CLAUDE.md"] },
      { name: "开发", checklist: ["当日清单已勾", "提示词已填参复制", "DEV 日志已追加"], artifacts: ["DEV-LOG"] },
      { name: "复盘", checklist: ["候选技巧已确认", "新词已入术语库", "提示词改进已回写"], artifacts: ["CHECK 报告"] }
    ]},
    { id: "f-spec", name: "Spec 驱动流", kind: "spec_driven", stages: [
      { name: "需求", checklist: ["用户故事可判定", "非目标已写明"], artifacts: ["需求说明"] },
      { name: "PRD", checklist: ["验收标准可机判或一眼判", "风险表已填"], artifacts: ["PRD.md"] },
      { name: "Spec", checklist: ["接口契约已冻结", "数据模型已定"], artifacts: ["spec.md"] },
      { name: "计划", checklist: ["任务已拆到 ≤2 人日", "依赖顺序已排"], artifacts: ["tasks.md"] },
      { name: "实现", checklist: ["上下文文件已注入", "测试基线已跑绿", "块标记未被绕过"], artifacts: ["源码 + 测试"] },
      { name: "审查", checklist: ["规则漂移已查", "破坏性变更已复核"], artifacts: ["审查记录"] },
      { name: "复盘", checklist: ["回流候选已确认入库", "模板缺陷已登记"], artifacts: ["CHECK 报告"] }
    ]},
    { id: "f-retro", name: "复盘流", kind: "retro", stages: [
      { name: "过清单", checklist: ["逐阶段勾选", "未完成项给出原因"], artifacts: ["清单快照"] },
      { name: "写报告", checklist: ["量化产出", "列回流候选"], artifacts: ["CHECK 报告"] },
      { name: "回流", checklist: ["候选已人工确认", "下个包版本已含改进"], artifacts: ["新资产"] },
      { name: "归档", checklist: ["日志编号连续", "关联文件可追溯"], artifacts: ["归档记录"] }
    ]},
    { id: "f-gate", name: "发布闸问答", kind: "custom", stages: [
      { name: "冻结", checklist: ["内容已冻结", "CI 三平台全绿"], artifacts: ["冻结点 commit"] },
      { name: "核验", checklist: ["golden 无 diff", "seed:check 通过"], artifacts: ["核验输出"] },
      { name: "发布", checklist: ["npm 真发布", "tag 已推"], artifacts: ["npm / release"] },
      { name: "回读", checklist: ["装包可用", "首条命令跑通"], artifacts: ["回读证据"] }
    ]},
    { id: "f-clarify", name: "需求澄清到 PRD", kind: "custom", stages: [
      { name: "澄清", checklist: ["两段式问参已跑", "假设已逐条标注"], artifacts: ["澄清记录"] },
      { name: "收敛", checklist: ["一句话问题陈述", "三条验收"], artifacts: ["问题陈述"] },
      { name: "成文", checklist: ["三段式结构齐", "冲突已指出"], artifacts: ["PRD.md"] }
    ]},
    { id: "f-bug", name: "Bug 根因排查", kind: "custom", stages: [
      { name: "现象", checklist: ["最小复现已固定", "日志已留全"], artifacts: ["复现步骤"] },
      { name: "追问", checklist: ["五问法已走", "每问有证据"], artifacts: ["因果链"] },
      { name: "修复", checklist: ["最小修复", "回归测试点已加"], artifacts: ["patch + test"] },
      { name: "归档", checklist: ["技巧候选已提", "同类问题已检索"], artifacts: ["技巧条目"] }
    ]},
    { id: "f-weekly", name: "周度复盘问答", kind: "custom", stages: [
      { name: "问答", checklist: ["四问已答", "重复劳动已点名"], artifacts: ["周记"] },
      { name: "提炼", checklist: ["候选资产已列", "优先级已排"], artifacts: ["候选清单"] },
      { name: "入库", checklist: ["已人工确认", "标签已打"], artifacts: ["新资产"] }
    ]}
  ];

  /* ---------------- 项目 M5 ---------------- */
  var projects = [
    {
      id: "prj-1", name: "openvibe-web", path: "~/projects/openvibe", templateId: "f-spec", stageIndex: 4,
      pack: { name: "default", version: "1.3.0" }, health: "注意",
      note: "「实现」站有 2 项未勾；上次注入后用户手改过 CLAUDE.md 的行为规则段。",
      tasks: [
        { id: "k1", title: "受管块标记升为契约", stage: "实现", status: "doing" },
        { id: "k2", title: "段级 diff 只读展示", stage: "实现", status: "todo" },
        { id: "k3", title: "verify 命令四态用例", stage: "实现", status: "todo" },
        { id: "k4", title: "golden 重基（待 A 级签字）", stage: "审查", status: "todo" },
        { id: "k5", title: "契约冻结面复核", stage: "审查", status: "done" },
        { id: "k6", title: "数据模型定稿", stage: "Spec", status: "done" },
        { id: "k7", title: "验收标准可机判化", stage: "PRD", status: "done" }
      ],
      logs: [
        { no: 12, type: "DEV", at: "2026-10-02 09:41", body: "段级 diff 的只读展示已接上骨架：对比「包渲染段文本」与「磁盘按标记切出的段文本」，整文件 sha 判定不变。", files: "packages/core/src/inject/planner.ts", cmd: "npx vitest run inject", result: "18 passed" },
        { no: 11, type: "DEV", at: "2026-09-30 16:20", body: "verify 四态判定落地，人为造中间态可被检出。", files: "packages/core/src/inject/verify.ts", cmd: "npx vitest run verify", result: "9 passed" },
        { no: 10, type: "CHECK", at: "2026-09-28 10:00", body: "40 轮检查：发现第 38 轮起有规则漂移迹象（绕开块标记），已登记为技巧候选。", files: "docs/decisions.md", cmd: "git diff --stat", result: "3 files changed" }
      ]
    },
    {
      id: "prj-2", name: "lingspot-site", path: "~/projects/lingspot", templateId: "f-light", stageIndex: 1,
      pack: { name: "default", version: "1.2.0" }, health: "健康",
      note: "轻量流跑到「开发」站，清单全勾。",
      tasks: [
        { id: "k8", title: "首页文案定稿", stage: "开发", status: "done" },
        { id: "k9", title: "术语卡组件", stage: "开发", status: "doing" },
        { id: "k10", title: "选定模板与包", stage: "启动", status: "done" }
      ],
      logs: [
        { no: 4, type: "DEV", at: "2026-10-01 11:12", body: "术语卡组件接上词库数据，别名可命中。", files: "src/components/TermCard.tsx", cmd: "pnpm test", result: "12 passed" },
        { no: 3, type: "DEV", at: "2026-09-29 09:30", body: "首启干跑注入 default 包，冲突 0。", files: ".openvibe/pack.lock.json", cmd: "openvibe sync . --dry-run", result: "8 files planned" }
      ]
    },
    {
      id: "prj-3", name: "internal-cli", path: "~/projects/icli", templateId: "f-bug", stageIndex: 1,
      pack: { name: "team-backend", version: "0.9.2" }, health: "注意",
      note: "根因追问停在第三层，缺一条复现证据。",
      tasks: [
        { id: "k11", title: "补 ELOOP 复现", stage: "追问", status: "doing" },
        { id: "k12", title: "固定最小复现", stage: "现象", status: "done" },
        { id: "k13", title: "扫描逐根隔离", stage: "修复", status: "todo" }
      ],
      logs: [
        { no: 7, type: "DEV", at: "2026-09-27 14:55", body: "确认符号链接环导致整次扫描 500，修法参照 port-scan 的降级形态。", files: "packages/core/src/repos/skills.ts", cmd: "ln -s loop loop; openvibe scan", result: "ELOOP 复现" },
        { no: 6, type: "CHECK", at: "2026-09-25 09:00", body: "已知局限第 3 条：看板拖拽无自动化证据，须在 Phase 2 补。", files: "README.md", cmd: "grep -n '已知局限' README.md", result: "命中 1 处" }
      ]
    }
  ];

  /* ---------------- 标准包 M6 ---------------- */
  var packs = [
    { id: "pk-default", name: "default", version: "1.3.0", builtin: true,
      manifest: { promptIds: ["p-001", "p-002", "p-003", "p-004", "p-007", "p-008"], skillIds: ["spec-kit-conventions", "commit-message-cn"], termIds: ["t-01", "t-02", "t-04", "t-05", "t-09", "t-10", "t-13"], flowTemplateId: "f-light" },
      sizeKb: 41.2, tokens: 18640 },
    { id: "pk-backend", name: "team-backend", version: "0.9.2", builtin: false,
      manifest: { promptIds: ["p-002", "p-004", "p-005", "p-010"], skillIds: ["test-pyramid-guard"], termIds: ["t-06", "t-07", "t-12", "t-14"], flowTemplateId: "f-spec" },
      sizeKb: 28.7, tokens: 12980 }
  ];

  /* ---------------- 平台 adapter M6 ---------------- */
  var adapters = [
    { id: "claude-code", name: "Claude Code", files: ["CLAUDE.md", "TERMS.md", ".claude/skills/"], note: "专用 adapter" },
    { id: "cursor", name: "Cursor", files: [".cursor/rules/openvibe.mdc"], note: "专用 adapter · frontmatter alwaysApply" },
    { id: "generic-agents", name: "通用 AGENTS", files: ["AGENTS.md", "TERMS.md"], note: "Linux 基金会标准，60k+ 项目" },
    { id: "codebuddy", name: "CodeBuddy", files: ["CODEBUDDY.md"], note: "专用 adapter（CODEBUDDY.md）" },
    { id: "trae", name: "Trae", files: [".trae/rules/openvibe.md"], note: "专用 adapter · v1.2 契约" },
    { id: "minicode", name: "MiniCode", files: ["MINI.md"], note: "专用 adapter（MINI.md）" }
  ];
  var compatMatrix = [
    { name: "zcode", via: "AGENTS.md", strength: "兼容矩阵" },
    { name: "Kimi Code", via: "AGENTS.md", strength: "兼容矩阵 · T6 挂起" }
  ];

  /* ---------------- 本机事件台账（D29） ---------------- */
  var eventKinds = {
    pack_composed: "组包",
    pack_exported: "导出包",
    injection_confirmed: "注入确认",
    injection_conflict_resolved: "冲突已处置",
    stage_advanced: "阶段推进",
    checklist_item_checked: "清单勾选",
    flow_template_run: "模板运行",
    asset_created: "新建资产",
    asset_reflowed: "资产回流",
    stage_view_switched: "视图切换"
  };

  var events = [
    { kind: "injection_confirmed", subject: "default@1.3.0 → openvibe-web", at: "2026-10-02 09:52" },
    { kind: "checklist_item_checked", subject: "openvibe-web / 实现 / 块标记未被绕过", at: "2026-10-02 09:48" },
    { kind: "asset_reflowed", subject: "技巧候选：规则漂移迹象（来自 DEV-0010）", at: "2026-10-01 17:22" },
    { kind: "stage_advanced", subject: "openvibe-web → 实现（5/7）", at: "2026-10-01 16:05" },
    { kind: "injection_conflict_resolved", subject: "CLAUDE.md / 行为规则 → 保留本地", at: "2026-10-01 15:59" },
    { kind: "flow_template_run", subject: "Spec 驱动流 / openvibe-web", at: "2026-10-01 15:31" },
    { kind: "pack_exported", subject: "default@1.3.0", at: "2026-09-30 22:10" },
    { kind: "asset_created", subject: "提示词「重构前置检查清单」", at: "2026-10-01 15:26" },
    { kind: "pack_composed", subject: "default@1.3.0", at: "2026-09-30 21:40" },
    { kind: "stage_view_switched", subject: "packs → 专家视图", at: "2026-09-29 10:14" }
  ];

  /* ---------------- 注入计划（dry-run 演示数据） ---------------- */
  var injectPlan = {
    pack: "default@1.3.0", target: "~/projects/openvibe", platform: "claude-code",
    files: [
      {
        name: "CLAUDE.md", state: "DRIFT", kb: 12.4, tokens: 5240,
        segments: [
          { key: "工作流程", state: "DRIFT", detail: "包 = v1.3，磁盘 = 你改过（2 行）", decision: "keep_local" },
          { key: "行为规则", state: "DRIFT", detail: "包 = v1.3，磁盘 = 你改过（1 行）", decision: "keep_local" },
          { key: "术语表", state: "IN_SYNC", detail: "三方哈希一致" },
          { key: "（段外自由区）", state: "FREE", detail: "块标记之外，永不触碰" }
        ],
        why: "lock 记的哈希 <code>a1b2c3…</code>、磁盘实际 <code>9f3e10…</code>、包渲染 <code>c4d552…</code> ⇒ 判定 DRIFT，需逐段决策。"
      },
      { name: "TERMS.md", state: "IN_SYNC", kb: 8.1, tokens: 3410, segments: [
        { key: "整文件", state: "IN_SYNC", detail: "三方哈希一致" }
      ], why: "三方哈希一致，无需决策。" },
      { name: ".cursor/rules/openvibe.mdc", state: "FOREIGN", kb: 1.2, tokens: 480, segments: [
        { key: "整文件", state: "FOREIGN", detail: "手工新建的文件，绝不删" }
      ], why: "未在 lock 登记 ⇒ FOREIGN，任何情况下不删、不覆盖。" },
      { name: ".openvibe/skills/spec-kit-conventions/", state: "NEW", kb: 4.6, tokens: 1980, segments: [
        { key: "整目录", state: "NEW", detail: "目标不存在，将新建" }
      ], why: "lock 无登记、目标不存在 ⇒ NEW，写入并登记。" }
    ]
  };

  /* ---------------- 成长阶段（D28） ---------------- */
  var stageDefs = [
    { code: "F0", name: "跟随者", mind: "别让我选，告诉我做什么" },
    { code: "F1", name: "实践者", mind: "我想知道为什么，我想挑" },
    { code: "F2", name: "作者", mind: "我要写自己的标准" },
    { code: "F3", name: "定标者", mind: "我要定义别人怎么判断" }
  ];
  var moduleStages = [
    { module: "提示词库", route: "/prompts", stage: 2, next: "自建 1 条非种子提示词并导出", progress: 72 },
    { module: "Skill 中心", route: "/skills", stage: 0, next: "完成 1 次本地扫描", progress: 35 },
    { module: "术语库", route: "/terms", stage: 1, next: "用过 2 个流程模板", progress: 50 },
    { module: "项目与流程", route: "/projects", stage: 1, next: "改过 1 次资产内容", progress: 60 },
    { module: "标准包", route: "/packs", stage: 1, next: "导出 1 个非预置包", progress: 45 }
  ];

  var redlines = [
    "永不隐藏数据 —— 只有排序、预填、折叠默认值的差别，「查看全部」永远一键可达",
    "永不隐藏错误 —— 任何阶段都必须看到失败、漂移、冲突，不为了「简单」而吞错",
    "阶段可见且可解释 —— 界面永远显示「为什么现在是这个视图」，可点开",
    "一键越级 —— 任意页面可切到「专家视图」，且按模块记忆该选择",
    "升级不打断 —— 升级提示是一次性卡片，不是模态框；拒绝后不再打扰"
  ];


  /* ---------------- CLI 速查（设置页） ---------------- */
  var cliRefs = [
    { cmd: "npx openvibe serve --open", desc: "启动本地服务并打开工作台（只听回环）" },
    { cmd: "openvibe sync <project-path> --pack default", desc: "注入标准包，默认 dry-run 预览" },
    { cmd: "openvibe diff <project-path>", desc: "段级差异：哪几段漂了、漂成什么样" },
    { cmd: "openvibe verify <project-path>", desc: "三方一致性核验：包 / lock / 磁盘" },
    { cmd: "openvibe update <project-path>", desc: "变更集预览 → 段级应用 → 写新 lock" },
    { cmd: "openvibe rollback <project-path>", desc: "从备份目录回到任一历史注入点" },
    { cmd: "openvibe clean <project-path>", desc: "退场：只删未改动的受管文件，删前备份" }
  ];

  return {
    PLATFORMS: PLATFORMS,
    prompts: prompts,
    terms: terms,
    roadmap: roadmap,
    skills: skills,
    scanDirs: scanDirs,
    flowTemplates: flowTemplates,
    projects: projects,
    packs: packs,
    adapters: adapters,
    compatMatrix: compatMatrix,
    eventKinds: eventKinds,
    events: events,
    injectPlan: injectPlan,
    stageDefs: stageDefs,
    moduleStages: moduleStages,
    redlines: redlines,
    cliCommands: cliCommands,
    reflows: reflows,
    cliRefs: cliRefs,
    stats: { terms: 109, prompts: 21, templates: 7, skills: 6, packs: 4, injections: 23, reflows: 11, loops: 2 }
  };
})();
